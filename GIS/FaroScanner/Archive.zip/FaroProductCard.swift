//
//  FaroProductCard.swift
//  GIS
//

import SwiftUI

struct FaroProductCard: View {

    let product: NSMutableDictionary
    let quantity: Int

    var onImageTap: () -> Void

    var onTap: (
        NSDictionary,
        String,
        String,
        String
    ) -> Void

    @State private var isExpanded = false
    @State private var selectedMetal = ""
    @State private var selectedStone = ""
    @State private var selectedSize = ""
    @State private var openDropdown: String? = nil

    private let teal = Color(
        red: 82 / 255,
        green: 203 / 255,
        blue: 196 / 255
    )

    private let cardHeight: CGFloat = 443

    private var metals: [NSDictionary] {
        if let list = product["metals"] as? [NSDictionary], !list.isEmpty {
            return list
        }
        if let metal = product["metal"] as? NSDictionary {
            return [metal]
        }
        return []
    }

    private var stones: [NSDictionary] {
        product["stones"] as? [NSDictionary] ?? []
    }

    private var sizes: [NSDictionary] {
        product["sizes"] as? [NSDictionary] ?? []
    }

    private func optionTitles(from array: [NSDictionary]) -> [String] {
        array.compactMap { value in
            guard let label = value["label"] else { return nil }
            return "\(label)"
        }
    }

    var body: some View {
        ZStack(alignment: .topLeading) {
            if isExpanded {
                expandedView
            } else {
                collapsedView
            }
        }
        .frame(maxWidth: .infinity)
        .frame(height: cardHeight)
        .zIndex(openDropdown == nil ? 0 : 50)
        .onAppear {
            loadDefaultOption()
        }
    }

    // MARK: - Collapsed card

    private var collapsedView: some View {
        VStack(alignment: .leading, spacing: 0) {

            ZStack(alignment: .topLeading) {
                RoundedRectangle(cornerRadius: 10)
                    .fill(Color.white)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color(UIColor.systemGray5), lineWidth: 1)
                    )

                Button(action: onImageTap) {
                    productImage
                        .padding(14)
                }
                .buttonStyle(.plain)

                if quantity > 0 {
                    Text("\(quantity)")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundColor(teal)
                        .frame(width: 28, height: 28)
                        .background(Color(red: 242/255, green: 251/255, blue: 250/255))
                        .overlay(
                            Circle()
                                .stroke(teal, lineWidth: 1.2)
                        )
                        .clipShape(Circle())
                        .padding(10)
                }
            }
            .frame(height: 261)

            Text(product["name"] as? String ?? "")
                .font(.system(size: 16, weight: .semibold))
                .foregroundColor(.black)
                .lineLimit(2)
                .frame(maxWidth: .infinity, alignment: .topLeading)
                .frame(height: 40, alignment: .topLeading)
                .padding(.top, 16)

            Text(product["SKU"] as? String ?? "")
                .font(.system(size: 13))
                .foregroundColor(.gray)
                .padding(.top, 6)

            HStack(alignment: .bottom, spacing: 8) {
                Text(product["price"] as? String ?? "")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundColor(.black)

                Spacer()

                selectButton
            }
            .padding(.top, 8)
        }
        .frame(maxWidth: .infinity)
        .frame(height: cardHeight, alignment: .top)
    }

    // MARK: - Expanded card

    private var expandedView: some View {
        ZStack(alignment: .bottom) {
            RoundedRectangle(cornerRadius: 10)
                .fill(Color(white: 0.965))
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(Color.gray.opacity(0.12), lineWidth: 1)
                )

            VStack(spacing: 0) {
                HStack(alignment: .top) {
                    AsyncImage(
                        url: URL(string: product["main_image"] as? String ?? "")
                    ) { image in
                        image.resizable().scaledToFit()
                    } placeholder: {
                        Color.gray.opacity(0.08)
                    }
                    .frame(width: 42, height: 42)

                    Spacer()

                    Button {
                        withAnimation(.easeInOut(duration: 0.2)) {
                            openDropdown = nil
                            isExpanded = false
                        }
                    } label: {
                        Image(systemName: "xmark")
                            .font(.system(size: 18, weight: .medium))
                            .foregroundColor(.gray)
                            .frame(width: 30, height: 30)
                    }
                    .buttonStyle(.plain)
                }
                .padding(.horizontal, 16)
                .padding(.top, 16)

                Text(product["name"] as? String ?? "")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(.black)
                    .lineLimit(2)
                    .frame(maxWidth: .infinity, alignment: .topLeading)
                    .frame(height: 40, alignment: .topLeading)
                    .padding(.horizontal, 16)
                    .padding(.top, 4)

                Text(product["SKU"] as? String ?? "")
                    .font(.system(size: 14))
                    .foregroundColor(.gray)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 16)
                    .padding(.top, 8)

                Rectangle()
                    .fill(Color.gray.opacity(0.18))
                    .frame(height: 1)
                    .padding(.top, 18)

                VStack(spacing: 10) {
                    FaroProductDropdownRow(title: "Metal", options: optionTitles(from: metals), selection: $selectedMetal, isOpen: binding(for: "Metal"))
                    FaroProductDropdownRow(title: "Stone", options: optionTitles(from: stones), selection: $selectedStone, isOpen: binding(for: "Stone"))
                    FaroProductDropdownRow(title: "Size", options: optionTitles(from: sizes), selection: $selectedSize, isOpen: binding(for: "Size"))
                }
                .padding(.horizontal, 16)
                .padding(.top, 16)

                Spacer(minLength: 0)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)

            Button {
                onTap(product, selectedMetal, selectedStone, selectedSize)
                withAnimation(.easeInOut(duration: 0.2)) {
                    openDropdown = nil
                    isExpanded = false
                }
            } label: {
                Text("Add Order")
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .frame(height: 45)
                    .background(teal)
                    .cornerRadius(9)
            }
            .buttonStyle(.plain)
            .padding(.horizontal, 16)
            .padding(.bottom, 16)
            .zIndex(openDropdown == nil ? 20 : 0)
        }
        .frame(maxWidth: .infinity)
        .frame(height: cardHeight)
        .zIndex(openDropdown == nil ? 0 : 1000)
    }

    private func binding(for name: String) -> Binding<Bool> {
        Binding(
            get: { openDropdown == name },
            set: { value in
                withAnimation(.easeInOut(duration: 0.15)) {
                    openDropdown = value ? name : nil
                }
            }
        )
    }

    private func loadDefaultOption() {
        if selectedMetal.isEmpty {
            selectedMetal = metals.first?["label"] as? String ?? "--"
        }
        if selectedStone.isEmpty {
            selectedStone = stones.first?["label"] as? String ?? "--"
        }
        if selectedSize.isEmpty {
            selectedSize = sizes.first?["label"] as? String ?? "--"
        }
    }

    private var productImage: some View {
        AsyncImage(
            url: URL(string: product["main_image"] as? String ?? "")
        ) { image in
            image
                .resizable()
                .scaledToFit()
        } placeholder: {
            ProgressView()
        }
    }

    private var selectButton: some View {
        Button {
            withAnimation(.easeInOut(duration: 0.2)) {
                openDropdown = nil
                isExpanded = true
            }
        } label: {
            Circle()
                .fill(teal)
                .frame(width: 42, height: 42)
                .overlay {
                    Image(systemName: "plus")
                        .foregroundColor(.white)
                        .font(.system(size: 18, weight: .bold))
                }
        }
        .buttonStyle(.plain)
    }
}

// MARK: - Dropdown

private struct FaroProductDropdownRow: View {
    let title: String
    let options: [String]
    @Binding var selection: String
    @Binding var isOpen: Bool

    private let teal = Color(red: 82/255, green: 203/255, blue: 196/255)

    var body: some View {
        ZStack(alignment: .top) {
            Button {
                guard !options.isEmpty else { return }
                isOpen.toggle()
            } label: {
                HStack(spacing: 10) {
                    Text(selection.isEmpty ? (options.isEmpty ? "--" : "Select \(title)") : selection)
                        .font(.system(size: 15))
                        .foregroundColor(selection.isEmpty ? .gray : Color(white: 0.35))
                        .lineLimit(1)
                    Spacer()
                    if !options.isEmpty {
                        Image(systemName: isOpen ? "chevron.up" : "chevron.down")
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundColor(.gray)
                    }
                }
                .padding(.horizontal, 14)
                .frame(height: 45)
                .background(Color.white)
                .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.gray.opacity(0.28), lineWidth: 1))
            }
            .buttonStyle(.plain)
            .disabled(options.isEmpty)

            if isOpen && !options.isEmpty {
                ScrollView(.vertical, showsIndicators: true) {
                    LazyVStack(spacing: 0) {
                        ForEach(Array(options.enumerated()), id: \.offset) { item in
                            let option = item.element
                            Button {
                                selection = option
                                isOpen = false
                            } label: {
                                HStack {
                                    Text(option)
                                        .font(.system(size: 15))
                                        .foregroundColor(Color(white: 0.35))
                                    Spacer()
                                    if selection == option {
                                        Image(systemName: "checkmark")
                                            .font(.system(size: 12, weight: .semibold))
                                            .foregroundColor(teal)
                                    }
                                }
                                .padding(.horizontal, 14)
                                .frame(height: 42)
                                .background(selection == option ? teal.opacity(0.12) : Color.white)
                            }
                            .buttonStyle(.plain)

                            if item.offset < options.count - 1 { Divider() }
                        }
                    }
                }
                .frame(maxWidth: .infinity)
                .frame(maxHeight: 220)
                .background(Color.white)
                .clipShape(RoundedRectangle(cornerRadius: 8))
                .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.gray.opacity(0.18), lineWidth: 1))
                .shadow(color: .black.opacity(0.14), radius: 8, y: 3)
                .offset(y: 49)
                .zIndex(10000)
            }
        }
        .frame(maxWidth: .infinity)
        .frame(height: 45)
        .zIndex(isOpen ? 10000 : 0)
    }
}
