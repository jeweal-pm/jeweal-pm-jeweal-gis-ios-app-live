//
//  CommonScanner.swift
//  GIS
//
//  Created by Macbook Pro on 14/08/23.
//  Copyright © 2023 Hawkscode. All rights reserved.
//

import UIKit
import AVFoundation
import Vision
import AudioToolbox

protocol ScannerDelegate {
    func mGetScannedData(value: String, type: String)
}

class CommonScanner: UIViewController,
                     AVCaptureMetadataOutputObjectsDelegate,
                     UIImagePickerControllerDelegate,
                     UINavigationControllerDelegate {

    // MARK: - IBOutlet

    @IBOutlet weak var mScannerCamView: UIView!
    @IBOutlet weak var mScannerGif: UIImageView!

    // MARK: - Camera

    var captureSession: AVCaptureSession!
    var previewLayer: AVCaptureVideoPreviewLayer!

    // MARK: - Existing Properties

    var mType = ""
    var delegate: ScannerDelegate? = nil

    let shape = CAShapeLayer()
    let layer = CAGradientLayer()

    // MARK: - Scanner UI

    private let scanFrameView = UIView()
    private let scanDescriptionLabel = UILabel()

    private let closeButton = UIButton(type: .custom)
    private let galleryButton = UIButton(type: .custom)
    
    // Design flashlight button (bottom-center)
    private let flashButton = UIButton(type: .custom)
    private var isFlashOn = false

    private var didFindCode = false

    // Corner layers
    private let topLeftCornerLayer = CAShapeLayer()
    private let topRightCornerLayer = CAShapeLayer()
    private let bottomLeftCornerLayer = CAShapeLayer()
    private let bottomRightCornerLayer = CAShapeLayer()


    // MARK: - Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()

        // -------------------------------------------------
        // Full screen scanner
        // -------------------------------------------------

        navigationItem.hidesBackButton = true

        navigationController?.setNavigationBarHidden(
            true,
            animated: false
        )

        navigationController?.navigationBar.isHidden = true

        edgesForExtendedLayout = [
            .top,
            .bottom
        ]

        extendedLayoutIncludesOpaqueBars = true

        view.backgroundColor = .black

        // -------------------------------------------------
        // UI
        // -------------------------------------------------

        setupScannerUI()
        setupCloseButton()
        setupGalleryButton()
        setupFlashButton()
        // -------------------------------------------------
        // Start scanner
        // -------------------------------------------------

        mStartQRcode()
    }


    override func viewWillAppear(_ animated: Bool) {

        super.viewWillAppear(animated)

        navigationController?.setNavigationBarHidden(
            true,
            animated: false
        )

        navigationController?.navigationBar.isHidden = true

        navigationItem.hidesBackButton = true

        didFindCode = false

        if captureSession != nil &&
            captureSession.isRunning == false {

            DispatchQueue.global(
                qos: .userInitiated
            ).async { [weak self] in

                self?.captureSession?.startRunning()
            }
        }
    }


    override func viewWillDisappear(_ animated: Bool) {

        super.viewWillDisappear(animated)

        stopCamera()

        turnOffFlash()

           if captureSession?.isRunning == true {
               DispatchQueue.global(qos: .userInitiated).async { [weak self] in
                   self?.captureSession?.stopRunning()
               }
           }

        // Restore navigation bar
        navigationController?.setNavigationBarHidden(
            false,
            animated: false
        )

        navigationController?.navigationBar.isHidden = false
    }


    override func viewDidLayoutSubviews() {

        super.viewDidLayoutSubviews()

        updateScannerUIFrames()

        // Camera view fills the entire screen
        mScannerCamView.frame = view.bounds

        if let previewLayer = previewLayer {

            previewLayer.frame = mScannerCamView.bounds
        }
    }


    // MARK: - Status Bar

    override var prefersStatusBarHidden: Bool {

        return false
    }


    override var preferredStatusBarStyle: UIStatusBarStyle {

        return .lightContent
    }


    override var supportedInterfaceOrientations:
        UIInterfaceOrientationMask {

        return .portrait
    }


    // MARK: - Scanner UI

    private func setupScannerUI() {

        view.backgroundColor = .black

        // -------------------------------------------------
        // Camera
        // -------------------------------------------------

        mScannerCamView.backgroundColor = .black
        mScannerCamView.clipsToBounds = true

        mScannerCamView.translatesAutoresizingMaskIntoConstraints = true
        mScannerCamView.frame = view.bounds

        // Old GIF is not used in new design
        mScannerGif.isHidden = true

        // -------------------------------------------------
        // Scanner frame
        // -------------------------------------------------

        scanFrameView.backgroundColor = .clear
        scanFrameView.isUserInteractionEnabled = false

        view.addSubview(scanFrameView)

        // -------------------------------------------------
        // Description
        // -------------------------------------------------

        scanDescriptionLabel.text =
            "You can scan QR codes or Barcodes"

        scanDescriptionLabel.textColor = .white

        scanDescriptionLabel.font =
            UIFont.systemFont(
                ofSize: 14,
                weight: .regular
            )

        scanDescriptionLabel.textAlignment = .center

        scanDescriptionLabel.numberOfLines = 2

        scanDescriptionLabel.lineBreakMode =
            .byWordWrapping

        scanDescriptionLabel.adjustsFontSizeToFitWidth = true

        scanDescriptionLabel.minimumScaleFactor = 0.85

        scanDescriptionLabel.backgroundColor = .clear

        view.addSubview(scanDescriptionLabel)

        updateScannerUIFrames()
    }


    // MARK: - UI Frames

    private func updateScannerUIFrames() {

        let bounds = view.bounds

        guard bounds.width > 0,
              bounds.height > 0 else {
            return
        }

        let safeTop = view.safeAreaInsets.top
        let safeBottom = view.safeAreaInsets.bottom

        // =================================================
        // SCANNER FRAME
        // =================================================

        // Smaller frame matching reference
        let horizontalMargin: CGFloat = 42

        let maxFrameWidth =
            bounds.width - (horizontalMargin * 2)

        let frameSide = min(
            maxFrameWidth,
            340
        )

        let frameX =
            (bounds.width - frameSide) / 2

        // Position frame in upper-middle area
        let frameY =
            safeTop + 175

        scanFrameView.frame = CGRect(
            x: frameX,
            y: frameY,
            width: frameSide,
            height: frameSide
        )

        drawScannerCorners(
            frameSize: scanFrameView.bounds.size
        )


        // =================================================
        // BOTTOM CONTENT
        // =================================================

        // Smaller gallery button
        let gallerySize: CGFloat = 40

        // Right margin from reference
        let galleryRightMargin: CGFloat = 42-16

        let galleryX =
            bounds.width -
            galleryRightMargin -
            gallerySize

        // Bottom position
        let galleryBottomMargin =
            max(
                safeBottom + 72,
                82
            )

        let galleryY =
            bounds.height -
            galleryBottomMargin -
            gallerySize

        galleryButton.frame = CGRect(
            x: galleryX,
            y: galleryY,
            width: gallerySize,
            height: gallerySize
        )

        /// Flashlight button - bottom center
        let flashSize: CGFloat = 84
        let flashCenterY = bounds.height - 185

        flashButton.frame = CGRect(
            x: (bounds.width - flashSize) / 2,
            y: flashCenterY - (flashSize / 2),
            width: flashSize,
            height: flashSize
        )

        // =================================================
        // DESCRIPTION
        // =================================================

        // Text sits left of gallery button
        let textRightSpacing: CGFloat = 18

        let descriptionRight =
            galleryX - textRightSpacing

        let descriptionWidth =
            min(
                bounds.width * 0.62,
                270
            )

        let descriptionHeight: CGFloat = 60

        scanDescriptionLabel.frame = CGRect(
            x: descriptionRight - descriptionWidth,
            y: galleryY - 2,
            width: descriptionWidth,
            height: descriptionHeight
        )
    }


    // MARK: - Draw Scanner Corners

    private func drawScannerCorners(
        frameSize: CGSize
    ) {

        // Reference:
        // thinner line
        // shorter corner
        let cornerLength: CGFloat = 60
        let lineWidth: CGFloat = 5

        let layers = [
            topLeftCornerLayer,
            topRightCornerLayer,
            bottomLeftCornerLayer,
            bottomRightCornerLayer
        ]

        for cornerLayer in layers {

            cornerLayer.removeFromSuperlayer()

            cornerLayer.strokeColor =
                UIColor.white.cgColor

            cornerLayer.fillColor =
                UIColor.clear.cgColor

            cornerLayer.lineWidth =
                lineWidth

            cornerLayer.lineCap =
                .round

            cornerLayer.lineJoin =
                .round

            cornerLayer.contentsScale =
                UIScreen.main.scale

            scanFrameView.layer.addSublayer(
                cornerLayer
            )
        }


        // =================================================
        // TOP LEFT
        // =================================================

        let topLeft = UIBezierPath()

        topLeft.move(
            to: CGPoint(
                x: 0,
                y: cornerLength
            )
        )

        topLeft.addLine(
            to: CGPoint(
                x: 0,
                y: 0
            )
        )

        topLeft.addLine(
            to: CGPoint(
                x: cornerLength,
                y: 0
            )
        )

        topLeftCornerLayer.path =
            topLeft.cgPath


        // =================================================
        // TOP RIGHT
        // =================================================

        let topRight = UIBezierPath()

        topRight.move(
            to: CGPoint(
                x: frameSize.width - cornerLength,
                y: 0
            )
        )

        topRight.addLine(
            to: CGPoint(
                x: frameSize.width,
                y: 0
            )
        )

        topRight.addLine(
            to: CGPoint(
                x: frameSize.width,
                y: cornerLength
            )
        )

        topRightCornerLayer.path =
            topRight.cgPath


        // =================================================
        // BOTTOM LEFT
        // =================================================

        let bottomLeft = UIBezierPath()

        bottomLeft.move(
            to: CGPoint(
                x: 0,
                y: frameSize.height - cornerLength
            )
        )

        bottomLeft.addLine(
            to: CGPoint(
                x: 0,
                y: frameSize.height
            )
        )

        bottomLeft.addLine(
            to: CGPoint(
                x: cornerLength,
                y: frameSize.height
            )
        )

        bottomLeftCornerLayer.path =
            bottomLeft.cgPath


        // =================================================
        // BOTTOM RIGHT
        // =================================================

        let bottomRight = UIBezierPath()

        bottomRight.move(
            to: CGPoint(
                x: frameSize.width - cornerLength,
                y: frameSize.height
            )
        )

        bottomRight.addLine(
            to: CGPoint(
                x: frameSize.width,
                y: frameSize.height
            )
        )

        bottomRight.addLine(
            to: CGPoint(
                x: frameSize.width,
                y: frameSize.height - cornerLength
            )
        )

        bottomRightCornerLayer.path =
            bottomRight.cgPath
    }


    // MARK: - Close Button

    private func setupCloseButton() {

        closeButton.backgroundColor = UIColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 0.2)

        // Smaller than previous 60
        closeButton.layer.cornerRadius = 25

        closeButton.clipsToBounds = true

        let image = UIImage(
            systemName: "xmark",
            withConfiguration:
                UIImage.SymbolConfiguration(
                    pointSize: 20,
                    weight: .regular
                )
        )

        closeButton.setImage(
            image,
            for: .normal
        )

        closeButton.tintColor = .white

        closeButton.accessibilityLabel =
            "Close scanner"

        closeButton.addTarget(
            self,
            action: #selector(closeScanner),
            for: .touchUpInside
        )

        view.addSubview(closeButton)

        closeButton.translatesAutoresizingMaskIntoConstraints =
            false

        NSLayoutConstraint.activate([

            closeButton.widthAnchor.constraint(
                equalToConstant: 50
            ),

            closeButton.heightAnchor.constraint(
                equalToConstant: 50
            ),

            closeButton.leadingAnchor.constraint(
                equalTo: view.leadingAnchor,
                constant: 30
            ),

            closeButton.topAnchor.constraint(
                equalTo: view.safeAreaLayoutGuide.topAnchor,
                constant: 18
            )
        ])
    }


    @objc private func closeScanner() {

        stopCamera()

        dismiss(
            animated: true
        )
    }


    // MARK: - Gallery Button

    private func setupGalleryButton() {

        galleryButton.backgroundColor =
            UIColor.white.withAlphaComponent(0.94)

        // Smaller button
        galleryButton.layer.cornerRadius = 10

        galleryButton.clipsToBounds = true

        let image = UIImage(
            systemName: "photo.on.rectangle",
            withConfiguration:
                UIImage.SymbolConfiguration(
                    pointSize: 23,
                    weight: .medium
                )
        )

        galleryButton.setImage(
            image,
            for: .normal
        )

        galleryButton.tintColor = .black

        galleryButton.imageView?.contentMode =
            .scaleAspectFit

        galleryButton.accessibilityLabel =
            "Choose photo"

        galleryButton.addTarget(
            self,
            action: #selector(openPhotoLibrary),
            for: .touchUpInside
        )

        view.addSubview(
            galleryButton
        )
    }

    // MARK: - Flashlight Button

    private func setupFlashButton() {
        guard let image = UIImage(named: "flash_ic") else {
            print("❌ Cannot find asset: flash_ic")
            return
        }

        flashButton.setImage(image, for: .normal)
        flashButton.imageView?.contentMode = .scaleAspectFit
        flashButton.accessibilityLabel = "Flashlight"

        flashButton.addTarget(
            self,
            action: #selector(toggleFlash),
            for: .touchUpInside
        )

        view.addSubview(flashButton)
    }

    @objc private func toggleFlash() {
        guard let device = AVCaptureDevice.default(for: .video),
              device.hasTorch else {
            return
        }

        do {
            try device.lockForConfiguration()

            if isFlashOn {
                device.torchMode = .off
                isFlashOn = false
            } else {
                try device.setTorchModeOn(level: AVCaptureDevice.maxAvailableTorchLevel)
                isFlashOn = true
            }

            device.unlockForConfiguration()

        } catch {
            print("❌ Flashlight error: \(error)")
        }
    }
    
    private func turnOffFlash() {
        guard isFlashOn,
              let device = AVCaptureDevice.default(for: .video),
              device.hasTorch else {
            return
        }

        do {
            try device.lockForConfiguration()
            device.torchMode = .off
            device.unlockForConfiguration()
            isFlashOn = false
        } catch {
            print("❌ Cannot turn off flashlight: \(error)")
        }
    }
    
    // MARK: - Back

    @IBAction func mBack(_ sender: Any) {

        closeScanner()
    }


    // MARK: - Start QR / Barcode Scanner

    func mStartQRcode() {

        // Prevent duplicate session
        if captureSession != nil {
            return
        }

        let session =
            AVCaptureSession()

        captureSession = session

        guard let videoCaptureDevice =
                AVCaptureDevice.default(
                    for: .video
                ) else {

            failed()

            return
        }

        let videoInput:
            AVCaptureDeviceInput

        do {

            videoInput =
                try AVCaptureDeviceInput(
                    device: videoCaptureDevice
                )

        } catch {

            failed()

            return
        }


        // =================================================
        // INPUT
        // =================================================

        if session.canAddInput(
            videoInput
        ) {

            session.addInput(
                videoInput
            )

        } else {

            failed()

            return
        }


        // =================================================
        // OUTPUT
        // =================================================

        let metadataOutput =
            AVCaptureMetadataOutput()

        if session.canAddOutput(
            metadataOutput
        ) {

            session.addOutput(
                metadataOutput
            )

            metadataOutput.setMetadataObjectsDelegate(
                self,
                queue: DispatchQueue.main
            )

            metadataOutput.metadataObjectTypes = [

                .code128,
                .code39,
                .code93,
                .qr,
                .ean8,
                .ean13,
                .pdf417,
                .aztec,
                .dataMatrix,
                .upce,
                .itf14
            ]

        } else {

            failed()

            return
        }


        // =================================================
        // PREVIEW
        // =================================================

        let newPreviewLayer =
            AVCaptureVideoPreviewLayer(
                session: session
            )

        newPreviewLayer.videoGravity =
            .resizeAspectFill

        previewLayer =
            newPreviewLayer

        mScannerCamView.layer.insertSublayer(
            newPreviewLayer,
            at: 0
        )


        // =================================================
        // START
        // =================================================

        DispatchQueue.global(
            qos: .userInitiated
        ).async {

            session.startRunning()
        }
    }


    // MARK: - Stop Camera

    private func stopCamera() {

        guard let session =
                captureSession else {
            return
        }

        if session.isRunning {

            session.stopRunning()
        }
    }


    // MARK: - Failed

    func failed() {

        DispatchQueue.main.async { [weak self] in

            guard let self =
                    self else {
                return
            }

            let ac =
                UIAlertController(
                    title: "Scanning not supported",
                    message:
                        "Your device does not support scanning a code from an item. Please use a device with a camera.",
                    preferredStyle: .alert
                )

            ac.addAction(
                UIAlertAction(
                    title: "OK",
                    style: .default
                )
            )

            self.present(
                ac,
                animated: true
            )
        }

        captureSession = nil
    }


    // MARK: - Camera Result

    func metadataOutput(
        _ output: AVCaptureMetadataOutput,
        didOutput metadataObjects: [AVMetadataObject],
        from connection: AVCaptureConnection
    ) {

        guard didFindCode == false else {
            return
        }

        guard let metadataObject =
                metadataObjects.first else {
            return
        }

        guard let readableObject =
                metadataObject
                as? AVMetadataMachineReadableCodeObject else {
            return
        }

        guard let stringValue =
                readableObject.stringValue,
              !stringValue.isEmpty else {
            return
        }

        didFindCode = true

        AudioServicesPlaySystemSound(
            kSystemSoundID_Vibrate
        )

        found(
            code: stringValue
        )
    }


    // MARK: - Found Code

    func found(code: String) {

        stopCamera()

        delegate?.mGetScannedData(
            value: code,
            type: mType
        )

        dismiss(
            animated: true
        )
    }


    // MARK: - Photo Library

    @objc private func openPhotoLibrary() {

        stopCamera()

        let picker =
            UIImagePickerController()

        picker.sourceType =
            .photoLibrary

        picker.delegate =
            self

        picker.allowsEditing =
            false

        picker.modalPresentationStyle =
            .fullScreen

        present(
            picker,
            animated: true
        )
    }


    // MARK: - Image Picker

    func imagePickerController(
        _ picker: UIImagePickerController,
        didFinishPickingMediaWithInfo info:
            [UIImagePickerController.InfoKey: Any]
    ) {

        guard let image =
                info[.originalImage] as? UIImage else {

            picker.dismiss(
                animated: true
            ) { [weak self] in

                self?.restartCamera()
            }

            return
        }

        picker.dismiss(
            animated: true
        ) { [weak self] in

            self?.scanCodeFromImage(
                image
            )
        }
    }


    func imagePickerControllerDidCancel(
        _ picker: UIImagePickerController
    ) {

        picker.dismiss(
            animated: true
        ) { [weak self] in

            self?.restartCamera()
        }
    }


    // MARK: - Restart Camera

    private func restartCamera() {

        didFindCode = false

        guard let session =
                captureSession else {

            mStartQRcode()

            return
        }

        if session.isRunning == false {

            DispatchQueue.global(
                qos: .userInitiated
            ).async {

                session.startRunning()
            }
        }
    }


    // MARK: - Scan Code From Image

    private func scanCodeFromImage(
        _ image: UIImage
    ) {

        CommonClass.showFullLoader(
            view: self.view
        )

        DispatchQueue.global(
            qos: .userInitiated
        ).async { [weak self] in

            guard let self =
                    self else {
                return
            }

            guard let cgImage =
                    self.makeCGImage(
                        from: image
                    ) else {

                DispatchQueue.main.async {

                    CommonClass.stopLoader()

                    self.showScanError(
                        message:
                            "Unable to read the selected image."
                    )

                    self.restartCamera()
                }

                return
            }


            // =================================================
            // Vision
            // =================================================

            let request =
                VNDetectBarcodesRequest {
                    [weak self] request, error in

                    guard let self =
                            self else {
                        return
                    }

                    DispatchQueue.main.async {

                        CommonClass.stopLoader()


                        if let error =
                            error {

                            self.showScanError(
                                message:
                                    error.localizedDescription
                            )

                            self.restartCamera()

                            return
                        }


                        guard let observations =
                                request.results
                                as? [VNBarcodeObservation] else {

                            self.showScanError(
                                message:
                                    "No QR code or barcode found in this image."
                            )

                            self.restartCamera()

                            return
                        }


                        let result =
                            observations.first {

                                guard let payload =
                                        $0.payloadStringValue else {
                                    return false
                                }

                                return !payload.isEmpty
                            }


                        guard let code =
                                result?.payloadStringValue,
                              !code.isEmpty else {

                            self.showScanError(
                                message:
                                    "No QR code or barcode found in this image."
                            )

                            self.restartCamera()

                            return
                        }


                        AudioServicesPlaySystemSound(
                            kSystemSoundID_Vibrate
                        )

                        self.found(
                            code: code
                        )
                    }
                }


            // =================================================
            // Supported formats
            // =================================================

            request.symbologies = [

                .QR,
                .Code128,
                .Code39,
                .Code93,
                .EAN8,
                .EAN13,
                .PDF417,
                .Aztec,
                .DataMatrix,
                .UPCE,
                .ITF14
            ]


            // =================================================
            // Vision Handler
            // =================================================

            let handler =
                VNImageRequestHandler(
                    cgImage: cgImage,
                    orientation:
                        self.cgImageOrientation(
                            for: image
                        ),
                    options: [:]
                )

            do {

                try handler.perform(
                    [request]
                )

            } catch {

                DispatchQueue.main.async {

                    CommonClass.stopLoader()

                    self.showScanError(
                        message:
                            error.localizedDescription
                    )

                    self.restartCamera()
                }
            }
        }
    }


    // MARK: - Make CGImage

    private func makeCGImage(
        from image: UIImage
    ) -> CGImage? {

        if let cgImage =
            image.cgImage {

            return cgImage
        }


        if let ciImage =
            image.ciImage {

            let context =
                CIContext(
                    options: [
                        CIContextOption.priorityRequestLow:
                            true
                    ]
                )

            return context.createCGImage(
                ciImage,
                from: ciImage.extent
            )
        }

        return nil
    }


    // MARK: - Image Orientation

    private func cgImageOrientation(
        for image: UIImage
    ) -> CGImagePropertyOrientation {

        switch image.imageOrientation {

        case .up:
            return .up

        case .upMirrored:
            return .upMirrored

        case .down:
            return .down

        case .downMirrored:
            return .downMirrored

        case .left:
            return .left

        case .leftMirrored:
            return .leftMirrored

        case .right:
            return .right

        case .rightMirrored:
            return .rightMirrored

        @unknown default:
            return .up
        }
    }


    // MARK: - Error

    private func showScanError(
        message: String
    ) {

        CommonClass.showSnackBar(
            message: message
        )
    }
}
