//
//  SKUProductSummary.swift
//  GIS
//
//  Created by MacBook Hawkscode  on 13/12/22.
//  Copyright © 2022 Hawkscode. All rights reserved.
//

import UIKit
import Alamofire
class SKUStonesCell : UITableViewCell {
    
    
    @IBOutlet weak var mStoneName: UILabel!
    
    @IBOutlet weak var mShapeName: UILabel!
    
    @IBOutlet weak var mCut: UILabel!
    @IBOutlet weak var mClarity: UILabel!
    @IBOutlet weak var mColor: UILabel!
    @IBOutlet weak var mSize: UILabel!
    
    @IBOutlet weak var mPcs: UILabel!
    @IBOutlet weak var mWeight: UILabel!
    @IBOutlet weak var mSetting: UILabel!
    @IBOutlet weak var mCertificateName: UILabel!
    
    @IBOutlet weak var mOpenLinkButton: UIButton!
    @IBOutlet weak var mCertificateNumber: UILabel!
    
    @IBOutlet weak var mStoneLABEL: UILabel!
    @IBOutlet weak var mShapeLABEL: UILabel!
    @IBOutlet weak var mCutLABEL: UILabel!
    @IBOutlet weak var mClarityLABEL: UILabel!
    @IBOutlet weak var mColorLABEL: UILabel!
    @IBOutlet weak var mSizeLABEL: UILabel!
    @IBOutlet weak var mPcsLABEL: UILabel!
    
    @IBOutlet weak var mWeightLABEL: UILabel!
    @IBOutlet weak var mSettingLABEL: UILabel!
    @IBOutlet weak var mCertificateLABEL: UILabel!
    
    
    
}

class SKUProductSummary: UIViewController , UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var mTableHeight: NSLayoutConstraint!
    @IBOutlet weak var mProductImage: UIImageView!
    @IBOutlet weak var mMetatag: UILabel!
    @IBOutlet weak var mProductInfo: UILabel!
    @IBOutlet weak var mProductId: UILabel!
    @IBOutlet weak var mSKUName: UILabel!
    @IBOutlet weak var mStockId: UILabel!
    @IBOutlet weak var mVariantStatus: UIImageView!
    @IBOutlet weak var mCurrencyFlag: UIImageView!
    @IBOutlet weak var mPrice: UILabel!
    @IBOutlet weak var mLocation: UILabel!
    @IBOutlet weak var mMetal: UILabel!
    @IBOutlet weak var mColor: UILabel!
    @IBOutlet weak var mSize: UILabel!
    @IBOutlet weak var mGrossWeight: UILabel!
    @IBOutlet weak var mNetWeight: UILabel!
    
    @IBOutlet weak var mStoneTable: UITableView!
    
    private var mProductData = NSMutableArray()
    var mOriginalData = NSArray()
    var mStoneData = NSArray()
    
    var storeCurrency: String = ""
    var mKey = ""
    
    
    @IBOutlet weak var mProductIdLABEL: UILabel!
    @IBOutlet weak var mSKULABEL: UILabel!
    @IBOutlet weak var mStockIdLABEL: UILabel!
    @IBOutlet weak var mPriceLABEL: UILabel!
    @IBOutlet weak var mLocationLABEL: UILabel!
    @IBOutlet weak var mMetalLABEL: UILabel!
    @IBOutlet weak var mColorLABEL: UILabel!
    @IBOutlet weak var mSizeLABEL: UILabel!
    @IBOutlet weak var mGrossWeightLABEL: UILabel!
    @IBOutlet weak var mNetWeightLABEL: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("🔥 SKUProductSummary OPEN")
        mUserLoginToken = UserDefaults.standard.string(forKey: "token")
        mUserLoginTokenPos = UserDefaults.standard.string(forKey: "token_pos")
        
        mProductIdLABEL.text = "Product ID".localizedString
        mSKULABEL.text = "SKU".localizedString
        mStockIdLABEL.text = "Stock ID".localizedString
        mPriceLABEL.text = "Price".localizedString
        mLocationLABEL.text = "Location".localizedString
        mMetalLABEL.text = "Metal".localizedString
        mColorLABEL.text = "Color".localizedString
        mSizeLABEL.text = "Size".localizedString
        mGrossWeightLABEL.text = "Gross Wt".localizedString
        mNetWeightLABEL.text = "Net Wt".localizedString
        
        
        if !mKey.isEmpty {
            CommonClass.showFullLoader(view: self.view)
            let params = ["id": mKey]
            
            mGetData(url: mProductInformation,headers: sGisHeaders,  params: params) { response , status in
                CommonClass.stopLoader()
                print("SKUProductSummary response is \(response)")
                if status {
                    if let data = response.value(forKey: "data") as? NSDictionary {
                        
                        self.mSetData(mData: data)
                    }else{
                        CommonClass.showSnackBar(message: "Product info not available!")
                    }
                }else{
                    CommonClass.showSnackBar(message: "Product info not available!")
                    
                }
                
            }
        }else{
            mProductData = NSMutableArray(array: mOriginalData )
            if let mData = mProductData[0] as? NSDictionary {
                mSetData(mData: mData)
            }
        }
        
        
        
        
    }
    
    private func getStoneData(from data: NSDictionary) -> NSArray {

        if let stones = data["stoneData"] as? NSArray,
           stones.count > 0 {
            return stones
        }

        if let stones = data["Stones"] as? NSArray,
           stones.count > 0 {
            return stones
        }

        if let product = data["product_details"] as? NSDictionary,
           let stones = product["Stones"] as? NSArray,
           stones.count > 0 {
            return stones
        }

        return NSArray()
    }
    
    func mSetData(mData: NSDictionary) {
        mProductImage.downlaodImageFromUrl(urlString: "\(mData.value(forKey: "main_image") ?? "" )")
        mMetatag.text = "\(mData.value(forKey: "Matatag") ?? "")"
//        mProductInfo.text = "\(mData.value(forKey: "item_name") ?? "")"
        mProductInfo.text = "\(mData["name"] ?? mData["item_name"] ?? "")"
//        mProductId.text = "\(mData.value(forKey: "ID") ?? "")"
        mProductId.text = "\(mData["ID"] ?? mData["product_id"] ?? "")"
        mSKUName.text = "\(mData.value(forKey: "SKU") ?? "")"
        mStockId.text = "\(mData.value(forKey: "stock_id") ?? "")"
//        mPrice.text = "\(mData.value(forKey: "price") ?? "")"
        if let mStoreCurr = UserDefaults.standard.string(forKey: "currencySymbol") {
            storeCurrency = mStoreCurr
        }
        if let price = mData.value(forKey: "price") as? Double {
            let formatter = NumberFormatter()
            formatter.numberStyle = .decimal
            formatter.minimumFractionDigits = 2
            formatter.maximumFractionDigits = 2
            mPrice.text = "\(storeCurrency) \(formatter.string(from: NSNumber(value: price)) ?? "0.00")"
        } else if let price = Double("\(mData.value(forKey: "price") ?? "0")") {
            let formatter = NumberFormatter()
            formatter.numberStyle = .decimal
            formatter.minimumFractionDigits = 2
            formatter.maximumFractionDigits = 2
            mPrice.text = "\(storeCurrency) \(formatter.string(from: NSNumber(value: price)) ?? "0.00")"//formatter.string(from: NSNumber(value: price))
        } else {
            mPrice.text = "\(storeCurrency) 0.00"
        }
        mLocation.text = "\(mData.value(forKey: "location_name") ?? "")"
        mMetal.text = "\(mData.value(forKey: "metal_name") ?? "")"
        mColor.text = "\(mData.value(forKey: "color") ?? "")"
        mSize.text = "\(mData.value(forKey: "size_name") ?? "")"
//        mGrossWeight.text = "\(mData.value(forKey: "GrossWt") ?? "")"
//        mNetWeight.text = "\(mData.value(forKey: "NetWt") ?? "")"
        mGrossWeight.text = "\(mData["GrossWt"] ?? mData["gross_weight"] ?? "")"

        mNetWeight.text = "\(mData["NetWt"] ?? mData["net_weight"] ?? "")"
        
        let isVariant = (mData["is_variant"] as? Int)
                     ?? (mData["isVariant"] as? Int)
                     ?? 0

        let isDesign = (mData["is_design"] as? Int)
                    ?? (mData["isDesign"] as? Int)
                    ?? 0

        if isVariant == 1 && isDesign == 1 {
            print("isVariant == 1 && isDesign == 1")
            mVariantStatus.image = UIImage(named: "diamond_ic")
        } else if isVariant == 1 {
            print("isVariant == 1")
            mVariantStatus.image = UIImage(named: "variantic")
        } else if isDesign == 1 {
            print("isDesign == 1")
            mVariantStatus.image = UIImage(named: "diamond_ic")
        } else {
            print("nilnilnil")
            mVariantStatus.image = nil
        }
        let variantType = "\(mData.value(forKey: "product_variants_enable") ?? "0")"

        switch variantType {

        case "1":
            mVariantStatus.image = UIImage(named: "variantic")

        case "2":
            mVariantStatus.image = UIImage(named: "diamond_ic")

        case "3":
            mVariantStatus.image = UIImage(named: "diamond_ic")

        default:
            mVariantStatus.image = nil
        }
        
//        if let mStonesArr = mData.value(forKey: "stoneData") as? NSArray, mStonesArr.count > 0 {
//            mStoneData = mStonesArr
//        } else {
//            return
//        }
        print("STONE =", mData)
        mStoneData = getStoneData(from: mData)
//        if let stones = mData["stoneData"] as? NSArray,
//           stones.count > 0 {
//
//            print("Using stoneData")
//            mStoneData = stones
//
//        } else if let stones = mData["Stones"] as? NSArray,
//                  stones.count > 0 {
//
//            print("Using Stones")
//            mStoneData = stones
//
//        } else if let productDetails = mData["product_details"] as? NSDictionary,
//                  let stones = productDetails["Stones"] as? NSArray,
//                  stones.count > 0 {
//
//            print("Using product_details.Stones")
//            mStoneData = stones
//
//        } else {
//
//            print("No stone data found")
//            mStoneData = []
//        }
        
        
        
        mStoneTable.delegate = self
        mStoneTable.dataSource = self
        mStoneTable.reloadData()
        mStoneTable.isScrollEnabled = false
        mStoneTable.separatorColor = UIColor(named: "themeTextExtraLight1")
        mStoneTable.separatorStyle = .singleLine
        
        mStoneTable.reloadData()
        mStoneTable.layoutIfNeeded()
        mTableHeight.constant = mStoneTable.contentSize.height + 300
    }
    
    @IBAction func mOpenLink(_ sender: UIButton) {

        guard let data = mStoneData[sender.tag] as? NSDictionary else {
            return
        }

        var link = ""

        if let certificate = data["certificate"] as? NSDictionary {
            link = certificate["url"] as? String ?? ""
        } else {
            link = data["certificateLink"] as? String ?? ""
        }

        guard !link.isEmpty,
              let url = URL(string: link) else {
            CommonClass.showSnackBar(message: "No links found!")
            return
        }

        UIApplication.shared.open(url)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return mStoneData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        tableView.showsVerticalScrollIndicator = false
        tableView.showsHorizontalScrollIndicator = false
        
        guard let cells = tableView.dequeueReusableCell(withIdentifier: "SKUStonesCell") as? SKUStonesCell else {
            return UITableViewCell()
        }
        
        cells.mStoneLABEL.text = "Stone".localizedString
        cells.mShapeLABEL.text = "Shape".localizedString
        cells.mCutLABEL.text = "Cut".localizedString
        cells.mClarityLABEL.text = "Clarity".localizedString
        cells.mColorLABEL.text = "Color".localizedString
        cells.mSizeLABEL.text = "Size".localizedString
        cells.mPcsLABEL.text = "Pcs".localizedString
        cells.mWeightLABEL.text = "Weight".localizedString
        cells.mSettingLABEL.text = "Setting".localizedString
        cells.mCertificateLABEL.text = "Certificate".localizedString
        
        if let mData = mStoneData[indexPath.row] as? NSDictionary {

//            let pointer = "\(mData["Pointer"] ?? "")"

//            let sizeName = "\(mData["Size_name"] ?? "")"
            let sizeName = "\(mData["size_name"] ?? mData["Size"] ?? "")"

//            if pointer.isEmpty || pointer == "0" || pointer == "0.0" {
                cells.mSize.text = sizeName
//            } else {
//                cells.mSize.text = "\(sizeName) - \(pointer)"
//            }
            

//            cells.mStoneName.text = "\(mData["stone_name"] ?? "--")"
//            cells.mShapeName.text = "\(mData["shape_name"] ?? "--")"
//            cells.mCut.text = "\(mData["Cut_name"] ?? "--")"
//            cells.mClarity.text = "\(mData["clarity_name"] ?? "--")"
//            cells.mColor.text = "\(mData["Color_name"] ?? "--")"
//            cells.mStoneName.text =
//                "\(mData["stone_name"] ?? mData["stone"] ?? "--")"
//            cells.mShapeName.text =
//                "\(mData["shape_name"] ?? mData["shape"] ?? "--")"
//            cells.mCut.text =
//                "\(mData["Cut_name"] ?? mData["cut"] ?? "--")"
//            cells.mClarity.text =
//                "\(mData["clarity_name"] ?? mData["Clarity_name"] ?? "--")"
//            cells.mColor.text =
//                "\(mData["Color_name"] ?? mData["color"] ?? "--")"
//            cells.mSetting.text =
//                "\(mData["Setting_type_name"] ?? mData["setting_type"] ?? "--")"
            
            cells.mStoneName.text =
                "\(mData["stone"] ?? mData["stone_name"] ?? "--")"

            cells.mShapeName.text =
                "\(mData["shape"] ?? mData["shape_name"] ?? "--")"

            cells.mCut.text =
                "\(mData["cut"] ?? mData["Cut_name"] ?? "--")"

            cells.mClarity.text =
                "\(mData["clarity"] ?? mData["clarity_name"] ?? mData["Clarity_name"] ?? "--")"

            cells.mColor.text =
                "\(mData["color"] ?? mData["Color_name"] ?? "--")"

            cells.mSetting.text =
                "\(mData["setting_type"] ?? mData["Setting_type_name"] ?? "--")"

            cells.mPcs.text = "\(mData["Pcs"] ?? "--")"
//            cells.mWeight.text = "\(mData["Cts"] ?? "--")"
            let cts = Double("\(mData["Cts"] ?? 0)") ?? 0
            cells.mWeight.text = String(format: "%.2f", cts)

//            cells.mSetting.text = "\(mData["Setting_type_name"] ?? "--")"

//            if let certificate = mData["certificate"] as? NSDictionary {
//
//                cells.mCertificateName.text = "\(certificate["type"] ?? "--")"
//                cells.mCertificateNumber.text = "\(certificate["number"] ?? "--")"
//
//            } else {
//
//                cells.mCertificateName.text = "--"
//                cells.mCertificateNumber.text = "--"
//            }
            if let certificate = mData["certificate"] as? NSDictionary {

                cells.mCertificateName.text = "\(certificate["type"] ?? "--")"
                cells.mCertificateNumber.text = "\(certificate["number"] ?? "--")"

            } else {

                cells.mCertificateName.text = "\(mData["certificateName"] ?? "--")"

                cells.mCertificateNumber.text = "\(mData["certificateNo"] ?? "--")"
            }

            cells.mOpenLinkButton.tag = indexPath.row
        }
//        if let mData = mStoneData[indexPath.row] as? NSDictionary {
//            
//            if var pointer = mData.value(forKey: "Pointer") as? String {
//                if pointer == "0.0" {
//                    pointer = ""
//                    cells.mSize.text = "\(mData.value(forKey: "Size") ?? "")"
//                }else{
//                    cells.mSize.text = "\(mData.value(forKey: "Size") ?? "")" +  " - \(pointer)"
//                }
//            }else{
//                cells.mSize.text = "\(mData.value(forKey: "Size") ?? "")"
//            }
//            cells.mStoneName.text = "\(mData.value(forKey: "stone") ?? "")"
//            cells.mShapeName.text = "\(mData.value(forKey: "shape") ?? "")"
//            cells.mCut.text = "\(mData.value(forKey: "cut") ?? "")"
//            cells.mClarity.text = "\(mData.value(forKey: "clarity") ?? "")"
//            cells.mPcs.text = "\(mData.value(forKey: "Pcs") ?? "")"
//            cells.mSetting.text = "\(mData.value(forKey: "setting_type") ?? "")"
//            cells.mColor.text = "\(mData.value(forKey: "color") ?? "")"
//            
//            cells.mCertificateName.text = "\(mData.value(forKey: "certificateName") ?? "")"
//            cells.mCertificateNumber.text = "\(mData.value(forKey: "certificateNo") ?? "")"
//            cells.mOpenLinkButton.tag = indexPath.row
//            cells.mWeight.text = "\(mData.value(forKey: "Cts") ?? "")"
//        }
        self.mStoneTable.layoutIfNeeded()
        self.mTableHeight.constant = self.mStoneTable.contentSize.height + 300
        return cells
    }
    
    
    
    
}
