//
//  PosCart.swift
//  GIS
//
//  Created by MacBook Hawkscode  on 06/02/23.
//  Copyright © 2023 Hawkscode. All rights reserved.
//

import UIKit
import Alamofire
import DropDown


protocol GetParkItems {
    func mGetParkItems(parkId:String)
}

protocol SalesPersonTransactionDelegate {
    func mSelectedCustomer(customerId:String)
    
}


let mAddParkPopUp = UINib(nibName:"confirmpark",bundle:.main).instantiate(withOwner: nil, options: nil).first as? AddParkPopUp ?? AddParkPopUp()

class AddParkPopUp: UIView {
    var mType = ""
    var mCustomerId = ""
    var mCartId = ""
    var index = Int()
    var delegate:ProceedToPay? = nil
    @IBOutlet weak var mAddNoteLABEL: UILabel!
    
    @IBOutlet weak var mNoteForLABEL: UILabel!
    @IBOutlet weak var mMessage: UITextField!
    @IBOutlet weak var mConfirmButton: UIButton!
    @IBOutlet weak var mCancelButton: UIButton!
    
    var mNavigation = UINavigationController()
    static func instantiate(message: String) -> AddParkPopUp {
        let view: AddParkPopUp = initFromNib()
        return view
    }

    @IBAction func mCancel(_ sender: Any) {
        self.removeFromSuperview()

    }
    
    @IBAction func mConfirm(_ sender: Any) {
        self.removeFromSuperview()
        if mMessage.text != "" {
            self.delegate?.isProceedWithStatus(status: true, message: self.mMessage.text ?? "")
        }else{
            CommonClass.showSnackBar(message: "Please write a note!")
        }
    }

}

class PosCart:UIViewController, UIViewControllerTransitioningDelegate ,GetCustomerDataDelegate , UITableViewDataSource, UITextFieldDelegate, UITableViewDelegate, GetInventoryDataItemsDelegate , DeleteCustomCartItems , ProceedToPay,GetParkItems , SalesPersonTransactionDelegate, SearchDelegate, ServiceLabourDelegate, GetAddressDataDelegate {
    
    func isProceed(status: Bool) {
        
    }
   
    
    @IBOutlet weak var mParkCount: UILabel!
    @IBOutlet weak var mAvailableParkView: UIView!
    //TAX VIEWS
    
    
    @IBOutlet weak var mTaxView: UIView!
    @IBOutlet weak var mTaxSubTotal: UILabel!
    @IBOutlet weak var mTaxTotal: UILabel!
    
    @IBOutlet weak var mTaxAmount: UITextField!
    @IBOutlet weak var mTaxValue: UITextField!

    @IBOutlet weak var mTaxLabourCharge: UITextField!
    @IBOutlet weak var mTaxShippingCharge: UITextField!
    @IBOutlet weak var mTaxLoyaltyPoint: UITextField!

    @IBOutlet weak var mTaxDiscountPercents: UITextField!
    @IBOutlet weak var mTaxDiscountAmounts: UITextField!
    
    @IBOutlet weak var mSearchField: UITextField!

    @IBOutlet weak var mTotalItems: UILabel!
    @IBOutlet weak var mGrandTotal: UILabel!
    @IBOutlet weak var mDepositAmount: UILabel!
    @IBOutlet weak var mOutstandingAmount: UILabel!
    @IBOutlet weak var mSelectedCustomerIcon: UIImageView!
    var mCustomerId = ""
    
    @IBOutlet weak var mNotes: UITextField!
    
    @IBOutlet weak var mAddressPickerIcon: UIImageView!
    @IBOutlet weak var mAddressAlertIcon: UIImageView!
    
    var mDepositPercentData = ["25%","50%","75%","100%"]
    var mDepositPercentValue = ["25","50","75","100"]
    var mCurrency = ""
    var mGrandTotalCart = "0.00"

    @IBOutlet weak var mDepositePercent: UILabel!
    var mDepositPercents = "100"
    var mGrandTotalAmounts = "0.00"
    var mTotalDepositAmounts = "0.00"
    var mOutStandingAmounts = "0.00"
    @IBOutlet weak var mCartTable: UITableView!
    var mCartData = NSMutableArray()
    var mCartDataMaster = NSArray()


    var mQuantityData = [Int]()
    var mCartAmount = [Double]()
    var mCurrentIndex = -1
    let mDatePicker:UIDatePicker = UIDatePicker()
    var isItemsAvailable =  false
    var isDeleted = false
    @IBOutlet weak var mSalesPersonimag: UIImageView!
    @IBOutlet weak var mUpForwardIcon: UIImageView!
    
    @IBOutlet weak var mTaxAmountLABEL: UILabel!
    
    @IBOutlet weak var mTaxPercentLABEL: UILabel!
    @IBOutlet weak var mTaxSubTotalLABEL: UILabel!
    @IBOutlet weak var mDiscountAmountLABEL: UILabel!
    @IBOutlet weak var mDiscountPercentLABEL: UILabel!
    @IBOutlet weak var mTaxShippingLABEL: UILabel!
    @IBOutlet weak var mTaxLoyaltyPointLABEL: UILabel!
    
    @IBOutlet weak var mTaxLabourLABEL: UILabel!
    @IBOutlet weak var mTaxTotalLABEL: UILabel!
    @IBOutlet weak var mCheckOutBUTTON: UIButton!
   
    @IBOutlet weak var mParkBUTTON: UIButton!
    @IBOutlet weak var mHeadingLABEL: UILabel!
    
    @IBOutlet weak var mParkButtonView: UIView!
    @IBOutlet weak var mNoteLABEL: UILabel!
    
    @IBOutlet weak var mGrandTotalLABEL: UILabel!
    
    var mParkedStockIds = Set<String>()
    
    var mCalculatedSubTotal: Double = 0.0
    var mCalculatedTaxAmount: Double = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mCustomerId = UserDefaults.standard.string(forKey: "DEFAULTCUSTOMER") ?? ""
        mSalesPersonimag.downlaodImageFromUrl(urlString: UserDefaults.standard.string(forKey: "SALESPERSON_IMAGE") ?? "")
        self.mNotes.keyboardType = .default
        mUserLoginToken = UserDefaults.standard.string(forKey: "token")
        mUserLoginTokenPos = UserDefaults.standard.string(forKey: "token_pos")

        self.mCartTable.delegate = self
        self.mCartTable.dataSource = self
        self.mCartTable.reloadData()
        mGrandTotal.text = "\(UserDefaults.standard.value(forKey: "currencySymbol") ?? "$") 0.00"
        print("GrandTotal =", mGrandTotal.text ?? "")
        UserDefaults.standard.setValue(nil, forKey: "CustomerBillingAddressUDID")
        UserDefaults.standard.setValue(nil, forKey: "CustomerShippingAddressUDID")
        
        mTaxDiscountPercents.keyboardType = .decimalPad
        mTaxDiscountAmounts.keyboardType = .decimalPad
        
        mTaxShippingCharge.delegate = self
        mTaxLoyaltyPoint.delegate = self
//        mTaxLabourCharge.delegate = self
        
        let tap = UITapGestureRecognizer(
            target: self,
            action: #selector(dismissKeyboard)
        )
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
        
    }
    
    @objc private func dismissKeyboard() {
        view.endEditing(true)
    }
    
    func mSelectedCustomer(customerId: String) {
        
    }
    
    
    
    @IBAction func mOpenSalesPerson(_ sender: Any) {
        
        let storyBoard: UIStoryboard = UIStoryboard(name: "posBoard", bundle: nil)
        if let mSalesPerson = storyBoard.instantiateViewController(withIdentifier: "SalesPerson") as? SalesPerson {
            mSalesPerson.modalPresentationStyle = .overFullScreen
            mSalesPerson.delegate = self
            mSalesPerson.transitioningDelegate = self
            self.present(mSalesPerson,animated: true)
        }
    }
    func isProceedWithStatus(status: Bool, message : String) {
        if status {
            
            let mParkCarData = NSMutableArray()
        
            for i in self.mCartData {
                let mParkObjects = NSMutableDictionary()
                if let mData = i as? NSDictionary {
                    mParkObjects.setValue("\(mData.value(forKey: "Qty") ?? "" )", forKey: "Qty")
                    mParkObjects.setValue("pos_order", forKey: "type")
                    mParkObjects.setValue("\(mData.value(forKey: "retailprice_Inc") ?? "0")", forKey: "retailprice_Inc")
                    
                    mParkObjects.setValue("\(mData.value(forKey: "price") ?? "0" )", forKey: "price")
                    mParkObjects.setValue("pos_order", forKey: "order_type")
                    mParkObjects.setValue("\(mData.value(forKey: "Discount_Amount") ?? "0" )", forKey: "Discount_Amount")
                    mParkObjects.setValue("\(mData.value(forKey: "discount_percent") ?? "0" )", forKey: "discount_percent")
                    mParkObjects.setValue("\(mData.value(forKey: "custom_cart_id") ?? "" )", forKey: "custom_cart_id")
                    mParkObjects.setValue("\(mData.value(forKey: "name") ?? "" )", forKey: "name")
                    mParkObjects.setValue("\(mData.value(forKey: "main_image") ?? "" )", forKey: "main_image")
                    mParkObjects.setValue("\(mData.value(forKey: "currency") ?? "" )", forKey: "currency")
                    mParkObjects.setValue("\(mData.value(forKey: "stock_id") ?? "" )", forKey: "stock_id")
                }
                mParkCarData.add(mParkObjects)
                
            }
            let mSummaryOrder = NSMutableDictionary()
            let mSellInfo = NSMutableDictionary()
            let mCustomerData = NSMutableDictionary()
            mCustomerData.setValue(self.mCustomerId, forKey: "id")
            mCustomerData.setValue(UserDefaults.standard.string(forKey:"DEFAULTCUSTOMERNAME") ?? "User", forKey: "name")

            mSummaryOrder.setValue(0, forKey: "labour")
            mSummaryOrder.setValue(0, forKey: "shipping")
            mSummaryOrder.setValue(0, forKey: "loyalty_points")
            mSummaryOrder.setValue(0, forKey: "tax_amount")
            mSummaryOrder.setValue(0, forKey: "tax_amount_int")
            mSummaryOrder.setValue(0, forKey: "tax_prect")
            mSummaryOrder.setValue("", forKey: "tax_type")
            mSummaryOrder.setValue(0, forKey: "discount")
            mSummaryOrder.setValue(0, forKey: "discount_percent")
            mSummaryOrder.setValue(mCustomerData, forKey: "customer_id")
            mSummaryOrder.setValue("", forKey: "sales_person_id")
            mSummaryOrder.setValue(0, forKey: "deposit")
            mSummaryOrder.setValue(Double(self.mGrandTotalAmounts), forKey: "deposit_amount")
        
            mSellInfo.setValue(mParkCarData, forKey: "cart")
            mSellInfo.setValue(mSummaryOrder, forKey: "summary_order")
            mSellInfo.setValue("pos_order", forKey: "status_type")
            mSellInfo.setValue(Double(self.mGrandTotalAmounts), forKey: "totalamount")
            let  mFinalData = ["sell_info": mSellInfo, "totalamount":self.mGrandTotalAmounts,"order_type":"pos_order", "parktime": message] as [String : Any]
            
            
            
            mUserLoginToken = UserDefaults.standard.string(forKey: "token")
            mUserLoginTokenPos = UserDefaults.standard.string(forKey: "token_pos")
        
            mGetData(url: mAddToPark,headers: sGisHeaders,  params: mFinalData) { response , status in
                if status {
                    var parkedIds = UserDefaults.standard.stringArray(forKey: "ParkedStockIds") ?? []

                    for item in self.mCartData {

                        if let dict = item as? NSDictionary {

                            let stockId = "\(dict["stock_id"] ?? "")"

                            if !parkedIds.contains(stockId) {
                                parkedIds.append(stockId)
                            }
                        }
                    }

                    UserDefaults.standard.set(parkedIds, forKey: "ParkedStockIds")
                    
                    
                    
                    // ===== Clear Cart =====
                    self.mClearCart()
                    self.mCartData.removeAllObjects()
                    self.mCartTable.reloadData()

                    // ถ้ามีฟังก์ชันคำนวณยอด
                    self.mTaxShippingCharge.text = "0.00"
                    self.mTaxLoyaltyPoint.text = "0.00"
                    self.calculateItemsWithAmount()
                    
                    self.mGetParkStatus()

                    
                }
        }
            
        }
    }
    
    
    @IBAction func mParkNow(_ sender: UIButton) {
        
        if mCartData.count  > 0 {
        mAddParkPopUp.frame = self.view.bounds
        mAddParkPopUp.mMessage.text = ""
            mAddParkPopUp.mMessage.placeholder = "Ex: Customer will back in 10 mins".localizedString
        mAddParkPopUp.delegate = self
            mAddParkPopUp.mAddNoteLABEL.text = "Add Note".localizedString
            mAddParkPopUp.mNoteForLABEL.text = "Not for the sale you want to park".localizedString
            mAddParkPopUp.mCancelButton.setTitle("CANCEL".localizedString, for: .normal)
            mAddParkPopUp.mConfirmButton.setTitle("PARK SALE".localizedString, for: .normal)
        self.view.addSubview(mAddParkPopUp)
    
        }else{
            CommonClass.showSnackBar(message: "No Items in Cart")
        }
        
    }
    
    func mGetParkItems(parkId: String) {
        
        if parkId != "" {
            
            let mParams = [ "park_id":parkId] as [String : Any]
            
            mUserLoginToken = UserDefaults.standard.string(forKey: "token")
            mUserLoginTokenPos = UserDefaults.standard.string(forKey: "token_pos")
            
            mGetData(url: mFetchCustomProduct,headers: sGisHeaders,  params: mParams) { response , status in
                CommonClass.stopLoader()
                if status {
                if "\(response.value(forKey: "code") ?? "")" == "200" {
                    if let mData = response.value(forKey: "data") as? NSArray, mData.count > 0 {
                        self.mCartDataMaster = mData
                        self.mCartData = NSMutableArray(array: mData)
                        self.mCartTable.delegate = self
                        self.mCartTable.dataSource = self
                        self.mQuantityData = [Int]()
                        self.mCartAmount = [Double]()
                        self.mGetParkStatus()
                        self.mCartTable.reloadData()
                        for i in self.mCartData {
                            if let mData = i as? NSDictionary {
                                self.mQuantityData.append(Int("\(mData.value(forKey: "Qty") ?? "0")") ?? 0)
                                
                                let priceString = "\(mData.value(forKey: "cart_price") ?? "0")"
                                print("priceStringpriceStringpriceString = \(priceString)")
                                let filtered = priceString.filter {
                                    "0123456789.-".contains($0)
                                }
                                print("filteredfilteredfilteredfiltered = \(filtered)")
                                let price = Double(filtered) ?? 0.0
                                print("pricepricepricepriceprice = \(price)")
                                self.mCartAmount.append(price)
                                print("mCartAmount =", self.mCartAmount)
                                print("sum =", self.mCartAmount.reduce(0, +))
//                                self.calculateItemsWithAmount()
                                
//                                self.mCartAmount.append(Double("\(mData.value(forKey: "cart_price") ?? "0")") ?? 0.0)
                            }
                        }
                        DispatchQueue.main.async {
                            self.mCartTable.reloadData()
                            self.calculateItemsWithAmount()
                        }
                    }
                    
                    
                }else{
              
                }
            }
        }
        }else{
            mGetParkStatus()
        }
        
    }
    @IBAction func mViewPark(_ sender: UIButton) {
      
        let storyBoard: UIStoryboard = UIStoryboard(name: "posBoard", bundle: nil)
        if let mPOSPark = storyBoard.instantiateViewController(withIdentifier: "POSPark") as? POSPark {
            mPOSPark.modalPresentationStyle = .overFullScreen
            mPOSPark.delegate = self
            mPOSPark.transitioningDelegate = self
            self.present(mPOSPark,animated: true)
        }
    }
    
    
    @IBAction func mEditLabour(_ sender: UITextField) {
//        if sender.text == "" {
//            sender.text = "0"
//            calculateItemsWithAmount()
//        }else{
//            calculateItemsWithAmount()
//            
//        }
        calculateItemsWithAmount()
    }
    @IBAction func mEditShipping(_ sender: UITextField) {
//        if sender.text == "" {
//            sender.text = ""
//            calculateItemsWithAmount()
//        }else{
            calculateItemsWithAmount()
//        }
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == self.mTaxShippingCharge,
           (textField.text ?? "").isEmpty {
            textField.text = "0"
        }
    }
    
    @IBAction func mEditLoyaltyPoints(_ sender: UITextField) {
//        if sender.text == "" {
//            sender.text = "0"
//            calculateItemsWithAmount()
//        }else{
            calculateItemsWithAmount()
            
//        }
    }
    @IBAction func mEditTaxDiscount(_ sender: UITextField) {

        let shipping = Double(self.mTaxShippingCharge.text ?? "") ?? 0.0
        let loyalty = Double(self.mTaxLoyaltyPoint.text ?? "") ?? 0.0

        let orderTotal = (Double(self.mGrandTotalAmounts) ?? 0.0) + shipping + loyalty
        var percent = Double(sender.text ?? "") ?? 0.0

        // จำกัดช่วง 0 - 100%
        if percent < 0 {
            percent = 0
        } else if percent > 100 {
            percent = 100
        }

        // อัปเดตค่าที่แสดงใน TextField
        sender.text = String(format: "%.0f", percent)

        let discountAmount = calculatePercentage(
            value: orderTotal,
            percent: percent
        )

        self.mTaxDiscountAmounts.text = String(format: "%.2f", discountAmount)

        calculateItemsWithAmount()
    }
    
    @IBAction func mEditTaxDiscountAmount(_ sender: UITextField) {
//        print("mEditTaxDiscountAmount")
//        let grandTotal = Double(self.mGrandTotalAmounts) ?? 0
        let shipping = Double(self.mTaxShippingCharge.text ?? "") ?? 0
        let grandTotal = (Double(self.mGrandTotalAmounts) ?? 0) + shipping
//        print("mEditTaxDiscountAmount grandTotal = \(grandTotal)")
        var discount = Double(sender.text ?? "") ?? 0
//        print("mEditTaxDiscountAmount discount = \(discount)")
        if discount < 0 {
            discount = 0
        }

        if discount > grandTotal {
            discount = grandTotal
        }

//        sender.text = String(format: "%.2f", discount)
//        print("mEditTaxDiscountAmount sender.text = \(String(describing: sender.text))")

        let percent = grandTotal == 0
            ? 0
            : (discount / grandTotal) * 100

        self.mTaxDiscountPercents.text = String(format: "%.2f", percent)
//        print("mEditTaxDiscountAmount self.mTaxDiscountPercents.text = \(String(describing: self.mTaxDiscountPercents.text))")

        calculateItemsWithAmount()
    }
    
    private func updateProductPrice(_ cell: CustomCartItems, price: Double) {

        let currency = UserDefaults.standard.string(forKey: "currencySymbol") ?? "$"

        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.minimumFractionDigits = 2
        formatter.maximumFractionDigits = 2

        let priceText = formatter.string(from: NSNumber(value: price)) ?? "0.00"

        let attr = NSMutableAttributedString()

        attr.append(
            NSAttributedString(
                string: "\(currency) ",
                attributes: [
                    .foregroundColor: UIColor.black,
                    .font: UIFont(name: "SegoeUI", size: 14)!
                ]
            )
        )

        attr.append(
            NSAttributedString(
                string: priceText,
                attributes: [
                    .foregroundColor: UIColor(named: "themeColor") ?? .systemTeal,
                    .font: UIFont(name: "SegoeUI", size: 14)!
                ]
            )
        )

        cell.mProductPrice.attributedText = attr
    }
    
    private func updateCartData(
        at index:Int,
        price:Double,
        discountPercent:Double,
        discountAmount:Double
    ){

        guard let oldData = mCartData[index] as? NSDictionary,
              let data = oldData.mutableCopy() as? NSMutableDictionary else {
            return
        }

        data["price"] = price
        data["discount_percent"] = String(format:"%.2f",discountPercent)
        data["Discount_Amount"] = String(format:"%.2f",discountAmount)

        if let exist = oldData["Service_labour_exsist"] as? Bool{

            data["Service_labour_exsist"] = exist

            if exist,
               let labour = oldData["Service_labour"] as? NSDictionary{

                data["Service_labour"] = labour
            }

        }else{

            data["Service_labour_exsist"] = false
        }

        if oldData["stock_id_options"] == nil{
            data["stock_id_options"] = []
        }

        mCartData[index] = data
        
        print("========== UPDATE CART ==========")
        print("price =", data["price"] ?? "")
        print("cart_price =", data["cart_price"] ?? "")
        print("Discount_Amount =", data["Discount_Amount"] ?? "")
        print("discount_percent =", data["discount_percent"] ?? "")
        print("=================================")
    }
    
    private func resetDiscount(
        cell:CustomCartItems,
        index:Int
    ){

        let price = mCartAmount[index]

        cell.mDiscountPercent.text = ""
        cell.mDiscountAmount.text = ""

        updateProductPrice(cell, price: price)

        updateCartData(
            at: index,
            price: price,
            discountPercent: 0,
            discountAmount: 0
        )

        calculateItemsWithAmount()
    }
    
    private func clearTaxFields() {
        mTaxLabourCharge.text = ""
        mTaxShippingCharge.text = ""
        mTaxLoyaltyPoint.text = ""
        mTaxDiscountAmounts.text = ""
        mTaxDiscountPercents.text = ""
    }
    
    @IBAction func mEditDiscount(_ sender: UITextField) {
        
        clearTaxFields()
        let mIndexPath = IndexPath(row:sender.tag,section: 0)
        
        print("sender.tag =", sender.tag)
        print("mCartAmount =", mCartAmount)
        print("mCartData.count =", mCartData.count)
        
        if sender.text == "" {

            guard let cell = self.mCartTable.cellForRow(at: mIndexPath) as? CustomCartItems else {
                return
            }

            sender.placeholder = "0.00"

            resetDiscount(
                cell: cell,
                index: sender.tag
            )

            return
        }else{
            guard let cell = self.mCartTable.cellForRow(at: mIndexPath) as? CustomCartItems else {
                return
            }
            
            let price = self.mCartAmount[sender.tag]
            print("Original Price =", price)
            var percent = Double(sender.text ?? "") ?? 0
            
            // จำกัด 0...100
            percent = min(max(percent, 0), 100)
            
            // ถ้าผู้ใช้พิมพ์เกิน 100 ให้แก้ textbox กลับ
            if percent != (Double(sender.text ?? "") ?? 0) {
                sender.text = String(format: "%.0f", percent)
            }
            
            // ถ้าเป็น 0 ให้รีเซ็ต
            if percent == 0 {
                
                resetDiscount(cell: cell, index: sender.tag)
                
                return
            }
            
//            let discountAmount = price * percent / 100
//
//            let finalPrice = price - discountAmount
//            
//            print("Percent =", percent)
//            print("Discount =", discountAmount)
//            print("Final =", finalPrice)
//
//            updateProductPrice(cell, price: finalPrice)

//            cell.mDiscountAmount.text = String(format: "%.2f", discountAmount)
            
            let discountAmount = price * percent / 100
            let finalPrice = price - discountAmount

            // Sync Discount Amount
            if cell.mDiscountAmount.isEditing == false {
                cell.mDiscountAmount.text = String(format: "%.2f", discountAmount)
            }

            updateProductPrice(cell, price: finalPrice)

            updateCartData(
                at: sender.tag,
                price: finalPrice,
                discountPercent: percent,
                discountAmount: discountAmount
            )

            calculateItemsWithAmount()

            updateCartData(
                at: sender.tag,
                price: finalPrice,
                discountPercent: percent,
                discountAmount: discountAmount
            )

            calculateItemsWithAmount()
            
        }
       
    }
    
    @IBAction func mEditDiscountAmount(_ sender: UITextField) {
        clearTaxFields()
    
        let mIndexPath = IndexPath(row:sender.tag,section: 0)

        if sender.text == "" {

            guard let cell = self.mCartTable.cellForRow(at: mIndexPath) as? CustomCartItems else {
                return
            }

            sender.placeholder = "0.00"

            resetDiscount(
                cell: cell,
                index: sender.tag
            )

            return
        }
        
        if sender.text == "0" {
            sender.text = ""
        }
        
            
            guard let cell = self.mCartTable.cellForRow(at: mIndexPath) as? CustomCartItems else {
                return
            }

            let originalPrice = self.mCartAmount[sender.tag]

            var discount = Double(sender.text ?? "") ?? 0

            // ไม่ให้ติดลบ
            discount = max(0, discount)

            // ไม่ให้เกินราคาสินค้า
            if discount > originalPrice {

                discount = originalPrice

//                sender.text = String(format: "%.2f", originalPrice)
                
                cell.mDiscountAmount.text = sender.text
            }
//            cell.mDiscountAmount.text =
//                String(format: "%.2f", discount)
            // ถ้าเป็น 0 ให้รีเซ็ต
            if discount == 0 {

                resetDiscount(cell: cell, index: sender.tag)

                return
            }

//            let percent = originalPrice == 0
//                ? 0
//                : (discount / originalPrice) * 100
//
//            let finalPrice = originalPrice - discount

//            cell.mDiscountPercent.text =
//                String(format: "%.2f", percent)
        let percent = originalPrice == 0
            ? 0
            : (discount / originalPrice) * 100

        let finalPrice = originalPrice - discount

        // Sync Discount %
        if cell.mDiscountPercent.isEditing == false {
            cell.mDiscountPercent.text = String(format: "%.2f", percent)
        }

        updateProductPrice(
            cell,
            price: finalPrice
        )

        updateCartData(
            at: sender.tag,
            price: finalPrice,
            discountPercent: percent,
            discountAmount: discount
        )

        calculateItemsWithAmount()
            updateProductPrice(
                cell,
                price: finalPrice
            )

            updateCartData(
                at: sender.tag,
                price: finalPrice,
                discountPercent: percent,
                discountAmount: discount
            )

            calculateItemsWithAmount()
        
    
    }
    
    
    @IBAction func mShowTax(_ sender: UIButton) {
         sender.isSelected = !sender.isSelected
         if sender.isSelected {
            mUpForwardIcon.image = UIImage(named: "top_ic")
            UIView.animate(withDuration: 1.0) {
                self.mTaxView.isHidden = false
                self.view.layoutIfNeeded() }
        }else{
            mUpForwardIcon.image = UIImage(named: "forward_ic")
             UIView.animate(withDuration: 1.0) {
                self.mTaxView.isHidden = true
                self.view.layoutIfNeeded()
            }
        }

        
    }
   
    @IBAction func mOpenProductStoneDetails(_ sender: UIButton) {
        let mIndex = sender.tag
        let mData = mCartData[mIndex] as? NSDictionary
        if let mPoProductId = mData?.value(forKey: "po_product_id") as? String {
            if mPoProductId != "" {
                let storyBoard: UIStoryboard = UIStoryboard(name: "common", bundle: nil)
                if let home = storyBoard.instantiateViewController(withIdentifier: "SKUProductSummary") as? SKUProductSummary{
                    home.mKey = mPoProductId
                    home.modalPresentationStyle = .automatic
                    home.transitioningDelegate = self
                    self.present(home,animated: true)
                }
            }
        }

      
    }
    
    

    override func viewWillDisappear(_ animated: Bool) {

    }
    
    func mClearCart() {
        print("🔥 POSCart.swift mClearCart called")
        mGetData(
            url: mClearDataApi,
            headers: sGisHeaders,
            params: [:]
        ) { response, status in

            if status,
               "\(response["code"] ?? "")" == "200" {

                self.mFetchCartItems()
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        mUserLoginToken = UserDefaults.standard.string(forKey: "token")
        mUserLoginTokenPos = UserDefaults.standard.string(forKey: "token_pos")
        
        mTaxAmountLABEL.text = "TAX (Amount)".localizedString
        mTaxPercentLABEL.text = "TAX (%)".localizedString
        mTaxSubTotalLABEL.text = "Sub Total".localizedString
        mDiscountAmountLABEL.text = "Discount (Amount)".localizedString
        mDiscountPercentLABEL.text = "Discount (%)".localizedString
        mTaxShippingLABEL.text = "Shipping".localizedString
        mTaxLoyaltyPointLABEL.text = "Loyalty point".localizedString
        mTaxLabourLABEL.text = "Labour".localizedString
        mTaxTotalLABEL.text = "Total".localizedString
        mCheckOutBUTTON.setTitle("CHECK OUT".localizedString, for: .normal)
        mParkBUTTON.setTitle("PARK".localizedString, for: .normal)
        mHeadingLABEL.text = "POS".localizedString
        mNoteLABEL.text = "Note".localizedString
        mGrandTotalLABEL.text = "Grand Total".localizedString
 
        mTotalItems.text = "0 " + "Item".localizedString
        mSearchField.placeholder = "Search by SKU / Stock ID".localizedString
        mNotes.placeholder = "EX. Urgent Order".localizedString
        
        
        
        if UserDefaults.standard.string(forKey: "cRemark") != nil {
            self.mNotes.text = "\(UserDefaults.standard.string(forKey: "cRemark") ?? "")"
        }
        
        mCustomerId  = UserDefaults.standard.string( forKey: "DEFAULTCUSTOMER") ?? ""
        if mCustomerId == "" {
            mOpenCustomerSheet()
        }else{
            if let clearCart = UserDefaults.standard.string(forKey: "mClearCart"),
               clearCart == "mClearCart" {

                UserDefaults.standard.setValue("", forKey: "mClearCart")
                mClearCart()
                self.mCheckAddresse()
                self.mSelectedCustomerIcon.image = UIImage(named: "selected_customer")

            } else {

                self.mCheckAddresse()
                self.mSelectedCustomerIcon.image = UIImage(named: "selected_customer")
                mFetchCartItems()
            }
//            if(UserDefaults.standard.value(forKey: "mClearCart") ?? "$" == "mClearCart"){
//                UserDefaults.standard.setValue("", forKey: "mClearCart")
//                mClearCart()
//                self.mCheckAddresse()
//                self.mSelectedCustomerIcon.image = UIImage(named: "selected_customer")
//            }
//            else {
//                self.mCheckAddresse()
//                self.mSelectedCustomerIcon.image = UIImage(named: "selected_customer")
//                mFetchCartItems()
//            }
            
            
        }
        
        let mParams = ["query":"{stones{id name}colors{id name}metals{id name}shapes{id name}claritys{id name}cuts{id name}sizes{id name}settingType{id name}stonecolors{id name}}"]
        AF.request(mGrapQlUrl, method:.post,parameters: mParams, encoding:JSONEncoding.default, headers: sGisHeaders).responseJSON
        {response in
     
            if(response.error != nil) {
                UserDefaults.standard.set(nil, forKey: "GRAPHQL")
            }else{
                if let jsonData = response.data {
                    let json = try? JSONSerialization.jsonObject(with: jsonData, options: [])
                    if let jsonResult = json as? NSDictionary {
                        UserDefaults.standard.set(jsonResult, forKey: "GRAPHQL")
                    }
                }
            }
        }
        
        
        AF.request(mGetShapes, method:.post,parameters: nil, headers: sGisHeaders).responseJSON { response in

            if(response.error != nil) {
                UserDefaults.standard.set(nil, forKey: "SHAPES")

            }else{
                if let jsonData = response.data {
                    let json = try? JSONSerialization.jsonObject(with: jsonData, options: [])
                    if let jsonResult = json as? NSDictionary {
                        
                        UserDefaults.standard.set(jsonResult, forKey: "SHAPES")
                    }
                }
            }
        }
        
        let isPark = UserDefaults.standard.bool(forKey: "isPark")
        if isPark {
            self.mParkButtonView.isHidden = false
            mGetParkStatus()
        }else{
            self.mAvailableParkView.isHidden = true
            self.mParkButtonView.isHidden = true
        }
   
    }
    
    func mGetParkStatus(){
        print("mGetParkStatus ")
        mUserLoginToken = UserDefaults.standard.string(forKey: "token")
        mUserLoginTokenPos = UserDefaults.standard.string(forKey: "token_pos")
        
        mGetData(url: mGetPark,headers: sGisHeaders,  params: ["":""]) { response , status in
                if status {
                    print("mGetParkStatus response = ",response)
                    if let mData = response.value(forKey: "data") as? NSArray {
                        print("mGetParkStatus mData = ",mData)
                        
                        self.mParkedStockIds.removeAll()

                        for item in mData {

                            guard let park = item as? NSDictionary else { continue }

                            if let status = park["status"] as? NSDictionary,
                               "\(status["is_park"] ?? "0")" == "1",
                               let cart = park["cart"] as? NSArray {

                                for obj in cart {

                                    if let product = obj as? NSDictionary {

                                        let stockId = "\(product["stock_id"] ?? "")"

                                        self.mParkedStockIds.insert(stockId)

                                    }

                                }

                            }

                        }
                        
                        UserDefaults.standard.set(
                            Array(self.mParkedStockIds),
                            forKey: "ParkedStockIds"
                        )

                        print("DEBUG_PARKED_STOCK =", self.mParkedStockIds)
//                        self.calculateItemsWithAmount()
                        if mData.count > 0 {
                            self.mAvailableParkView.isHidden = false
                            self.mParkCount.text = "\(mData.count)"
                        }else{
                            self.mAvailableParkView.isHidden = true

                        }
                    }
                }else{
                    self.mAvailableParkView.isHidden = true

                }
        }
    }
//    func mGetSearchItems(id: String) {
//    func mGetSearchItems(id: String, locationId: String) {
    func mGetSearchItems(
        id: String,
        locationId: String,
        type: String
    ) {
        var mParams = [String : Any]()
        

            mParams = ["product_id":[id], "customer_id":mCustomerId, "sales_person_id":"", "type":"inventory", "order_type":"pos_order"]
        
        mUserLoginToken = UserDefaults.standard.string(forKey: "token")
        mUserLoginTokenPos = UserDefaults.standard.string(forKey: "token_pos")
//        let stockId = "\(product["stock_id"] ?? "")"
//        if mParkedStockIds.contains(stockId) {
//
//            CommonClass.showSnackBar(message: "This stock is already parked")
//            return
//
//        }
        
        CommonClass.showFullLoader(view: self.view)
        self.tabBarController?.tabBar.isUserInteractionEnabled = false
        mGetData(url: mAddCustomProduct,headers: sGisHeaders,  params: mParams) { response , status in
//            CommonClass.stopLoader()
            if status {
                if "\(response.value(forKey: "code") ?? "")" == "200" {
                    
                    self.mFetchCartItems()

                }else{
                    CommonClass.stopLoader()
                    self.tabBarController?.tabBar.isUserInteractionEnabled = true
                }
            }
            else{
                CommonClass.stopLoader()
                self.tabBarController?.tabBar.isUserInteractionEnabled = true
            }
    }

    }
    
    @IBAction func mSearchnow(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Test", bundle: nil)
        if let mCommonSearch = storyBoard.instantiateViewController(withIdentifier: "CommonSearch") as? CommonSearch {
            mCommonSearch.modalPresentationStyle = .overFullScreen
            mCommonSearch.delegate = self
            mCommonSearch.mType = "inventory"
            mCommonSearch.mFrom = "pos"
            
            mCommonSearch.transitioningDelegate = self
            self.present(mCommonSearch,animated: false)
        }
    }
    
    @IBAction func mSearchCart(_ sender: Any) {
                
           
    }
    
    
    @IBAction func mOpenCustomer(_ sender: Any) {
      
         mOpenCustomerSheet()
    }
    
    
    @IBAction func mOpenAddressPicker(_ sender: Any) {
        mOpenAddressPicker()
    }
    
    @IBAction func mBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)

     }

    @IBAction func mCatalog(_ sender: Any) {
        if mCustomerId == "" {
            CommonClass.showSnackBar(message: "Please choose customer first!")
            mOpenCustomerSheet()
            return
        }
        let storyBoard: UIStoryboard = UIStoryboard(name: "common", bundle: nil)
        if let mFilters = storyBoard.instantiateViewController(withIdentifier: "CommonCatalog") as? CommonCatalog {
            mFilters.mOrderType = "pos_order"
            
            print("PosCart.swift withIdentifier: CommonCatalog")
            mFilters.modalPresentationStyle = .overFullScreen
            mFilters.transitioningDelegate = self
            self.present(mFilters,animated: true)
        }
    }
    
//    func mGetInventoryItems(items: [String]) {
//
//        mFetchCartItems()
//    }
//    
//    
//  
//    func mFetchCartItems(){
// 
//        let mParams = [ "customer_id":mCustomerId ] as [String : Any]
//        
//        
//        mUserLoginToken = UserDefaults.standard.string(forKey: "token")
//        mUserLoginTokenPos = UserDefaults.standard.string(forKey: "token_pos")
//        
//        mGetData(url: mFetchCustomProduct, headers:sGisHeaders ,params: mParams) { response , status in
//            CommonClass.stopLoader()
//            if status {
//            if "\(response.value(forKey: "code") ?? "")" == "200" {
//                if let mData = response.value(forKey: "data") as? NSArray, mData.count > 0 {
//                    print("DEBUG_CART_RESPONSE PosCart.swift = \(mData)")
//                        self.mCartDataMaster = mData
//                        self.mCartData = NSMutableArray(array: mData)
//                        self.mCartTable.delegate = self
//                        self.mCartTable.dataSource = self
//                        self.mQuantityData = [Int]()
//                        self.mCartAmount = [Double]()
//
//                        self.mCartTable.reloadData()
//                        for i in self.mCartData {
//                            if let mData = i as? NSDictionary {
//                                self.mQuantityData.append(Int("\(mData.value(forKey: "Qty") ?? "0")") ?? 0)
//                                self.mCartAmount.append(Double("\(mData.value(forKey: "price") ?? "0")") ?? 0.0)
//                            }
//                        }
//                
//                }
//            }else{
//          
//            }
//        }
//    }
//    }
    
    func mGetInventoryItems(items: [String]) {

        print("========== DELEGATE CALLBACK ==========")
        print("mGetInventoryItems CALLED")
        print("ITEMS =", items)
        print("CUSTOMER ID =", mCustomerId)
        print("=======================================")

        mFetchCartItems()
    }


    func mFetchCartItems() {

        let mParams = [
            "customer_id": mCustomerId
        ] as [String : Any]

        mUserLoginToken = UserDefaults.standard.string(forKey: "token")
        mUserLoginTokenPos = UserDefaults.standard.string(forKey: "token_pos")

        print("========== FETCH CART REQUEST ==========")
        print("URL =", mFetchCustomProduct)
        print("PARAMS =", mParams)
        print("CUSTOMER ID =", mCustomerId)
        print("========================================")
        
        mGetData(
            url: mFetchCustomProduct,
            headers: sGisHeaders,
            params: mParams
        ) { response, status in

//            CommonClass.stopLoader()
            DispatchQueue.main.async {
                self.mCartTable.reloadData()
                self.calculateItemsWithAmount()
                CommonClass.stopLoader()
                self.tabBarController?.tabBar.isUserInteractionEnabled = true
            }

            print("========== FETCH CART RESPONSE ==========")
            print("STATUS =", status)
            print("FULL RESPONSE =", response)
            print("=========================================")

            if status {

                let code = "\(response.value(forKey: "code") ?? "")"

                print("FETCH CART CODE =", code)

                if code == "200" {

                    if let mData = response.value(forKey: "data") as? NSArray {

                        print("CART ITEM COUNT =", mData.count)
                        print("CART DATA =", mData)
                        
                        

                        if mData.count > 0 {

                            self.mCartDataMaster = mData
                            self.mCartData = NSMutableArray(array: mData)

                            self.mCartTable.delegate = self
                            self.mCartTable.dataSource = self

                            self.mQuantityData = [Int]()
                            self.mCartAmount = [Double]()

                            for item in self.mCartData {

                                if let data = item as? NSDictionary {

                                    print("price =", data["price"] ?? "")
                                    print("cart_price =", data["cart_price"] ?? "")
                                    print("discount =", data["discount"] ?? "")
                                    print("discount_amount =", data["discount_amount"] ?? "")
                                    print("discount_price =", data["discount_price"] ?? "")
                                    print("final_price =", data["final_price"] ?? "")
                                    print("delivery_date", data["delivery_date"] ?? "")
                                    
                                    let sku =
                                        "\(data.value(forKey: "SKU") ?? data.value(forKey: "sku") ?? "")"

                                    let productId =
                                        "\(data.value(forKey: "product_id") ?? "")"

                                    let poProductId =
                                        "\(data.value(forKey: "po_product_id") ?? "")"

                                    let qty =
                                        Int("\(data.value(forKey: "Qty") ?? "0")") ?? 0

//                                    let price =
//                                        Double("\(data.value(forKey: "price") ?? "0")") ?? 0.0
                                    
                                    let price =
                                        Double("\(data.value(forKey: "cart_price") ?? "0")") ?? 0.0

                                    print("---------- CART ITEM ----------")
                                    print("SKU =", sku)
                                    print("product_id =", productId)
                                    print("po_product_id =", poProductId)
                                    print("Qty =", qty)
                                    print("price =", price)
                                    print("-------------------------------")
                                    let rawPrice = data.value(forKey: "cart_price")

                                    print("RAW PRICE =", rawPrice ?? "nil")
                                    print("RAW TYPE =", type(of: rawPrice))

                                    let pricee =
                                        Double("\(rawPrice ?? "0")") ?? 0.0
                                    print("-------------------------------")
                                    print("PARSED PRICE =", pricee)
                                    self.mQuantityData.append(qty)
                                    self.mCartAmount.append(price)
                                }
                            }

                            DispatchQueue.main.async {
                                self.mCartTable.reloadData()
                                self.calculateItemsWithAmount()
                            }

                        } else {

                            print("🚨 FETCH CART SUCCESS BUT DATA IS EMPTY")
                        }

                    } else {

                        print("🚨 FETCH CART DATA IS NOT NSArray")
                        print("DATA TYPE =", type(of: response.value(forKey: "data")))
                    }

                } else {

                    print("🚨 FETCH CART CODE IS NOT 200")
                }

            } else {

                print("🚨 FETCH CART REQUEST FAILED")
            }
        }
    }
    
    func uniqueElementsFrom(array:[String]) -> [String] {
        
        var set = Set<String>()
        
        let result = array.filter {
            guard !set.contains($0)  else {
                return false
            }
            set.insert($0)
            return true
        }
        
        return result
    }
    @IBAction func mInventory(_ sender: Any) {

        if mCustomerId == "" {
            CommonClass.showSnackBar(
                message: "Please choose customer first!"
            )
            mOpenCustomerSheet()
            return
        }

        let storyBoard = UIStoryboard(
            name: "common",
            bundle: nil
        )

        if let mInv = storyBoard.instantiateViewController(
            withIdentifier: "CommonInventory"
        ) as? CommonInventory {

            mInv.modalPresentationStyle = .overFullScreen

            mInv.delegate = self
            mInv.mCustomerId = mCustomerId

            // สำคัญ
            mInv.mOrderType = "pos_order"

            mInv.transitioningDelegate = self

            self.present(
                mInv,
                animated: true
            )
        }
    }
    
    @IBAction func mCustomer(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "reserveBoard", bundle: nil)
        if let home = storyBoard.instantiateViewController(withIdentifier: "CustomerSearch") as? CustomerSearch {
            self.navigationController?.pushViewController(home, animated:true)
        }
    }
    
    func mCreateNewCustomer() {
        let storyBoard: UIStoryboard = UIStoryboard(name: "reserveBoard", bundle: nil)
        if let mCreateCustomer = storyBoard.instantiateViewController(withIdentifier: "CreateCustomer") as? CreateCustomer {
            self.navigationController?.pushViewController(mCreateCustomer, animated:true)
        }
    }
    func mGetCustomerData(data: NSMutableDictionary) {
       
        UserDefaults.standard.set(data.value(forKey: "id") ?? "", forKey: "DEFAULTCUSTOMER")
        UserDefaults.standard.set(data.value(forKey: "profile") ?? "", forKey: "DEFAULTCUSTOMERPICTURE")
        UserDefaults.standard.set(data.value(forKey: "name") ?? "", forKey: "DEFAULTCUSTOMERNAME")

        self.mCustomerId = data.value(forKey: "id") as? String ?? ""
        self.mSelectedCustomerIcon.image = UIImage(named: "selected_customer")
        
        UserDefaults.standard.setValue(nil, forKey: "CustomerBillingAddressUDID")
        UserDefaults.standard.setValue(nil, forKey: "CustomerShippingAddressUDID")
        
        if let haveAddresses = data.value(forKey: "haveAddresses") as? Bool, haveAddresses {
            mAddressPickerIcon.image = UIImage(named: "address_pick_ic_green")
            mAddressAlertIcon.isHidden = true
        } else {
            mAddressPickerIcon.image = UIImage(named: "address_pick_ic_green")
            mAddressAlertIcon.isHidden = false
        }
        
        mFetchCartItems()

    }
    
    func mCheckAddresse() {
        
        guard Reachability.isConnectedToNetwork() == true else {
            return
        }
        
        let params = ["id": mCustomerId] as [String : Any]
        
        AF.request(mCheckAddress, method:.post,parameters: params,encoding: JSONEncoding.default, headers: sGisHeaders).responseJSON { response in
            
            guard let jsonData = response.data else {
                return
            }
            
            do {
                if let json = try JSONSerialization.jsonObject(with: jsonData, options: []) as? [String: Any],
                   let code = json["code"] as? Int {
                    switch code {
                    case 200:
                        if let haveAddress = json["AddressExists"] as? Bool, haveAddress {
                            self.mAddressPickerIcon.image = UIImage(named: "address_pick_ic_green")
                            self.mAddressAlertIcon.isHidden = true
                        } else {
                            self.mAddressPickerIcon.image = UIImage(named: "address_pick_ic_green")
                            self.mAddressAlertIcon.isHidden = false
                        }
                    case 403:
                        CommonClass.sessionExpired(isExpired: true, navigation: self.navigationController)
                    default:
                        break
                    }
                }
            } catch {
            }
        }
        
    }
    
    func mOpenCustomerSheet(){
        let storyBoard: UIStoryboard = UIStoryboard(name: "common", bundle: nil)
        if let home = storyBoard.instantiateViewController(withIdentifier: "CustomerPicker") as? CustomerPicker {
            home.delegate = self
            home.modalPresentationStyle = .automatic
            home.transitioningDelegate = self
            self.present(home,animated: true)
        }
    }
    
    func mOpenAddressPicker(){
        if !mCustomerId.isEmpty {
            let storyBoard: UIStoryboard = UIStoryboard(name: "AddressPicker", bundle: nil)
            if let addressPicker = storyBoard.instantiateViewController(withIdentifier: "AddressPicker") as? AddressPicker {
                addressPicker.delegate = self
                addressPicker.mCustomerId = mCustomerId
                self.navigationController?.pushViewController(addressPicker, animated: true)
            }
        }
    }
    
    func mGetAddress(data: NSMutableDictionary) {
        
    }
    
    @IBAction func mDepositeDropdown(_ sender: Any) {
        let dropdown = DropDown()
               dropdown.anchorView = self.mDepositePercent
               dropdown.direction = .any
               dropdown.bottomOffset = CGPoint(x: 0, y: self.mDepositePercent.frame.size.height)
               dropdown.width = 120
               dropdown.dataSource = mDepositPercentData
               dropdown.selectionAction = {
               [unowned self](index:Int, item: String) in
               self.mDepositePercent.text  = item
                self.mDepositPercents = self.mDepositPercentValue[index]
                   if self.mCartData.count > 0{
                   self.calculateItemsWithAmount()
                   }
                   
              }
               dropdown.show()
    }
    
    
    @IBAction func mCheckOut(_ sender: UIButton) {
            sender.showAnimation{
                
                if self.mCartData.count == 0 {
                    CommonClass.showSnackBar(message: "No items in cart!")
                    return
                }
                if Double(self.mTotalDepositAmounts) ?? 0.00 == 0.0 {
                    CommonClass.showSnackBar(message: "Please fill valid amount!")
                    return
                }
                
                guard self.mAddressAlertIcon.isHidden else {
                    CommonClass.showSnackBar(message: "Add Billing and Shipping address")
                    return
                }
                
                // ✨ แนบ Quotation ID ลง UserDefaults ✨
                // ใน PosCart บางทีไม่มีตัวแปร mQuotationId ให้ส่งค่าว่างเพื่อเคลียร์ของเก่า
                UserDefaults.standard.setValue("", forKey: "quotationId")
                
                let storyBoard: UIStoryboard = UIStoryboard(name: "laybyInstallment", bundle: nil)
                guard let mCheckOut = storyBoard.instantiateViewController(withIdentifier: "POSCheckout") as? POSCheckout else { return }
                mCheckOut.mTotalP = self.mTotalDepositAmounts
                
                // ... (โค้ดเดิมด้านล่าง) ...
                mCheckOut.mSubTotalP = String(format: "%.2f", self.mCalculatedSubTotal)
                mCheckOut.mTaxAm = String(format: "%.2f", self.mCalculatedTaxAmount)
//                mCheckOut.mSubTotalP = ""
                mCheckOut.mTaxP = ""
//                mCheckOut.mTaxAm = ""
                mCheckOut.mStoreCurrency =  self.mCurrency
                mCheckOut.mOrderType = "pos_order"
                mCheckOut.mNote = self.mNotes.text ?? ""
                print("DEBUG_cRemark = \(UserDefaults.standard.string(forKey: "cRemark") ?? "nil")")
                print("DEBUG_mNotes = \(self.mNotes.text ?? "nil")")
                mCheckOut.mRemark = UserDefaults.standard.string(forKey: "cRemark") ?? ""
//                mCheckOut.mRemark = self.mNotes.text ?? ""
                mCheckOut.mTotalOutstandingAm = self.mOutStandingAmounts
                mCheckOut.mCurrencySymbol = self.mCurrency
//                mCheckOut.mCartTotalAmount = self.mGrandTotalCart
                print("mGrandTotalCart =", self.mGrandTotalCart)
                print("mTotalDepositAmounts =", self.mTotalDepositAmounts)
                mCheckOut.mCartTotalAmount = self.mTotalDepositAmounts
//                mCheckOut.mCartTotalAmount = self.mGrandTotalCart

                mCheckOut.mDepositPercents = self.mDepositPercents
                mCheckOut.mTotalWithDiscount =  self.mTotalDepositAmounts
                
                mCheckOut.mLabourPoints = Double(self.mTaxLabourCharge.text ?? "") ?? 0.00
                mCheckOut.mShippingPoints = Double(self.mTaxShippingCharge.text ?? "") ?? 0.00
                mCheckOut.mLoyaltyPoints = Double(self.mTaxLoyaltyPoint.text ?? "") ?? 0.00
                mCheckOut.mTaxAmount = Double(self.mTaxAmount.text?.replacingOccurrences(of: ",", with: "") ?? "") ?? 0.0
                mCheckOut.mTaxAmountInt = Double(self.mTaxAmount.text?.replacingOccurrences(of: ",", with: "") ?? "") ?? 0.0
                mCheckOut.mTaxInPercent = Double(self.mTaxValue.text ?? "") ?? 0.0
                mCheckOut.mTaxDiscountAmount = Double(self.mTaxDiscountAmounts.text ?? "") ?? 0.0
                mCheckOut.mTaxDiscountPercent = Double(self.mTaxDiscountPercents.text ?? "") ?? 0.0
                
                mCheckOut.mTaxTypeIE = UserDefaults.standard.string(forKey: "taxType") ?? ""
                mCheckOut.mCustomerId = self.mCustomerId
                mCheckOut.mCartTableData =  self.mCartData
                
                self.navigationController?.pushViewController( mCheckOut, animated:true)
            }
        }

    func mUpdateCartProduct(newStockId: String,qty: Int , index: Int){
        
        guard let mData = mCartData[index] as? NSDictionary,
        let cartId = mData.value(forKey: "custom_cart_id") as? String,
        let oldStockId = mData.value(forKey: "stock_id") as? String else { return }
        
        let mParams = [ "cart_id": cartId, "old_stockId": oldStockId, "new_stockId": newStockId, "qty": qty ] as [String : Any]
    
        mUserLoginToken = UserDefaults.standard.string(forKey: "token")
        mUserLoginTokenPos = UserDefaults.standard.string(forKey: "token_pos")
        
        mGetData(url: mStockIdManage, headers:sGisHeaders ,params: mParams) { response , status in
            CommonClass.stopLoader()
            if status {
            if "\(response.value(forKey: "code") ?? "")" == "200" {
                self.mFetchCartItems()
            }else{
                CommonClass.showSnackBar(message: "Oop! Something went wrong!")
            }
        }
        }
    }
    
    @IBAction func mPickStockId(_ sender: UIButton) {
        guard let mCartDatas = mCartData[sender.tag] as? NSDictionary else { return }
        if let mCartItems = mCartDatas.value(forKey: "stock_id_options") as? NSArray {
            if mCartItems.count < 1 {
                return
            }
            
            var mStockIds = [String]()
            for i in mCartItems {
                if let data = i as? NSDictionary {
                    mStockIds.append("\(data.value(forKey: "value") ?? "")")
                }
            }

            let dropdown = DropDown()
            dropdown.anchorView = sender
            dropdown.direction = .any
            dropdown.bottomOffset = CGPoint(x: 0, y: sender.frame.size.height)
            dropdown.width = 200
            dropdown.dataSource = mStockIds
            dropdown.selectionAction = {
                [unowned self](index:Int, item: String) in
                let cell1 = mCartTable.cellForRow(at: IndexPath(row: sender.tag, section: 0)) as? CustomCartItems
               
                mUpdateCartProduct(newStockId: item, qty: mCartDatas.value(forKey: "Qty") as? Int ?? 0 , index: sender.tag)
                cell1?.mStockId.text = item
                
                guard let mInvData = self.mCartData[sender.tag] as? NSDictionary,
                      let mData = mInvData.mutableCopy() as? NSMutableDictionary else { return }

                mData.setValue(item, forKey: "stock_id")

                if let mServiceLabourStatus =  mInvData.value(forKey: "Service_labour_exsist") as? Bool {
                    mData.setValue(mServiceLabourStatus, forKey: "Service_labour_exsist")
                    if mServiceLabourStatus, let mServiceLabour = mInvData.value(forKey: "Service_labour") as? NSDictionary {
                        mData.setValue(mServiceLabour, forKey: "Service_labour")
                    }
                } else {
                    mData.setValue(false, forKey: "Service_labour_exsist")
                }

                if mInvData.value(forKey: "stock_id_options") == nil {
                    mData.setValue([], forKey: "stock_id_options")
                }

                self.mCartData.removeObject(at: sender.tag)
                self.mCartData.insert(mData, at: sender.tag)
                self.calculateItemsWithAmount()
            }
            dropdown.show()
        }
        
    }
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return mCartData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        tableView.showsVerticalScrollIndicator = false
        tableView.showsHorizontalScrollIndicator = false

        guard let cell = tableView.dequeueReusableCell(withIdentifier: "CustomCartItems") as? CustomCartItems else {
            return UITableViewCell()
        }
        
        cell.mSNo.text = "\(indexPath.row + 1)"
        cell.mOpenProductDetailsButton.tag = indexPath.row
        cell.mRemoveButton.tag = indexPath.row
        
        cell.mPickStockId.tag = indexPath.row
        cell.mProductPrice.tag = indexPath.row
        cell.mPlusButton.tag = indexPath.row
        cell.mMinusButton.tag = indexPath.row
        cell.mDiscountAmount.tag = indexPath.row
        cell.mDiscountPercent.tag = indexPath.row
        cell.mEditServiceLabourButton.tag = indexPath.row
        cell.mShowServiceLabourButton.tag = indexPath.row

        guard let mData = mCartData[indexPath.row] as? NSDictionary else { return UITableViewCell() }
        
        let isServiceLabour = UserDefaults.standard.bool(forKey: "isServiceLabour")
        if isServiceLabour {
            if let mServiceLabourStatus =  mData.value(forKey: "Service_labour_exsist") as? Bool {
                mServiceLabourStatus ? (cell.mEditServiceLabourIcon.tintColor = UIColor(named:"themeColor")) : (cell.mEditServiceLabourIcon.tintColor = UIColor(named:"theme6A"))
                
                cell.mServiceLabourView.isHidden = false
                
                if mServiceLabourStatus {
                    
                    self.mTaxLabourCharge.isEnabled = false
                    if let mServiceLabour = mData.value(forKey: "Service_labour") as? NSDictionary {
                        if let mServiceItem = mServiceLabour.value(forKey: "service_laburelist") as? NSArray {
                            if mServiceItem.count > 0 {
                                cell.mServiceLabourCount.text = "Service Labour".localizedString + " (\(mServiceItem.count))"
                                var mAmounts = [Double]()
                                for i in mServiceItem {
                                    if let items = i as? NSDictionary {
                                        mAmounts.append(Double("\(items.value(forKey: "scrviceamount") ?? "0.0")".replacingOccurrences(of: ",", with: "")) ?? 0.00)
                                    }
                                }
                                cell.mServiceLabourCharges.text = self.mCurrency + " " + String(format:"%.02f",locale:Locale.current,mAmounts.reduce(0, {$0 + $1}))
                            }else{
                                self.mTaxLabourCharge.isEnabled = true
                                cell.mServiceLabourCharges.text = self.mCurrency + " 0.00"
                                cell.mServiceLabourCount.text = "Service Labour".localizedString + " (0)"
                            }
                        }
                    }
                    
                }else{
                    cell.mServiceLabourCharges.text = self.mCurrency + " 0.00"
                    cell.mServiceLabourCount.text = "Service Labour".localizedString + " (0)"
                }
            }else{
                cell.mServiceLabourView.isHidden = true
                self.mTaxLabourCharge.isEnabled = true
            }
        } else {
            cell.mServiceLabourView.isHidden = true
        }
        
        cell.mCurrency.text = "\(mData.value(forKey: "currency") ?? "$")"
        self.mCurrency = "\(mData.value(forKey: "currency") ?? "$") "
 
        cell.mSKUName.text = "\(mData.value(forKey: "SKU") ?? "")"
        cell.mDiscountAmount.text = "\(mData.value(forKey: "Discount_Amount") ?? "")"
        cell.mDiscountPercent.text = "\(mData.value(forKey: "discount_percent") ?? "")"
        cell.mProductName.text = "\(mData.value(forKey: "name") ?? "")"
        cell.mMetalColorSize.text = "\(mData.value(forKey: "color_name") ?? "") " + "\(mData.value(forKey: "metal_name") ?? "") " + "\(mData.value(forKey: "size_name") ?? "")"
        
        let priceValue = PriceHelper.unformatPrice(
            "\(mData.value(forKey: "price") ?? "0")"
        )

        let displayPrice = priceValue > 0
            ? priceValue
            : PriceHelper.unformatPrice(
                "\(mData.value(forKey: "cart_price") ?? "0")"
              )
        updateProductPrice(cell, price: displayPrice)
//        cell.mProductPrice.text = "\(mData.value(forKey: "price") ?? "")"
        
        cell.mStockId.text = "\(mData.value(forKey: "stock_id") ?? "")"
        
        cell.mProductImage.downlaodImageFromUrl(urlString: "\(mData.value(forKey: "main_image") ?? "")")
        cell.mProductImage.tag = indexPath.row
        cell.imageTapGesture(target: self, action: #selector(handleImageTap(_:)))
        
//        calculateItemsWithAmount()
        
        return cell
    }
    
    @objc func handleImageTap(_ sender: UITapGestureRecognizer) {
        guard let imageView = sender.view as? UIImageView else {
            return
        }
        let index = imageView.tag
        if let mData = mCartData[index] as? NSDictionary {
            let productId = "\(mData.value(forKey: "id") ?? "")"
            let sku = "\(mData.value(forKey: "SKU") ?? "")"
       
            mOpenGlobalImageViewer(mProductIdForImage: productId, mSKUForImage: sku)
        }
    }
    
    func mOpenGlobalImageViewer(mProductIdForImage: String , mSKUForImage: String){
        if mProductIdForImage != "" {
            let storyBoard: UIStoryboard = UIStoryboard(name: "Test", bundle: nil)
            if let mGlobalImageViewer = storyBoard.instantiateViewController(withIdentifier: "GlobalImageViewer") as? GlobalImageViewer {
                mGlobalImageViewer.modalPresentationStyle = .overFullScreen
                mGlobalImageViewer.mProductId = mProductIdForImage
                mGlobalImageViewer.mSKUName = mSKUForImage
                mGlobalImageViewer.transitioningDelegate = self
                self.present(mGlobalImageViewer,animated: false)
            }
        }
    }
    

    func mRemoveServiceLabour() {
        mFetchCartItems()
    }
    func mConfirmServiceLabour(data: NSDictionary) {
        mFetchCartItems()
    }
   
    
    @IBAction func mShowServiceLabour(_ sender: UIButton) {
        if let mData = self.mCartData[sender.tag] as? NSDictionary {
            
            if let mServiceData = mData.value(forKey: "Service_labour") as? NSDictionary {
                let storyBoard: UIStoryboard = UIStoryboard(name: "laybyInstallment", bundle: nil)
                if let mSelectedServiceLabour = storyBoard.instantiateViewController(withIdentifier: "SelectedServiceLabour") as? SelectedServiceLabour {
                    mSelectedServiceLabour.modalPresentationStyle = .automatic
                    mSelectedServiceLabour.mProductData = mServiceData
                    mSelectedServiceLabour.transitioningDelegate = self
                    self.present(mSelectedServiceLabour,animated: true)
                }
            }
        }
    }

    @IBAction func mEditServiceLabour(_ sender: UIButton) {
        
        let storyBoard: UIStoryboard = UIStoryboard(name: "laybyInstallment", bundle: nil)
        if let mCommonServiceLabour = storyBoard.instantiateViewController(withIdentifier: "CommonServiceLabour") as? CommonServiceLabour {
            mCommonServiceLabour.modalPresentationStyle = .overFullScreen
            mCommonServiceLabour.delegate = self
            mCommonServiceLabour.mProductData = self.mCartData[sender.tag] as? NSDictionary ?? NSDictionary()
            mCommonServiceLabour.transitioningDelegate = self
            self.present(mCommonServiceLabour,animated: true)
        }
    }
    
    @IBAction func mMinusButton(_ sender: UIButton) {
        let index = sender.tag
        guard let mInvData = mCartData[index] as? NSDictionary,
              let cells = mCartTable.cellForRow(at: IndexPath(row: sender.tag , section: 0)) as? CustomCartItems else {
            return
        }
        let mOrgData = mCartDataMaster[sender.tag] as? NSDictionary
        let mMinQty = 1
        var mCurrentQty = Int(cells.mQuantityUnit.text ?? "") ?? 0
        if mCurrentQty == mMinQty {
            return
        } else {
            mCurrentQty -= 1
            cells.mQuantityUnit.text = "\(mCurrentQty)"

            cells.mProductPrice.text = "\((Double("\(mInvData.value(forKey: "price") ?? "0")") ?? 0.0))"
        }

        guard let mData = mInvData.mutableCopy() as? NSMutableDictionary else { return }
        
        let finalQTY = Int(cells.mQuantityUnit.text ?? "") ?? 0
        let finalPrice = Double((cells.mProductPrice.text ?? "0").replace(string: ",", replacement: "")) ?? 0
        mData.setValue(finalQTY, forKey: "Qty")
        mData.setValue(finalPrice, forKey: "price")

        if let mServiceLabourStatus = mInvData.value(forKey: "Service_labour_exsist") as? Bool {
            mData.setValue(mServiceLabourStatus, forKey: "Service_labour_exsist")
            if mServiceLabourStatus, let mServiceLabour = mInvData.value(forKey: "Service_labour") as? NSDictionary {
                mData.setValue(mServiceLabour, forKey: "Service_labour")
            }
        } else {
            mData.setValue(false, forKey: "Service_labour_exsist")
        }

        if mInvData.value(forKey: "stock_id_options") == nil {
            mData.setValue([], forKey: "stock_id_options")
        }

        mCartData.removeObject(at: index)
        mCartData.insert(mData, at: index)
        mCartTable.reloadData()
        calculateItemsWithAmount()
    }

    @IBAction func mPlusButton(_ sender: UIButton) {
        let index = sender.tag

        let mOrgData = mCartDataMaster[sender.tag] as? NSDictionary
        guard let mInvData = mCartData[index] as? NSDictionary,
              let cells = mCartTable.cellForRow(at: IndexPath(row: sender.tag , section: 0)) as? CustomCartItems else {
            return
        }
        
        let mMaxQty =  Int("\(mInvData.value(forKey: "po_QTY") ?? "1")") ?? 1
        var mCurrentQty = Int(cells.mQuantityUnit.text ?? "") ?? 0
        print("Current Qty =", mCurrentQty)
        print("Max Qty =", mMaxQty)
        print("Inventory Data =", mInvData)
        if mCurrentQty >= mMaxQty {
            return
        }
        mCurrentQty += 1
        cells.mQuantityUnit.text = "\(mCurrentQty)"

        cells.mProductPrice.text = "\((Double("\(mInvData.value(forKey: "price") ?? "0")") ?? 0.0))"

        guard let mData = mInvData.mutableCopy() as? NSMutableDictionary else { return }

        let finalQTY = Int(cells.mQuantityUnit.text ?? "") ?? 0
        let finalPrice = Double((cells.mProductPrice.text ?? "0").replace(string: ",", replacement: "")) ?? 0
        mData.setValue(finalQTY, forKey: "Qty")
        mData.setValue(finalPrice, forKey: "price")

        if let mServiceLabourStatus = mInvData.value(forKey: "Service_labour_exsist") as? Bool {
            mData.setValue(mServiceLabourStatus, forKey: "Service_labour_exsist")
            if mServiceLabourStatus, let mServiceLabour = mInvData.value(forKey: "Service_labour") as? NSDictionary {
                mData.setValue(mServiceLabour, forKey: "Service_labour")
            }
        } else {
            mData.setValue(false, forKey: "Service_labour_exsist")
        }

        if mInvData.value(forKey: "stock_id_options") == nil {
            mData.setValue([], forKey: "stock_id_options")
        }

        mCartData.removeObject(at: index)
        mCartData.insert(mData, at: index)
        mCartTable.reloadData()
        calculateItemsWithAmount()
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
       
       if editingStyle == .delete {
 
           guard let mData = mCartData[indexPath.row] as? NSDictionary else {
               return
           }
           CommonClass.showFullLoader(view: self.view)
           let mParams = [ "customer_id":mCustomerId , "custom_cart_id":mData.value(forKey: "custom_cart_id") as? String ?? ""] as [String : Any]
           
           mUserLoginToken = UserDefaults.standard.string(forKey: "token")
           mUserLoginTokenPos = UserDefaults.standard.string(forKey: "token_pos")
           
           mGetData(url: mDeleteCartItem,headers: sGisHeaders,  params: mParams) { response , status in
               CommonClass.stopLoader()
               if status {
               if "\(response.value(forKey: "code") ?? "")" == "200" {
                   CommonClass.stopLoader()
                   self.mDeleteRow(index: indexPath.row)
               }else{
             
               }
           }
       }
           
       }
   }
    func mDeleteRow(index : Int)
    {
        self.mCartData.removeObject(at: index)
        self.mCartTable.reloadData()
        calculateItemsWithAmount()

    }
    
//    func mDeleteCartItems(index: Int) {
//        self.mCartData.removeObject(at: index)
//        self.mCartTable.reloadData()
//        calculateItemsWithAmount()
//
//    }
    func mDeleteCartItems(index: Int) {

        print("========== DELETE CART DEBUG ==========")
        print("🔥 DELETE INDEX =", index)
        print("🔥 CART COUNT =", self.mCartData.count)
        print("🔥 CART DATA =", self.mCartData)
        print("=======================================")


        guard index >= 0,
              index < self.mCartData.count else {

            print("❌ INVALID DELETE INDEX")
            return
        }


        self.mCartData.removeObject(at: index)

        self.mCartTable.reloadData()

        calculateItemsWithAmount()
    }
    @IBAction func mRemoveCartItems(_ sender: UIButton) {
        
        mRemovePopUp.frame = self.view.bounds
        mRemovePopUp.mCustomerId = mCustomerId
        mRemovePopUp.delegate = self
        mRemovePopUp.index = sender.tag
        mRemovePopUp.mType = ""
        if let mData = mCartData[sender.tag] as? NSDictionary {
            mRemovePopUp.mCartId = mData.value(forKey: "custom_cart_id") as? String ?? ""
        }
        mRemovePopUp.mMessage.text = "Are you sure want to remove ?".localizedString
        mRemovePopUp.mCancelButton.setTitle("CANCEL".localizedString, for: .normal)
        mRemovePopUp.mConfirmButton.setTitle("CONFIRM".localizedString, for: .normal)
        self.view.addSubview(mRemovePopUp)
    }

    @IBAction func mEditAmount(_ sender: UITextField) {
        
        self.mTaxLabourCharge.text = ""
        self.mTaxShippingCharge.text = ""
        self.mTaxLoyaltyPoint.text = ""
        self.mTaxDiscountAmounts.text = ""
        self.mTaxDiscountPercents.text = ""
        
        if let mInvData = mCartData[sender.tag] as? NSDictionary,
        let mOrgData = mCartDataMaster[sender.tag] as? NSDictionary,
           let cells = mCartTable.cellForRow(at: IndexPath(row: sender.tag , section: 0)) as? CustomCartItems {
            cells.mQuantityUnit.text = "1"
            cells.mDiscountAmount.text = "0"
            cells.mDiscountPercent.text = "0"
            if sender.text == "" || sender.text == "0" {
                cells.mProductPrice.text = ""
                
                guard var mData = mInvData.mutableCopy() as? NSMutableDictionary else { return }
                mData.setValue(0, forKey: "price")
                self.mCartAmount[sender.tag] = 0.0
                
                mData.setValue("0", forKey: "discount_percent")
                mData.setValue("0", forKey: "Discount_Amount")
                
                if let mServiceLabourStatus = mInvData.value(forKey: "Service_labour_exsist") as? Bool {
                    mData.setValue(mServiceLabourStatus, forKey: "Service_labour_exsist")
                    if mServiceLabourStatus, let mServiceLabour = mInvData.value(forKey: "Service_labour") as? NSDictionary {
                        mData.setValue(mServiceLabour, forKey: "Service_labour")
                    }
                } else {
                    mData.setValue(false, forKey: "Service_labour_exsist")
                }
                
                if let mStockData = mInvData.value(forKey: "stock_id_options") as? NSArray {
                    mData.setValue(mStockData, forKey: "stock_id_options")
                } else {
                    mData.setValue([], forKey: "stock_id_options")
                }
                
                mCartData[sender.tag] = mData
                calculateItemsWithAmount()
                return
            }
            
            guard var mData = mInvData.mutableCopy() as? NSMutableDictionary else { return }
            self.mCartAmount.remove(at: sender.tag)
            self.mCartAmount.insert(Double("\(cells.mProductPrice.text ?? "")") ?? 0.0, at: sender.tag)
            
            let finalPrice = Double((cells.mProductPrice.text ?? "0").replace(string: ",", replacement: "")) ?? 0
            mData.setValue(finalPrice, forKey: "price")
            
            mData.setValue("0", forKey: "discount_percent")
            mData.setValue("0", forKey: "Discount_Amount")
            if let mServiceLabourStatus =  mInvData.value(forKey: "Service_labour_exsist") as? Bool {
                if mServiceLabourStatus {
                    mData.setValue(mServiceLabourStatus, forKey: "Service_labour_exsist")
                    if let mServiceLabour = mInvData.value(forKey: "Service_labour") as? NSDictionary {
                        mData.setValue(mServiceLabour, forKey: "Service_labour")
                    }
                }else{
                    mData.setValue(false, forKey: "Service_labour_exsist")
                }
            }
            
            if let mStockData = mInvData.value(forKey: "stock_id_options") as? NSArray {
                mData.setValue(mStockData, forKey: "stock_id_options")
            }else{
                mData.setValue([], forKey: "stock_id_options")
                
            }
            mCartData.removeObject(at: sender.tag)
            mCartData.insert(mData, at: sender.tag)
            calculateItemsWithAmount()
        }
    }
    
    @IBAction func mEditremarks(_ sender: UITextField) {
        

    }
    
    
    
//    func calculateItemsWithAmount(){
//        var mAmounts = [Double]()
//        var mQuantities = [Int]()
//        
//        var mServiceAmounts = [Double]()
//        
//        for i in mCartData {
//            if let mData = i as? NSDictionary {
//                let qty = Int("\(mData.value(forKey: "Qty") ?? "0")") ?? 0
//                let amount = Double("\(mData.value(forKey: "price") ?? "0.0")".replacingOccurrences(of: ",", with: "")) ?? 0.00
//                mQuantities.append(qty)
//                mAmounts.append(amount * Double(qty))
//                
//                if let mServiceLabourStatus = mData.value(forKey: "Service_labour_exsist") as? Bool {
//                    
//                    if mServiceLabourStatus {
//                        if let mServiceLabour = mData.value(forKey: "Service_labour") as? NSDictionary {
//                            if let mServiceItem = mServiceLabour.value(forKey: "service_laburelist") as? NSArray,
//                               mServiceItem.count > 0 {
//                                var mAmounts = [Double]()
//                                for i in mServiceItem {
//                                    if let items = i as? NSDictionary {
//                                        mAmounts.append(Double("\(items.value(forKey: "scrviceamount") ?? "0.0")".replacingOccurrences(of: ",", with: "")) ?? 0.00)
//                                    }
//                                }
//                                
//                                mServiceAmounts.append(mAmounts.reduce(0, {$0 + $1}))
//                            }
//                        }
//                        
//                    }
//                }
//            }
//        }
//        
//        self.mTaxLabourCharge.text = "\(mServiceAmounts.reduce(0, {$0 + $1}))"
//        mTotalItems.text = "\(mCartData.count) items"
//        mGrandTotal.text = self.mCurrency + String(format:"%.02f",locale:Locale.current,mAmounts.reduce(0, {$0 + $1}))
//        self.mTaxTotal.text = self.mCurrency + String(format:"%.02f",locale:Locale.current,mAmounts.reduce(0, {$0 + $1}))
//        
//        mGrandTotalCart = "\(mAmounts.reduce(0, {$0 + $1}))"
//        self.mGrandTotalAmounts = "\(mAmounts.reduce(0, {$0 + $1}))"
//        self.mTaxValue.text = "\((Double("\(UserDefaults.standard.string(forKey: "taxValue") ?? "0")") ?? 0.00))"
//        self.mTaxTotal.text =  self.mCurrency + " " + self.mGrandTotalAmounts.formatPrice()
//        if mDepositPercents == "100" {
//            var mAdditionalAmount =  Double()
//            let mDiscountA = Double(self.mTaxDiscountAmounts.text ?? "") ?? 0.0
//            let mLabour = Double(self.mTaxLabourCharge.text ?? "") ?? 0.0
//            let mShipping = Double(self.mTaxShippingCharge.text ?? "") ?? 0.0
//            let mLoyalty = Double(self.mTaxLoyaltyPoint.text ?? "") ?? 0.0
//            mAdditionalAmount = mLabour + mShipping + mLoyalty
//            
//            mDepositAmount.text =  mGrandTotal.text
//            mOutstandingAmount.text = self.mCurrency + "0.00"
//            self.mOutStandingAmounts = "0.00"
//            self.mTotalDepositAmounts = self.mGrandTotalAmounts
//
//             let mTaxType = UserDefaults.standard.string(forKey: "taxType") ?? ""
//                if mTaxType.lowercased() == "inclusive" {
//                    let grandTotal = Double(self.mGrandTotalAmounts.replacingOccurrences(of: ",", with: "")) ?? 0.0
//                    let taxPercent = Double(UserDefaults.standard.string(forKey: "taxValue") ?? "0.0") ?? 0.0
//
//                    let taxAmount = calculateInclusiveTax(value: grandTotal, percent: taxPercent)
//
//                    mTaxAmount.text = String(format: "%.02f", locale: Locale.current, taxAmount)
//                    
//                    let subTotal = grandTotal - taxAmount
//                    mTaxSubTotal.text = "\(self.mCurrency) \(String(format: "%.02f", locale: Locale.current, subTotal))"
//
//                    var includingDiscount = (Double(self.mGrandTotalAmounts) ?? 0.00) - (mDiscountA)
//                    includingDiscount = includingDiscount + mAdditionalAmount
//                    
//                    mGrandTotal.text = self.mCurrency + "\(includingDiscount)".formatPrice()
//                self.mTotalDepositAmounts  = String(format: "%.2f", includingDiscount)
//
//                }
//            if mTaxType.lowercased() == "exclusive" {
//            
//                let grandTotal = Double(self.mGrandTotalAmounts.replacingOccurrences(of: ",", with: "")) ?? 0.0
//                let taxPercent = Double(UserDefaults.standard.string(forKey: "taxValue") ?? "0.0") ?? 0.0
//                let taxAmount = calculateExclusiveTax(value: grandTotal, percent: taxPercent)
//                mTaxAmount.text = String(format: "%.02f", locale: Locale.current, taxAmount)
//
//                let taxSubTotal = grandTotal + taxAmount + mAdditionalAmount - mDiscountA
//                mTaxSubTotal.text = self.mCurrency + " " + String(format: "%.02f", locale: Locale.current, taxSubTotal)
//
//                var includingDiscount = (Double(self.mGrandTotalAmounts) ?? 0.00) - (mDiscountA)
//                includingDiscount = includingDiscount + mAdditionalAmount + calculateExclusiveTax(value: (Double(self.mGrandTotalAmounts.replacingOccurrences(of: ",", with: "")) ?? 0.0), percent: (Double("\(UserDefaults.standard.string(forKey: "taxValue") ?? "0")") ?? 0.0))
//                
//                
//                mGrandTotal.text = self.mCurrency + "\(includingDiscount)".formatPrice()
//            self.mTotalDepositAmounts  = String(format: "%.2f", includingDiscount)
//            }
//                  
//            }else{
//              let mTotalValue = mAmounts.reduce(0, {$0 + $1})
//            mDepositAmount.text = self.mCurrency + String(format:"%.02f",locale:Locale.current,calculatePercentage(value: mTotalValue, percent: Double(mDepositPercents) ?? 0.00))
//            self.mTotalDepositAmounts = "\(calculatePercentage(value: mTotalValue, percent: Double(mDepositPercents) ?? 0.00))"
//            let mOutstandingBal = mTotalValue - calculatePercentage(value: mTotalValue, percent: Double(mDepositPercents) ?? 0.00)
//            self.mOutStandingAmounts = "\(mOutstandingBal)"
//            self.mOutstandingAmount.text = self.mCurrency + String(format:"%.02f",locale:Locale.current,mOutstandingBal)
//        }
//        
//        
//        
//       
//    }
    
    func calculateItemsWithAmount() {

        var mAmounts = [Double]()
        var mQuantities = [Int]()
        var mServiceAmounts = [Double]()

        // =====================================================
        // 1. PRODUCT TOTAL + SERVICE LABOUR TOTAL
        // =====================================================

        for item in mCartData {

            guard let mData = item as? NSDictionary else {
                continue
            }
            
            print("========== CALCULATE ==========")
            print("price =", mData["price"] ?? "")
            print("cart_price =", mData["cart_price"] ?? "")
            print("Discount_Amount =", mData["Discount_Amount"] ?? "")
            print("discount_percent =", mData["discount_percent"] ?? "")

            let qty =
                Int("\(mData.value(forKey: "Qty") ?? "0")") ?? 0

//            let amount =
//                Double(
//                    "\(mData.value(forKey: "price") ?? "0.0")"
//                        .replacingOccurrences(of: ",", with: "")
//                ) ?? 0.0
//            let amount = PriceHelper.unformatPrice(
//                "\(mData.value(forKey: "price") ?? "0")"
//            )
            
//            let rawAmount =
//                mData.value(forKey: "cart_price")
//                ?? mData.value(forKey: "price")
//                ?? "0"
            let rawAmount =
                mData.value(forKey: "price")
                ?? mData.value(forKey: "cart_price")
                ?? "0"
            print("RAW AMOUNT =", rawAmount)
            let amount = PriceHelper.unformatPrice("\(rawAmount)")
            
            print("---------------------")
            print("price =", mData["price"] ?? "")
            print("cart_price =", mData["cart_price"] ?? "")
            print("amount =", amount)

            mQuantities.append(qty)

            // Product amount
            mAmounts.append(amount * Double(qty))


            // =================================================
            // SERVICE LABOUR
            // =================================================

            let serviceLabourStatus =
                mData.value(forKey: "Service_labour_exsist") as? Bool
                ?? false

            if serviceLabourStatus {

                if let mServiceLabour =
                    mData.value(forKey: "Service_labour")
                        as? NSDictionary {

                    /*
                     รองรับทั้ง key เดิมของ project:
                     service_laburelist
                     scrviceamount

                     และ key ใหม่ ถ้า API เปลี่ยน:
                     service_labour_list
                     serviceAmount
                     */

                    let serviceItems =
                        (mServiceLabour.value(
                            forKey: "service_laburelist"
                        ) as? NSArray)
                        ??
                        (mServiceLabour.value(
                            forKey: "service_labour_list"
                        ) as? NSArray)

                    if let serviceItems = serviceItems {

                        var itemServiceTotal = 0.0

                        for serviceItem in serviceItems {

                            guard let service =
                                serviceItem as? NSDictionary else {
                                continue
                            }

                            let rawAmount =
                                service.value(forKey: "scrviceamount")
                                ??
                                service.value(forKey: "serviceAmount")
                                ??
                                "0"

                            let serviceAmount =
                                Double(
                                    "\(rawAmount)"
                                        .replacingOccurrences(
                                            of: ",",
                                            with: ""
                                        )
                                ) ?? 0.0

                            itemServiceTotal += serviceAmount
                        }

                        mServiceAmounts.append(itemServiceTotal)
                    }
                }
            }
        }


        // =====================================================
        // 2. CALCULATE BASE TOTALS
        // =====================================================

        let productTotal =
            mAmounts.reduce(0, +)

        let serviceLabourTotal =
            mServiceAmounts.reduce(0, +)

        // Service Labour included here
        let baseGrandTotal =
            productTotal + serviceLabourTotal


        print("========== POS TOTAL DEBUG ==========")
        print("PRODUCT TOTAL =", productTotal)
        print("SERVICE LABOUR TOTAL =", serviceLabourTotal)
        print("BASE GRAND TOTAL =", baseGrandTotal)
        print("=====================================")


        // =====================================================
        // 3. UPDATE BASIC UI
        // =====================================================

        self.mTaxLabourCharge.text =
            String(format: "%.2f", serviceLabourTotal)

        mTotalItems.text =
            "\(mCartData.count) items"

//        mGrandTotal.text =
//            self.mCurrency +
//            String(
//                format: "%.02f",
//                locale: Locale.current,
//                baseGrandTotal
//            )
        let currency = UserDefaults.standard.string(forKey: "currencySymbol") ?? "$"

        mGrandTotal.text = PriceHelper.formatPrice(
            baseGrandTotal,
            currency: currency
        )
        print("GrandTotal =", mGrandTotal.text ?? "")
        mTaxTotal.text =
            self.mCurrency +
            String(
                format: "%.02f",
                locale: Locale.current,
                baseGrandTotal
            )

        mGrandTotalCart =
            "\(baseGrandTotal)"

        self.mGrandTotalAmounts =
            "\(baseGrandTotal)"

        self.mTaxValue.text = "\(Double(UserDefaults.standard.string(forKey: "taxValue") ?? "0") ?? 0.0)"

        self.mTaxTotal.text =
            self.mCurrency +
            " " +
            self.mGrandTotalAmounts.formatPrice()


        // =====================================================
        // 4. DISCOUNT / SHIPPING / LOYALTY
        // =====================================================

//        let mDiscountA =
//            Double(
//                self.mTaxDiscountAmounts.text ?? ""
//            ) ?? 0.0
        
        var mDiscountA =
            Double(
                self.mTaxDiscountAmounts.text ?? ""
            ) ?? 0.0

        // Discount cannot exceed product total
//        if mDiscountA > baseGrandTotal {
//            mDiscountA = baseGrandTotal
//            self.mTaxDiscountAmounts.text = String(format: "%.2f", mDiscountA)
//        }

        let mShipping =
            Double(
                self.mTaxShippingCharge.text ?? ""
            ) ?? 0.0

        let mLoyalty =
            Double(
                self.mTaxLoyaltyPoint.text ?? ""
            ) ?? 0.0
        
        let discountBase = baseGrandTotal + mShipping

        if mDiscountA > discountBase {
            mDiscountA = discountBase
            self.mTaxDiscountAmounts.text = String(format: "%.2f", mDiscountA)
        }

        /*
         IMPORTANT

         Service Labour ถูกบวกเข้า baseGrandTotal แล้ว

         เพราะฉะนั้นห้ามเอา mTaxLabourCharge
         มาบวกใน mAdditionalAmount อีก
         ไม่อย่างนั้น Labour จะโดนบวก 2 รอบ
         */

        let mAdditionalAmount =
            mShipping + mLoyalty


        // =====================================================
        // 5. TAX TYPE
        // =====================================================

        let mTaxType =
            UserDefaults.standard.string(
                forKey: "taxType"
            ) ?? ""

        let taxPercent =
            Double(
                UserDefaults.standard.string(
                    forKey: "taxValue"
                ) ?? "0.0"
            ) ?? 0.0


        // =====================================================
        // 6. CALCULATE FINAL TOTAL
        // =====================================================

        var finalGrandTotal = baseGrandTotal


        if mTaxType.lowercased() == "inclusive" {

//            let taxAmount =
//                calculateInclusiveTax(
//                    value: baseGrandTotal,
//                    percent: taxPercent
//                )
            
            let taxAmount = calculateInclusiveTax(
                value: baseGrandTotal,
                percent: taxPercent
            )

            mTaxAmount.text =
                String(
                    format: "%.02f",
                    locale: Locale.current,
                    taxAmount
                )

//            let subTotal =
//                baseGrandTotal - taxAmount
            
            let subTotal = baseGrandTotal - taxAmount
            
            mCalculatedTaxAmount = taxAmount
            mCalculatedSubTotal = subTotal

            mTaxSubTotal.text =
                "\(self.mCurrency) " +
                String(
                    format: "%.02f",
                    locale: Locale.current,
                    subTotal
                )

            finalGrandTotal =
                baseGrandTotal
                - mDiscountA
                + mAdditionalAmount

            if finalGrandTotal < 0 {
                finalGrandTotal = 0
            }

        } else if mTaxType.lowercased() == "exclusive" {

//            let taxAmount =
//                calculateExclusiveTax(
//                    value: baseGrandTotal,
//                    percent: taxPercent
//                )
            let subTotalBeforeTax =
                baseGrandTotal
                + mShipping
                - mDiscountA

            let taxAmount =
                calculateExclusiveTax(
                    value: max(subTotalBeforeTax, 0),
                    percent: taxPercent
                )

            mTaxAmount.text =
                String(
                    format: "%.02f",
                    locale: Locale.current,
                    taxAmount
                )
            
            mCalculatedTaxAmount = taxAmount
            mCalculatedSubTotal = subTotalBeforeTax

            let taxSubTotal =
                baseGrandTotal
                + taxAmount
                + mAdditionalAmount
                - mDiscountA

            mTaxSubTotal.text =
                self.mCurrency +
                " " +
                String(
                    format: "%.02f",
                    locale: Locale.current,
                    taxSubTotal
                )

//            finalGrandTotal =
//                baseGrandTotal
//                - mDiscountA
//                + mAdditionalAmount
//                + taxAmount
            
            finalGrandTotal =
                max(subTotalBeforeTax, 0)
                + taxAmount

            if finalGrandTotal < 0 {
                finalGrandTotal = 0
            }

        } else {

            // No tax type
//            finalGrandTotal =
//                baseGrandTotal
//                - mDiscountA
//                + mAdditionalAmount
            
            let subTotalBeforeTax =
                baseGrandTotal
                + mShipping
                - mDiscountA

            finalGrandTotal = max(subTotalBeforeTax, 0)
            
            
            if finalGrandTotal < 0 {
                finalGrandTotal = 0
            }

            mTaxAmount.text = "0.00"

            mTaxSubTotal.text =
                self.mCurrency +
                " " +
                String(
                    format: "%.02f",
                    locale: Locale.current,
                    finalGrandTotal
                )
        }

        
        // ===== DEBUG =====
        print("========== POS FINAL DEBUG ==========")
        print("BASE =", baseGrandTotal)
        print("DISCOUNT =", mDiscountA)
        print("SHIPPING =", mShipping)
        print("ADDITIONAL =", mAdditionalAmount)
        print("TAX TYPE =", mTaxType)
        print("TAX =", taxPercent)
        print("FINAL =", finalGrandTotal)
        print("UserDefaults taxType = ")
        print(UserDefaults.standard.string(forKey: "taxType") ?? "")
        print("=====================================")

        // =====================================================
        // 7. UPDATE GRAND TOTAL
        // =====================================================

//        mGrandTotal.text =
//            self.mCurrency +
//            "\(finalGrandTotal)".formatPrice()
        print("baseGrandTotal =", baseGrandTotal)
        print("formatted =", PriceHelper.formatPrice(baseGrandTotal, currency: currency))

        mGrandTotal.text = PriceHelper.formatPrice(
            finalGrandTotal,
            currency: currency
        )
        print("GrandTotal =", mGrandTotal.text ?? "")
        self.mTotalDepositAmounts =
            String(
                format: "%.2f",
                finalGrandTotal
            )


        print("FINAL GRAND TOTAL =", finalGrandTotal)


        // =====================================================
        // 8. DEPOSIT / OUTSTANDING
        // =====================================================

        if mDepositPercents == "100" {

//            mDepositAmount.text =
//                self.mCurrency +
//                String(
//                    format: "%.02f",
//                    locale: Locale.current,
//                    finalGrandTotal
//                )
            mDepositAmount.text = PriceHelper.formatPrice(
                finalGrandTotal,
                currency: currency
            )

            mOutstandingAmount.text =
                self.mCurrency + "0.00"

            self.mOutStandingAmounts =
                "0.00"

            self.mTotalDepositAmounts =
                String(
                    format: "%.2f",
                    finalGrandTotal
                )


        } else {

            let depositPercent =
                Double(mDepositPercents) ?? 0.0

            let depositAmount =
                calculatePercentage(
                    value: finalGrandTotal,
                    percent: depositPercent
                )

            let outstandingAmount =
                finalGrandTotal - depositAmount


//            mDepositAmount.text =
//                self.mCurrency +
//                String(
//                    format: "%.02f",
//                    locale: Locale.current,
//                    depositAmount
//                )
            mDepositAmount.text = PriceHelper.formatPrice(
                depositAmount,
                currency: currency
            )

            self.mTotalDepositAmounts =
                String(
                    format: "%.2f",
                    depositAmount
                )

            self.mOutStandingAmounts =
                String(
                    format: "%.2f",
                    outstandingAmount
                )

//            self.mOutstandingAmount.text =
//                self.mCurrency +
//                String(
//                    format: "%.02f",
//                    locale: Locale.current,
//                    outstandingAmount
//                )
            
            self.mOutstandingAmount.text = PriceHelper.formatPrice(
                outstandingAmount,
                currency: currency
            )
        }


        print("========== POS FINAL DEBUG ==========")
        print("PRODUCT =", productTotal)
        print("SERVICE =", serviceLabourTotal)
        print("DISCOUNT =", mDiscountA)
        print("SHIPPING =", mShipping)
        print("LOYALTY =", mLoyalty)
        print("TAX TYPE =", mTaxType)
        print("TAX % =", taxPercent)
        print("FINAL TOTAL =", finalGrandTotal)
        print("DEPOSIT =", self.mTotalDepositAmounts)
        print("OUTSTANDING =", self.mOutStandingAmounts)
        print("=====================================")
    }
    
    func calculatePercentage(value:Double,percent: Double) -> Double {
        let val = value * percent
        return val/100.00
    }
    func calculateInclusiveTax(value:Double,percent: Double) -> Double {
            let val = value * percent
        return val/(100.00 + (Double("\(UserDefaults.standard.string(forKey: "taxValue") ?? "0")") ?? 0.00))
      
    }
    func calculateExclusiveTax(value:Double,percent: Double) -> Double {
        let val = value * percent
        return val/100.00
    }

    
}
extension Double {
    
    func toInt() -> Int? {
        let roundedValue = rounded(.toNearestOrEven)
        return Int(exactly: roundedValue)
    }
    
}
