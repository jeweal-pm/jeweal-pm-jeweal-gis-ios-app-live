//
//  POSCheckout.swift
//  GIS
//
//  Created by Macbook Pro on 07/07/23.
//  Copyright © 2023 Hawkscode. All rights reserved.
//

import UIKit
import Alamofire
import DropDown
import StripePaymentSheet
import CorePayments
import PayPalWebPayments
import UIKit
import SwiftUI


protocol ConfirmLaybyDelegate {
    func mConfirmLayByPayment(date : String, receiveAmount:String,outstanding:String,noOfReceived:String)
}

protocol ConfirmationDelegate {
    func mGetDatePicker()
    func mConfirmPayment(date : String,dateInGMT: Date, receiveAmount:String,outstanding:String,noOfReceived:String)
}

let mConfirmQuote = UINib(nibName:"confirmquote",bundle:.main).instantiate(withOwner: nil, options: nil).first as? ConfirmQuote ?? ConfirmQuote()

class ConfirmQuote: UIView {
    var mType = ""
    var mNewDate = Date()
    var index = Int()
    var delegate:ConfirmationDelegate? = nil
    
    @IBOutlet weak var mDueDateLABEL: UILabel!
    @IBOutlet weak var mNotes: UITextField!
    @IBOutlet weak var mCurrentDate: UILabel!
    @IBOutlet weak var mHeadingLabel: UILabel!
    @IBOutlet weak var mSubHeading: UILabel!
    @IBOutlet weak var mCreateQuote: UIButton!
    @IBOutlet weak var mCancelButton: UIButton!
    @IBOutlet weak var mDueDate: UITextField!
    
    static func instantiate(message: String) -> ConfirmQuote {
        let view: ConfirmQuote = initFromNib()
        return view
    }
    @IBAction func mChooseDate(_ sender: Any) {
        self.delegate?.mGetDatePicker()
    }
    @IBAction func mCancel(_ sender: Any) {
        self.removeFromSuperview()
    }
    @IBAction func mConfirm(_ sender: Any) {
        self.removeFromSuperview()
        self.delegate?.mConfirmPayment(date: mCurrentDate.text ?? "", dateInGMT: mNewDate, receiveAmount: "", outstanding: "", noOfReceived: mNotes.text ?? "")
    }
}

let mPaymentConfirmation = UINib(nibName:"paymentconfirmation",bundle:.main).instantiate(withOwner: nil, options: nil).first as? PaymentConfirmation ?? PaymentConfirmation()

class PaymentConfirmation: UIView {
    var mType = ""
    
    @IBOutlet weak var mGrandTotal: UILabel!
    @IBOutlet weak var mDueDateLABEL: UILabel!
    @IBOutlet weak var mOutstandingLABEL: UILabel!
    @IBOutlet weak var mGrandTotalLABEL: UILabel!
    @IBOutlet weak var mOutstanding: UILabel!
    @IBOutlet weak var mTotalReceived: UILabel!
    var index = Int()
    var delegate:ConfirmationDelegate? = nil
    
    @IBOutlet weak var mCurrentDate: UILabel!
    @IBOutlet weak var mHeadingLabel: UILabel!
    @IBOutlet weak var mReceiveLabel: UILabel!
    @IBOutlet weak var mConfirmButton: UIButton!
    @IBOutlet weak var mCancelButton: UIButton!
    @IBOutlet weak var mDueDate: UITextField!
    
    var mGrandTotalBalance = ""
    var mOutstandingBalance = ""
    var mTotalReceivedBalance = ""
    var mNavigation = UINavigationController()
    
    static func instantiate(message: String) -> PaymentConfirmation {
        let view: PaymentConfirmation = initFromNib()
        return view
    }
    @IBAction func mChooseDate(_ sender: Any) {
        self.delegate?.mGetDatePicker()
    }
    @IBAction func mCancel(_ sender: Any) {
        self.removeFromSuperview()
    }
    @IBAction func mConfirm(_ sender: Any) {
        self.removeFromSuperview()
        if mType == "Repayment" {
            self.delegate?.mConfirmPayment(date: mCurrentDate.text ?? "",dateInGMT: Date(), receiveAmount: mTotalReceivedBalance, outstanding: mOutstandingBalance, noOfReceived: mReceiveLabel.text ?? "")
            return
        }
        self.delegate?.mConfirmPayment(date: mCurrentDate.text ?? "",dateInGMT: Date(), receiveAmount: mTotalReceived.text ?? "", outstanding: mOutstanding.text ?? "", noOfReceived: mReceiveLabel.text ?? "")
    }
}

class POSCheckout: UIViewController, UITextFieldDelegate , UITableViewDelegate ,UITableViewDataSource , UICollectionViewDelegate, UICollectionViewDataSource , UICollectionViewDelegateFlowLayout ,GetVerification , ProceedToPay, UIViewControllerTransitioningDelegate, ConfirmationDelegate, FinalInstallmentDelegate, ScannerDelegate, QRCodeViewDelegate {
    
    // MARK: - Outlets
    @IBOutlet weak var mPartialPaymentView: UIView!
    @IBOutlet weak var mReceiveView: UIStackView!
    @IBOutlet weak var mCashIcon: UIImageView!
    @IBOutlet weak var mCreditNoteIcon: UIImageView!
    @IBOutlet weak var mBankIcon: UIImageView!
    @IBOutlet weak var mCreditCardIcon: UIImageView!
    @IBOutlet weak var mCreditNoteDetailsView: UIView!
    @IBOutlet weak var mTotalCreditAmount: UILabel!
    @IBOutlet weak var mItemsSelected: UILabel!
    @IBOutlet weak var mTotalSelectedAmount: UILabel!
    @IBOutlet weak var mCreditNoteTable: UITableView!
    @IBOutlet weak var mSubmitCreditNote: UIButton!
    
    @IBOutlet weak var mEditCashView: UIView!
    @IBOutlet weak var mCashCurrencyImage: UIImageView!
    @IBOutlet weak var mCurrencyName: UILabel!
    @IBOutlet weak var mChooseCurrencyButt: UIButton!
    @IBOutlet weak var mCashAmount: UITextField!
    @IBOutlet weak var mExchangeRateLabel: UILabel!
    @IBOutlet weak var mExchangeRateValue: UITextField!
    @IBOutlet weak var mConvertedAmount: UILabel!
    
    @IBOutlet weak var mSubmitTx: UIButton!
    @IBOutlet weak var mTaxCalView: UIView!
    @IBOutlet weak var mTotalTx: UILabel!
    @IBOutlet weak var mTotalDiscountTx: UILabel!
    @IBOutlet weak var mSubTotalTx: UILabel!
    @IBOutlet weak var mTaxVal: UITextField!
    @IBOutlet weak var mFinalTaxAmount: UITextField!
    @IBOutlet weak var mTaxAmountTx: UILabel!
    @IBOutlet weak var mTaxValueTx: UILabel!
    @IBOutlet weak var mExchangeTx: UILabel!
    @IBOutlet weak var mLabourCharge: UITextField!
    @IBOutlet weak var mShippingCharge: UITextField!
    @IBOutlet weak var mDiscountPercents: UITextField!
    @IBOutlet weak var mDiscountAmounts: UITextField!
    
    @IBOutlet weak var mPayNowButton: UIButton!
    @IBOutlet weak var mCreditCardView: UIView!
    @IBOutlet weak var mTaxInfoView: UIView!
    @IBOutlet weak var mKeyBoardView: UIView!
    @IBOutlet weak var mCardView: UIView!
    @IBOutlet weak var mCashView: UIView!
    @IBOutlet weak var mBankView: UIView!
    @IBOutlet weak var mCreditNoteView: UIView!
    @IBOutlet weak var mTaxView: UIView!
    
    @IBOutlet weak var mVisaView: UIView!
    @IBOutlet weak var mApplePayView: UIView!
    @IBOutlet weak var mAliPayView: UIView!
    @IBOutlet weak var mWeChatPayView: UIView!
    @IBOutlet weak var mCreditCardLabel: UILabel!
    @IBOutlet weak var mApplePayLabel: UILabel!
    @IBOutlet weak var mAliPayLabel: UILabel!
    @IBOutlet weak var mWeChatPayLabel: UILabel!
    @IBOutlet weak var mPayNowView: UIView!
    
    @IBOutlet weak var mCustomerSearch: UITextField!
    @IBOutlet weak var mDropDownImage: UIImageView!
    
    @IBOutlet weak var mCustomerSearchView: UIView!
    @IBOutlet weak var mCustomerDetailView: UIView!
    @IBOutlet weak var mCustomerNames: UILabel!
    @IBOutlet weak var mCustomerAddresss: UILabel!
    @IBOutlet weak var mCustomerNumbers: UILabel!
    
    @IBOutlet weak var mBALANCEDUE: UILabel!
    @IBOutlet weak var mTOTALAMOUNT: UILabel!
    @IBOutlet weak var mSubmittedCash: UILabel!
    @IBOutlet weak var mSubmittedCreditCard: UILabel!
    @IBOutlet weak var mSubmittedCreditNote: UILabel!
    @IBOutlet weak var mCreditNotesView: UIView!
    
    @IBOutlet weak var mHCheckoutLABEL: UILabel!
    @IBOutlet weak var mCreditCardLABEL: UILabel!
    @IBOutlet weak var mCashLABEL: UILabel!
    @IBOutlet weak var mBankLABEL: UILabel!
    @IBOutlet weak var mCreditNoteLABEL: UILabel!
    @IBOutlet weak var mTaxLABEL: UILabel!
    @IBOutlet weak var mCNTypeLABEL: UILabel!
    @IBOutlet weak var mCNDate: UILabel!
    @IBOutlet weak var mCNRefNoLABEL: UILabel!
    @IBOutlet weak var mCNAmountLABEL: UILabel!
    @IBOutlet weak var mCNTotalLABEL: UILabel!
    @IBOutlet weak var mSUBLABEL: UILabel!
    @IBOutlet weak var mTLabourLABEL: UILabel!
    @IBOutlet weak var mTShippingLABEL: UILabel!
    @IBOutlet weak var mLoyaltyPointLABEL: UILabel!
    @IBOutlet weak var mTDiscountPLABEL: UILabel!
    @IBOutlet weak var mTDiscountALABEL: UILabel!
    @IBOutlet weak var mTaxPLABEL: UILabel!
    @IBOutlet weak var mTaxALABEL: UILabel!
    @IBOutlet weak var mBCreditCardLABEL: UILabel!
    @IBOutlet weak var mBCashLABEL: UILabel!
    @IBOutlet weak var mBBankLABEL: UILabel!
    @IBOutlet weak var mBCreditNoteLABEL: UILabel!
    @IBOutlet weak var mTxTotalLABEL: UILabel!
    @IBOutlet weak var mTxSubTotalLABEL: UILabel!
    @IBOutlet weak var mTxExchangeLABEL: UILabel!
    @IBOutlet weak var mBTotalLABEL: UILabel!
    @IBOutlet weak var mBBalanceDueLABEL: UILabel!
    @IBOutlet weak var mTxDiscountLABEL: UILabel!
    
    @IBOutlet weak var mChequeDetailsView: UIView!
    @IBOutlet weak var mChequeAmount: UITextField!
    @IBOutlet weak var mCheqDate: UITextField!
    @IBOutlet weak var mCheqAccountNumber: UITextField!
    @IBOutlet weak var mCheqAccountName: UITextField!
    @IBOutlet weak var mCheqBankImage: UIImageView!
    @IBOutlet weak var mCheqBankName: UITextField!
    @IBOutlet weak var mCheqRefNumber: UITextField!
    @IBOutlet weak var mCheqInstNumber: UITextField!
    @IBOutlet weak var mSubmittedBankAmount: UILabel!
    
    @IBOutlet weak var mCheqDateLABEL: UILabel!
    @IBOutlet weak var mCheqAccountNoLABEL: UILabel!
    @IBOutlet weak var mCheqAccountNameLABEL: UILabel!
    @IBOutlet weak var mCheqBankLABEL: UILabel!
    @IBOutlet weak var mCheqRefLABEL: UILabel!
    @IBOutlet weak var mCheqInstLABEL: UILabel!
    @IBOutlet weak var mCheqSubmitBUTTON: UIButton!
    
    @IBOutlet weak var mSubmitButtonCredit: UIButton!
    @IBOutlet weak var mCloseButtonCredit: UIButton!
    @IBOutlet weak var mCreditCardPaymentView: UIView!
    @IBOutlet weak var mCreditFillAmount: UITextField!
    @IBOutlet weak var mCreditCardBanksView: UIView!
    @IBOutlet weak var mStripeCardView: UIView!
    @IBOutlet weak var mCollectionView: UICollectionView!
    @IBOutlet weak var mGiftCardAmount: UITextField!
    @IBOutlet weak var mApplyGiftBUTTON: UIButton!
    @IBOutlet weak var mClearBUTTON: UIButton!
    @IBOutlet weak var mReceiveAmountLABEL: UILabel!
    
    @IBOutlet weak var mCardNumber: UITextField!
    @IBOutlet weak var mCardName: UITextField!
    @IBOutlet weak var mCreditBankName: UITextField!
    @IBOutlet weak var mCreditBankImage: UIImageView!
    @IBOutlet weak var mTotalItemsInCart: UILabel!
    
    // Tab Outlets
    @IBOutlet weak var mSelectPaymentOptionContainer: UIView!
    @IBOutlet weak var mTabBarContainer: UIView!
    @IBOutlet weak var mCardNumberContainer: UIView!
    @IBOutlet weak var mCardNameContainer: UIStackView!
    @IBOutlet weak var mIBSelect: UIButton!
    @IBOutlet weak var mChequeSelect: UIButton!
    @IBOutlet weak var mIBTabSelect: UILabel!
    @IBOutlet weak var mChequeTabSelect: UILabel!
    @IBOutlet weak var mEnterAmountText: UITextField!
    @IBOutlet weak var mSelectIBBank: UITextField!
    @IBOutlet weak var mSelectIBBankImage: UIImageView!
    @IBOutlet weak var mEnterQRAmount: UITextField!
    @IBOutlet weak var mSelectedBankName: UITextField!
    @IBOutlet weak var mSelectedBankImage: UIImageView!
    @IBOutlet weak var mPaymentOptionIcon: UIImageView!
    @IBOutlet weak var mPaymentOptionView: UIView!
    @IBOutlet weak var mGCurrency: UILabel!
    @IBOutlet weak var mRCurrency: UILabel!
    @IBOutlet weak var mBCurrency: UILabel!
    
    @IBOutlet weak var mFullPaymentLabel: UILabel!

    @IBOutlet weak var mLaybyLabel: UILabel!
    @IBOutlet weak var mInstallmentLabel: UILabel!

    @IBOutlet weak var mFullPaymentOptionView: UIView!
    @IBOutlet weak var mLaybyOptionView: UIView!
    @IBOutlet weak var mInstallmentOptionView: UIView!

    @IBOutlet weak var mInstallmentDetailsButton: UIButton!
    
    @IBOutlet weak var mRECEIVEAMOUNT: UILabel!
    
    @IBOutlet weak var mPaypalSandboxView: UIView!
    @IBOutlet weak var mPaypalSandboxImage: UIImageView!
    @IBOutlet weak var mPaypalSandboxLabel: UILabel!
    
    
    // MARK: - Variables
    var mCreditNoteData = NSMutableArray()
    var mSelectedIndex = [IndexPath]()
    var mCurrencyImageData = [String]()
    var mCurrencyNameData = [String]()
    var mExchangeRateData = [String]()
    var mCashAmounts = ""
    var mSelectedStoreCurrency = ""
    var mStoreCurrency = ""
    var mConvertedAmounts = "0"

    // Cash split-payment state.
    // amount = amount deducted from the order total in STORE currency.
    // enteredAmount = amount typed by the customer in the selected currency.
    private struct CashPaymentPage {
        var amount: Double
        var enteredAmount: Double
        var currency: String
        var exchangeRate: Double
        var isSubmitted: Bool
    }
    private var mCashPages: [CashPaymentPage] = [
        CashPaymentPage(
            amount: 0,
            enteredAmount: 0,
            currency: "",
            exchangeRate: 1,
            isSubmitted: false
        )
    ]
    private var mCurrentCashPage = 0
    private let mPageControl = UIPageControl()
    var isQRCodeDeleted = false
    var mTotalP = ""
    var mTotalAm = ""
    var mSubTotalP = ""
    var mTaxP = ""
    var mTaxAm = ""
    var mRemark = ""
    var mNote = ""
    var mTaxType = ""
    var mTaxLabel = ""
    var mTaxPercent = ""
    var mTotalWithDiscount = ""
    var mCustomerId = ""
    var mCartTableData = NSMutableArray()
    let mCustomerSearchTableView = UITableView()
    var mSearchCustomerData = NSArray()
    var mTransactionType = "Cash"
    var isExchange = false
    var mOrderType = ""
    var mPartialPayment = ""
    var mQuantity = [Int]()
    var mCreditData = NSMutableArray()
    var mCreditDataMerged = NSMutableArray()
    var mSelectedCustomIndex = [IndexPath]()
    var mAmountData = NSMutableArray()
    var mCreditCardMethod = NSMutableArray()
    var mGiftCardMethod = NSMutableArray()
    var mGiftFinalTotalAmount = ""
    var mChequePaymentId = ""
    var mChequePaymentIdNew = ""
    var paymentSlag = ""
    var mCreditCardPaymentId = ""
    var mCreditCardLogo = ""
    var mCreditCardName = ""
    let mDatePicker:UIDatePicker = UIDatePicker()
    var mChequeData = NSMutableDictionary()
    var mFinalPaymentMethod = [String:Any]()
    var mFTOTAL = ""
    var mStripeIndex = 0
    var mPaymentData = NSArray()
    var mBankData = NSArray()
    var mCreditCardPayment = NSMutableArray()
    var mBankPayment = NSMutableArray()
    var mCashPayment = NSMutableDictionary()
    var mCartTotalAmount = ""
    var mDepositPercents = "100"
    var mTotalOutstandingAm = "0.00"
    var mCurrencySymbol = "$"
    var mLabourPoints = 0.0
    var mShippingPoints = 0.0
    var mLoyaltyPoints = 0.0
    var mTaxAmount = 0.0
    var mTaxAmountInt = 0.0
    var mTaxInPercent = 0.0
    var mTaxDiscountAmount = 0.0
    var mTaxDiscountPercent = 0.0
    var mTaxTypeIE = ""
    var mOrderId = ""
    var mClientReferenceID = ""
    var mClientSecreat = ""
    var mPaymentIntentID = ""
    var mPaymentID = ""
    var mStripPublishKey = ""
    var mPaypalClientID = ""
    var mPaypalEnvironment = "sandbox"
    
    var mPaypalSandboxData = NSDictionary()
    var mPaypalLiveData = NSDictionary()

    var mPaypalPayerID = ""
    var mPaypalOrderID = ""
    var mPaypalEncryptedPayload = ""
    
    var mSelectedPaypalMethodData: NSDictionary?

    private var payPalClient: PayPalWebCheckoutClient?
    private var payPalConfig: CoreConfig?
    var mPaymentMethod = ""
    var mSelectdPaymentMethod = ""
    let qrCodeView = QRCodeView.loadFromNib()
    
    var mIsCrossLocationReserve = false
    var mCrossLocationId = ""
    
    
    private var paypalHostingController:
    UIHostingController<PayPalCheckoutView>?
    
    // Address Variables
    private var mSelectedBillingAddress: [String : Any] = [:]
    private var mSelectedShippingAddress: [String : Any] = [:]
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.mCreditCardPaymentView.isHidden = true
        mVisaView.backgroundColor = .white
        mApplePayView.backgroundColor = .clear
        mAliPayView.backgroundColor = .white
        mWeChatPayView.backgroundColor = .white
        
        mVisaView.borderColor = .white
        mApplePayView.borderColor = .white
        mAliPayView.borderColor = .white
        mWeChatPayView.borderColor = .white
        
        mCreditCardLabel.textColor = .black
        mApplePayLabel.textColor = .black
        mAliPayLabel.textColor = .black
        mWeChatPayLabel.textColor = .black
        
        self.mCheqBankName.text = "Choose Bank"
        self.mCheqBankImage.downlaodImageFromUrl(urlString: "https://art.gis247.net/assets/images/icon/camera_profile.png")
        
        mApplyGiftBUTTON.setTitle("APPLY".localizedString, for: .normal)
        mGiftCardAmount.placeholder = "Gift Card number".localizedString
        mHCheckoutLABEL.text = "CHECK OUT".localizedString
        mCreditCardLABEL.text = "Credit Card".localizedString
        mCashLABEL.text = "Cash".localizedString
        mBankLABEL.text = "Bank".localizedString
        mCreditNoteLABEL.text = "Credit note".localizedString
        mCNTotalLABEL.text = "Total".localizedString
        mSUBLABEL.text = "SUB".localizedString
        mBCreditCardLABEL.text = "Credit Card".localizedString
        mBCashLABEL.text = "Cash".localizedString
        mBBankLABEL.text = "Bank".localizedString
        mBCreditNoteLABEL.text = "Credit Note".localizedString
        mBTotalLABEL.text = "Grand Total".localizedString
        mBBalanceDueLABEL.text = "Balance Due".localizedString
        mCreditCardLabel.text = "Credit Card".localizedString
        mExchangeRateLabel.text = "Exchange Rate".localizedString
        mItemsSelected.text = "0 " + "Item Selected".localizedString
        mPayNowButton.setTitle("PAY NOW".localizedString, for: .normal)
        mClearBUTTON.setTitle("Clear".localizedString, for: .normal)
        mCheqSubmitBUTTON.setTitle("SUBMIT".localizedString, for: .normal)
        mSubmitButtonCredit.setTitle("SUBMIT".localizedString, for: .normal)
        mCardNumber.placeholder = "Card number".localizedString
        mCardName.placeholder = "Card name".localizedString
        mCheqAccountNoLABEL.text = "Account No.".localizedString
        mCheqAccountNameLABEL.text = "Account Name".localizedString
        mCheqRefLABEL.text = "Ref No.".localizedString
        mCheqInstLABEL.text = "Inst No.".localizedString
        
        let isPartial = UserDefaults.standard.bool(forKey: "isPartial")
        self.mPartialPaymentView.isHidden = !isPartial
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

        print("VIEW_APPEAR_CARD =",
              mCardNumberContainer.isHidden)

        print("VIEW_APPEAR_NAME =",
              mCardNameContainer.isHidden)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupCashPageControl()
        let tap = UITapGestureRecognizer(
            target: self,
            action: #selector(dismissKeyboard)
        )

        tap.cancelsTouchesInView = false

        view.addGestureRecognizer(tap)
        
        mUserLoginToken = UserDefaults.standard.string(forKey: "token")
        mUserLoginTokenPos = UserDefaults.standard.string(forKey: "token_pos")
        
        mGCurrency.text = UserDefaults.standard.string(forKey: "currencySymbol") ?? "$"
        mBCurrency.text = UserDefaults.standard.string(forKey: "currencySymbol") ?? "$"
        
        if let mStoreCurr = UserDefaults.standard.string(forKey: "storeCurrency") as? String {
            mStoreCurrency = mStoreCurr
        }
        mCreditNoteTable.separatorStyle = .none
        
        if mCartTableData.count > 1 {
            mTotalItemsInCart.text = "\(mCartTableData.count) Items"
        }else{
            mTotalItemsInCart.text = "\(mCartTableData.count) Item"
        }
        
        if mOrderType == "Sales Order" {
            mTotalAm = mTotalP.replacingOccurrences(of: ",", with: "")
            mTotalTx.text = mTotalP
            mSubTotalTx.text = mSubTotalP
            mTaxAmountTx.text = mTaxAm
            mTaxValueTx.text = "Tax(\(mTaxP)%)"
            mTaxVal.text = mTaxP
            mFinalTaxAmount.text = mTaxAm
            self.mLabourCharge.text = "0"
            self.mShippingCharge.text = "0"
            self.mDiscountAmounts.text = "0"
            self.mDiscountPercents.text = "0"
        }else{
            mCreditNoteView.isHidden = false
            mCreditNotesView.isHidden = false
        }
        
        if let mData = UserDefaults.standard.object(forKey: "CREDITCARDDATA") as? NSArray {
            if mData.count > 0 {
                self.mPaymentData = mData
                self.mCollectionView.delegate = self
                self.mCollectionView.dataSource = self
                self.mCollectionView.reloadData()
            }
        }
        
        
        mFetchCreditNoteData(value: "")
        mCardNumber.keyboardType = .numberPad
        self.mCashLABEL.textColor = UIColor(named:"themeColor")
        self.mCreditCardLABEL.textColor = UIColor(named:"theme6A")
        self.mBankLABEL.textColor = UIColor(named:"theme6A")
        self.mCreditNoteLABEL.textColor = UIColor(named:"theme6A")
        self.mCashIcon.image = UIImage(named: "cashGreen")
        self.mCreditNoteIcon.image = UIImage(named: "creditnotegrey_ic")
        self.mCreditCardIcon.image = UIImage(named: "card_grey_ic")
        self.mBankIcon.image = UIImage(named: "bankgrey_ic")
        mTransactionType = "Cash"
        refreshCashPage()
        mChequeDetailsView.isHidden = true
        mTaxInfoView.isHidden = true
        mKeyBoardView.isHidden = false
        mCreditCardView.isHidden = true
        mEditCashView.isHidden = false
        mCreditNoteDetailsView.isHidden = true
        mCashView.backgroundColor = .clear
        mCardView.backgroundColor = UIColor(named: "themeShades")
        mBankView.backgroundColor = UIColor(named: "themeShades")
        mCreditNoteView.backgroundColor = UIColor(named: "themeShades")
        
        mShowDatePicker()
        mGetCurrency()
        mPartialPayment = UserDefaults.standard.string( forKey: "isPartialPayment") ?? "0"
        mFetchStore(key: "")
        getCustomerAddressList()
        mTabBarContainer.isHidden = true
        if let selectBtn = mIBSelect { selectBtn.isSelected = true }
        mSelectPaymentOptionContainer.isHidden = true
    }

    private func setupCashPageControl() {
        mPageControl.translatesAutoresizingMaskIntoConstraints = false
        mPageControl.numberOfPages = 1
        mPageControl.currentPage = 0
        mPageControl.hidesForSinglePage = false
        mPageControl.pageIndicatorTintColor = UIColor(red: 0.78, green: 0.78, blue: 0.78, alpha: 1)
        mPageControl.currentPageIndicatorTintColor = UIColor(red: 0.165, green: 0.165, blue: 0.165, alpha: 1) // #2A2A2A
        mPageControl.addTarget(self, action: #selector(cashPageChanged(_:)), for: .valueChanged)

        view.addSubview(mPageControl)
        view.bringSubviewToFront(mPageControl)
        NSLayoutConstraint.activate([
            mPageControl.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            mPageControl.bottomAnchor.constraint(equalTo: mKeyBoardView.topAnchor, constant: -16)
        ])

        let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(handleCashPageSwipe(_:)))
        swipeLeft.direction = .left
        swipeLeft.cancelsTouchesInView = false

        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(handleCashPageSwipe(_:)))
        swipeRight.direction = .right
        swipeRight.cancelsTouchesInView = false

        mEditCashView.addGestureRecognizer(swipeLeft)
        mEditCashView.addGestureRecognizer(swipeRight)
        refreshCashPage()
    }

    private func saveCurrentCashPage() {
        guard mCashPages.indices.contains(mCurrentCashPage) else { return }
        syncCurrentCashPageFromInput()
    }

    // Convert entered amount to STORE currency using the backend rate directly.
    private func syncCurrentCashPageFromInput() {
        guard mCashPages.indices.contains(mCurrentCashPage) else { return }

        let enteredAmount = Double(mCashAmounts) ?? 0
        let selectedCurrency = mCurrencyName.text ?? mStoreCurrency

        let rate: Double
        if selectedCurrency == mStoreCurrency || mExchangeRateLabel.isHidden {
            rate = 1
        } else {
            rate = Double(mExchangeRateValue.text ?? "") ?? 0
        }

        let convertedAmount = enteredAmount > 0 && rate > 0
            ? enteredAmount * rate
            : 0

        mCashPages[mCurrentCashPage].enteredAmount = enteredAmount
        mCashPages[mCurrentCashPage].amount = convertedAmount
        mCashPages[mCurrentCashPage].currency = selectedCurrency
        mCashPages[mCurrentCashPage].exchangeRate = rate

        mConvertedAmounts = "\(convertedAmount)"

        if enteredAmount > 0 && rate > 0 {
            let rounded = (convertedAmount * 100).rounded() / 100
            mConvertedAmount.text = "= \(mStoreCurrency) \(rounded)"
        } else if enteredAmount == 0 {
            mConvertedAmount.text = ""
        }
    }

    private func totalSubmittedCash() -> Double {
        mCashPages
            .filter { $0.isSubmitted }
            .reduce(0) { $0 + $1.amount }
    }

    private func refreshCashPage() {
        guard mCashPages.indices.contains(mCurrentCashPage) else { return }

        let page = mCashPages[mCurrentCashPage]

        if page.enteredAmount == 0 {
            mCashAmount.text = ""
            mCashAmounts = ""
            mConvertedAmounts = "0"
            mConvertedAmount.text = ""
        } else {
            let value: String
            if page.enteredAmount.rounded() == page.enteredAmount {
                value = String(Int(page.enteredAmount))
            } else {
                value = String(page.enteredAmount)
            }

            mCashAmount.text = value
            mCashAmounts = value
            mConvertedAmounts = "\(page.amount)"

            if page.amount > 0 {
                let rounded = (page.amount * 100).rounded() / 100
                mConvertedAmount.text = "= \(mStoreCurrency) \(rounded)"
            } else {
                mConvertedAmount.text = ""
            }
        }

        if !page.currency.isEmpty {
            mCurrencyName.text = page.currency
        }

        if page.currency == mStoreCurrency || page.currency.isEmpty {
            mExchangeRateLabel.isHidden = true
            mExchangeRateValue.isHidden = true
            mExchangeRateValue.text = ""
        } else {
            mExchangeRateLabel.isHidden = false
            mExchangeRateValue.isHidden = false
            mExchangeRateValue.text = String(format: "%.8f", page.exchangeRate)
        }

        mPageControl.numberOfPages = mCashPages.count
        mPageControl.currentPage = mCurrentCashPage
        mPageControl.isHidden = mTransactionType != "Cash"
    }

    @objc private func cashPageChanged(_ sender: UIPageControl) {
        guard mCashPages.indices.contains(sender.currentPage) else { return }
        saveCurrentCashPage()
        mCurrentCashPage = sender.currentPage
        refreshCashPage()
    }

    @objc private func handleCashPageSwipe(_ gesture: UISwipeGestureRecognizer) {
        guard mTransactionType == "Cash" else { return }
        saveCurrentCashPage()

        switch gesture.direction {
        case .left:
            guard mCurrentCashPage < mCashPages.count - 1 else {
                bounceCashPage(direction: -14)
                return
            }
            mCurrentCashPage += 1
        case .right:
            guard mCurrentCashPage > 0 else {
                bounceCashPage(direction: 14)
                return
            }
            mCurrentCashPage -= 1
        default:
            return
        }

        UISelectionFeedbackGenerator().selectionChanged()
        UIView.transition(
            with: mEditCashView,
            duration: 0.22,
            options: [.curveEaseInOut],
            animations: {
                self.refreshCashPage()
            }
        )
    }

    private func bounceCashPage(direction: CGFloat) {
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
        UIView.animate(withDuration: 0.08, animations: {
            self.mEditCashView.transform = CGAffineTransform(translationX: direction, y: 0)
        }) { _ in
            UIView.animate(withDuration: 0.16) {
                self.mEditCashView.transform = .identity
            }
        }
    }

    func mGetPaypalDataBackEnd() {

        guard let amountText = self.mCreditFillAmount.text,
              !amountText.isEmpty,
              let amount = Double(amountText),
              amount > 0 else {

            CommonClass.showSnackBar(message: "Please fill valid amount")
            return
        }

        let params: [String: Any] = [

            "amount": amountText,
            "slug": self.mSelectdPaymentMethod,
            "PaymentMethod": self.mPaymentMethod,
            "customerId": self.mCustomerId

        ]

        print("========== PAYPAL REQUEST ==========")
        print("URL =", mGeneratePaypalQRCode)
        print("PARAMS =", params)
        print("CLIENT ID =", mPaypalClientID)
        print("ENV =", mPaypalEnvironment)

        CommonClass.showFullLoader(view: self.view)

        AF.request(
            mGeneratePaypalQRCode,
            method: .post,
            parameters: params,
            encoding: JSONEncoding.default,
            headers: sGisHeaders2
        )
        .responseJSON { response in

            CommonClass.stopLoader()

            switch response.result {

            case .success:

                guard let jsonData = response.data,
                      let json = try? JSONSerialization.jsonObject(
                        with: jsonData
                      ) as? [String: Any] else {

                    CommonClass.showSnackBar(
                        message: "Invalid response"
                    )

                    return
                }

                print("========== PAYPAL RESPONSE ==========")
                print(json)

                guard let code = json["code"] as? Int else {

                    CommonClass.showSnackBar(
                        message: "Unknown error"
                    )

                    return
                }

                if code != 200 {

                    CommonClass.showSnackBar(
                        message: json["message"] as? String ?? "Payment failed"
                    )

                    return

                }

                guard
                    let data = json["data"] as? [String: Any]
                else {

                    CommonClass.showSnackBar(
                        message: "Invalid response"
                    )

                    return

                }

                self.mPaypalOrderID =
                    data["order_id"] as? String ?? ""

                self.mPaypalEncryptedPayload =
                    data["encryptedPayload"] as? String ?? ""

                print("PAYPAL ORDER ID =", self.mPaypalOrderID)
                print("PAYPAL PAYLOAD =", self.mPaypalEncryptedPayload)

                // PATCH 3
                 self.PayPalPayment()

            case .failure(let error):

                print(error)

                CommonClass.showSnackBar(
                    message: error.localizedDescription
                )

            }

        }

    }
    
    func PayPalPayment() {

        guard !mPaypalClientID.isEmpty else {

            CommonClass.showSnackBar(message: "PayPal Client ID not found")

            return

        }

        guard !mPaypalOrderID.isEmpty else {

            CommonClass.showSnackBar(message: "PayPal Order ID not found")

            return

        }

        let environment: CorePayments.Environment =
            mPaypalEnvironment.lowercased() == "live"
            ? .live
            : .sandbox
        
//        let environment: CorePayments.Environment = .sandbox

        print(environment)
        
        switch environment {
        case .live:
            print("SDK USING LIVE")
        case .sandbox:
            print("SDK USING SANDBOX")
        }
        
        let config = CoreConfig(

            clientID: mPaypalClientID,

            environment: environment

        )
        
        print("PAYPAL ENV =", mPaypalEnvironment)
        print("ORDER =", mPaypalOrderID)

        self.payPalConfig = config

        self.payPalClient = PayPalWebCheckoutClient(
            config: config
        )

        let request = PayPalWebCheckoutRequest(
            orderID: mPaypalOrderID
        )

        print("========== PAYPAL SDK ==========")
        print("CLIENT =", mPaypalClientID)
        print("ENV =", mPaypalEnvironment)
        print("ORDER =", mPaypalOrderID)

        payPalClient?.start(
            request: request
        ) { result in

            DispatchQueue.main.async {

                switch result {

//                case .success(let checkout):
//
//                    print("PAYPAL SUCCESS")
//
//                    print("ORDER =", checkout.orderID)
//
//                    print("PAYER =", checkout.payerID)
//
//                    self.mPaypalOrderID = checkout.orderID
//                    self.mPaypalPayerID = checkout.payerID
//                    // PATCH 3B
////                    self.paypalSuccess(
////                        orderID: checkout.orderID
////                    )
////                    self.paypalSuccess(
////                        orderID: checkout.orderID,
////                        payerID: checkout.payerID
////                    )
//                    self.paypalSuccess()
//
//
//
//                    let mCreditCardData = NSMutableDictionary()
//
//                    mCreditCardData.setValue(
//                        "PayPal",
//                        forKey: "name"
//                    )
//
//                    mCreditCardData.setValue(
//                        "",
//                        forKey: "card_number"
//                    )
//
//                    mCreditCardData.setValue(
//                        "PayPal",
//                        forKey: "card_name"
//                    )
//
//                    mCreditCardData.setValue(
//                        self.mPaymentMethod,
//                        forKey: "payment_method_id"
//                    )
//
//                    mCreditCardData.setValue(
//                        "",
//                        forKey: "logo"
//                    )
//
//                    mCreditCardData.setValue(
//                        self.mCreditFillAmount.text ?? "",
//                        forKey: "amount"
//                    )
//
//                    mCreditCardData.setValue(
//                        "Credit_Card",
//                        forKey: "Paymentmethod_type"
//                    )
//
//                    mCreditCardData.setValue(
//                        checkout.orderID,
//                        forKey: "client_reference_id"
//                    )
//
//                    self.mCreditCardMethod.add(
//                        mCreditCardData
//                    )
//
//                    DispatchQueue.main.async {
//
//                        self.recheckBalanceDue()
//
//                        self.mStripeCardView.isHidden = true
//
//                        self.mCreditCardBanksView.isHidden = false
//
//                        self.mCreditFillAmount.text = ""
//
//                        CommonClass.showSnackBar(
//                            message: "PayPal payment successful"
//                        )
//
//                    }
                    
                case .success(let checkout):

                    print("PAYPAL SUCCESS")
                    print("ORDER =", checkout.orderID)
                    print("PAYER =", checkout.payerID)

                    self.mPaypalOrderID = checkout.orderID
                    self.mPaypalPayerID = checkout.payerID

                    let mCreditCardData = NSMutableDictionary()

                    mCreditCardData.setValue(
                        "PayPal",
                        forKey: "name"
                    )

                    mCreditCardData.setValue(
                        "",
                        forKey: "card_number"
                    )

                    mCreditCardData.setValue(
                        "PayPal",
                        forKey: "card_name"
                    )

                    mCreditCardData.setValue(
                        self.mPaymentMethod,
                        forKey: "payment_method_id"
                    )

                    mCreditCardData.setValue(
                        "",
                        forKey: "logo"
                    )

                    mCreditCardData.setValue(
                        self.mCreditFillAmount.text ?? "",
                        forKey: "amount"
                    )

                    mCreditCardData.setValue(
                        "Credit_Card",
                        forKey: "Paymentmethod_type"
                    )

                    mCreditCardData.setValue(
                        checkout.orderID,
                        forKey: "client_reference_id"
                    )

                    
                    print("ORDER =", self.mPaypalOrderID)
                    print("PAYER =", self.mPaypalPayerID)
                    print("PAYLOAD =", self.mPaypalEncryptedPayload)
                    self.paypalSuccess { success in

                        print("CALLBACK =", success)

                        DispatchQueue.main.async {

                            print("INSIDE MAIN")

                            guard success else {

                                print("CAPTURE FAILED")

                                return
                            }

                            print("ADDING PAYMENT")
                            print("Credit BEFORE =", self.mCreditCardMethod)

                            self.mCreditCardMethod.add(mCreditCardData)

                            print("Credit AFTER =", self.mCreditCardMethod)
                            
                            var mAmounts = [Double]()
                            for i in self.mCreditCardMethod {
                                if let mData = i as? NSDictionary {
                                    mAmounts.append(
                                        Double("\(mData.value(forKey: "amount") ?? "0.0")"
                                            .replacingOccurrences(of: ",", with: "")) ?? 0.00
                                    )
                                }
                            }

                            self.mSubmittedCreditCard.text = "\(mAmounts.reduce(0, {$0 + $1}))"

                            print("RECHECK")
                            self.recheckBalanceDue()

                            
                        }
                    }
                    
                case .failure(let error):

                    print("PAYPAL ERROR")
                    print("========== PAYPAL FAILED ==========")
                    print(error.localizedDescription)
                    print(error)

                    CommonClass.showSnackBar(

                        message: error.localizedDescription

                    )

                }

            }

        }

    }
    
    func paypalSuccess(completion: @escaping (Bool) -> Void) {

        guard !mPaypalEncryptedPayload.isEmpty else {
            completion(false)
            return
        }

//        let urlString = "https://api2.gis247.net/api/v1/webhook/paypal-success-mobile?data=\(mPaypalEncryptedPayload)"
        let urlString = BaseUrl+"webhook/paypal-success-mobile?data=\(mPaypalEncryptedPayload)&token=\(mPaypalOrderID)"

        guard let url = URL(string: urlString) else {
            completion(false)
            return
        }

        print("========== PAYPAL SUCCESS API ==========")
        print("SUCCESS URL =", url.absoluteString)

        URLSession.shared.dataTask(with: url) { data, response, error in

            if let error = error {
                print(error)
                completion(false)
                return
            }

            if let http = response as? HTTPURLResponse {
                print("PAYPAL SUCCESS STATUS =", http.statusCode)
            }

            if let data = data,
               let text = String(data: data, encoding: .utf8) {
                print("PAYPAL SUCCESS RESPONSE =")
                print(text)
            }

            if let http = response as? HTTPURLResponse {
                completion(http.statusCode == 200)
            } else {
                completion(false)
            }

        }.resume()
    }
    
    
    
//    func paypalSuccess(completion: @escaping (Bool)->Void) {
//
//        var components = URLComponents(
//            string: "https://api2.gis247.net/api/v1/webhook/paypal-success-mobile"
//        )!
//
//        components.queryItems = [
//
//            URLQueryItem(
//                name: "data",
//                value: self.mPaypalEncryptedPayload//mPaypalOrderID//mPaypalPayload
//            )
//
//        ]
//
//        guard let url = components.url else {
//            return
//        }
//
//        URLSession.shared.dataTask(with: url) { data, response, error in
//
//            if let error = error {
//
//                print(error)
//
//                return
//
//            }
//
//            print("PAYPAL CAPTURE SUCCESS")
//
//        }.resume()
//
//    }
    
//    func paypalSuccess(orderID: String, payerID: String) {
//
//        print("ORDER =", orderID)
//        print("PAYER =", payerID)
//
//        let url = "https://api2.gis247.net/api/v1/webhook/paypal-success"
//
//        var components = URLComponents(string: url)!
//
//        components.queryItems = [
//
//            URLQueryItem(
//                name: "token",
//                value: orderID
//            ),
//
//            URLQueryItem(
//                name: "data",
//                value: mPaypalEncryptedPayload
//            )
//
//        ]
//
//        print("PAYPAL SUCCESS URL =")
//        print(components.url?.absoluteString ?? "")
//
//        URLSession.shared.dataTask(with: components.url!) { data, response, error in
//
//            if let error = error {
//
//                print(error)
//
//                return
//
//            }
//
//            print("PAYPAL CAPTURE SUCCESS")
//
//        }.resume()
//
//    }
    
    // MARK: - Delegates and Verification
    func isProceedWithStatus(status: Bool, message: String) { }
    
    func mGetDatePicker() { mShowDatePicker() }
    func mConfirmPayment(date: String, dateInGMT: Date, receiveAmount: String, outstanding: String, noOfReceived: String) {}
    func mCancelInstallment() {}
    func mGetReceiveAmount(masterData: NSArray, selectedData: NSMutableArray, totalInstallments: Int, totalMonths: Int, receivedAmount: Double, outstanding: Double, selectedInstallments: [Int]) {}
    func mGetScannedData(value: String, type: String) {
        if type == "GiftCard" { mGiftCardAmount.text = value }
    }
    func didTapCancelQRCode() { mCancelQRCode() }
    
    // The key Verify and Pay functions
    func isProceed(status: Bool) {
        if status {
            let storyBoard: UIStoryboard = UIStoryboard(name: "common", bundle: nil)
            if let mVerifyPin = storyBoard.instantiateViewController(withIdentifier: "VerifyPin") as? VerifyPin {
                mVerifyPin.delegate = self
                mVerifyPin.modalPresentationStyle = .overFullScreen
                mVerifyPin.transitioningDelegate = self
                self.present(mVerifyPin,animated: false)
            }
        }
    }
    
    func isVerified(status: Bool) {
        guard status else { return }
        submitVerifiedCheckout()
    }

    // MARK: - Verified checkout payload
    // Kept in POSCheckout so the POS storyboard continues to use this class while
    // sharing the current custom-order payload contract.
    private func checkoutAmount(_ text: String?) -> Double {
        let rawValue = text ?? ""
        let allowedCharacters = CharacterSet(charactersIn: "0123456789.-")
        let numericValue = rawValue.unicodeScalars
            .filter { allowedCharacters.contains($0) }
            .map(String.init)
            .joined()
        return Double(numericValue) ?? 0
    }

    private func checkoutCartWithDeliveryDates(currentDate: String) -> NSArray {
        let cart = NSMutableArray()

        for case let item as NSDictionary in mCartTableData {

            let updatedItem = item.mutableCopy() as! NSMutableDictionary

            let deliveryDate = "\(updatedItem["delivery_date"] ?? "")"

            print("📅 delivery_date from cart =", deliveryDate)

            if deliveryDate.isEmpty {
                updatedItem["delivery_date"] = currentDate
            }

            print("📤 sending delivery_date =", updatedItem["delivery_date"] ?? "")

            cart.add(updatedItem)
        }

        return cart
    }

    private func giftCardCheckoutCart(currentDate: String) -> NSArray {
        let cart = NSMutableArray()

        for case let item as NSDictionary in mCartTableData {
            let giftCardDetails = NSMutableDictionary()
            giftCardDetails["amount"] = item["amount_forcalculation"] ?? ""
            giftCardDetails["card_no"] = item["card_no"] ?? ""
            giftCardDetails["name"] = item["name"] ?? ""
            giftCardDetails["expire_date"] = item["expire_date"] ?? ""
            giftCardDetails["remark"] = item["remark"] ?? ""
            giftCardDetails["barcode"] = item["barcode"] ?? ""
            giftCardDetails["qr_code"] = item["qr_code"] ?? ""

            cart.add([
                "_id": item["custom_cart_id"] ?? "",
                "custom_cart_id": item["custom_cart_id"] ?? "",
                "delivery_date": currentDate,
                "giftCard_details": giftCardDetails
            ])
        }

        return cart
    }

    private func submitVerifiedCheckout() {
        print("DEBUG_SHIPPING: Billing: \(mSelectedBillingAddress)")
        print("DEBUG_SHIPPING: Shipping: \(mSelectedShippingAddress)")

        mFinalPaymentMethod = [String: Any]()

        let cashMethod = NSMutableDictionary()
        let creditNoteMethod = NSMutableDictionary()
        let debitedAmount = NSMutableDictionary()
        let payData = NSMutableDictionary()
        let paymentInfo = NSMutableDictionary()
        let summaryOrder = NSMutableDictionary()
        let sellInfo = NSMutableDictionary()

        let submittedCash = checkoutAmount(mSubmittedCash.text)
        let submittedBank = checkoutAmount(mSubmittedBankAmount.text)
        let submittedCreditCard = checkoutAmount(mSubmittedCreditCard.text)
        let submittedCreditNote = checkoutAmount(mSubmittedCreditNote.text)

        if let cashData = UserDefaults.standard.object(forKey: "CASHDATA") as? NSDictionary {
            cashMethod["payment_method_id"] = "\(cashData["id"] ?? "")"
            cashMethod["Paymentmethod_type"] = "cash"
            cashMethod["amount"] = submittedCash
        }

        debitedAmount["cash"] = submittedCash
        debitedAmount["bank"] = submittedBank
        debitedAmount["credit_card"] = submittedCreditCard
        debitedAmount["credit_notes"] = submittedCreditNote

        summaryOrder["labour"] = mLabourPoints
        summaryOrder["shipping"] = mShippingPoints
        summaryOrder["loyalty_points"] = mLoyaltyPoints
        summaryOrder["tax_amount"] = mTaxAmount
        summaryOrder["tax_amount_int"] = mTaxAmountInt
        summaryOrder["tax_prect"] = mTaxInPercent
        summaryOrder["tax_type"] = mTaxTypeIE
        summaryOrder["discount"] = mTaxDiscountAmount
        summaryOrder["discount_percent"] = mTaxDiscountPercent
        summaryOrder["customer_id"] = mCustomerId
        summaryOrder["sales_person_id"] = ""

        let fallbackRemark = UserDefaults.standard.string(forKey: "cRemark") ?? ""
        let finalRemark = mRemark.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            ? fallbackRemark
            : mRemark
        summaryOrder["remark"] = finalRemark
        summaryOrder["deposit"] = Int(mDepositPercents) ?? 0
        summaryOrder["deposit_amount"] = checkoutAmount(mTotalP)

//        let itemTotal = checkoutAmount(mCartTotalAmount)
//        summaryOrder["Sub_Total"] = itemTotal
        let grandTotal = checkoutAmount(mCartTotalAmount)

        let labour = mLabourPoints
        let shipping = mShippingPoints
        let discount = mTaxDiscountAmount
        var productTotal = 0.0

        for case let item as NSDictionary in mCartTableData {

            let qty = Double("\(item["Qty"] ?? "1")") ?? 1
            let price = checkoutAmount("\(item["cart_price"] ?? item["price"] ?? "0")")

            productTotal += price * qty
        }
        var subTotal = grandTotal

        if mTaxTypeIE.lowercased() == "inclusive" ||
           mTaxTypeIE.lowercased() == "exclusive" {

            subTotal = max(grandTotal - mTaxAmount, 0)
//            subTotal =
//            productTotal
//            - discount
//            + labour
//            + shipping
        }

        summaryOrder["Sub_Total"] = subTotal
        
        print("===== SUMMARY ORDER =====")
        print("Grand Total =", grandTotal)
        print("Tax Amount =", mTaxAmount)
        print("Sub Total =", subTotal)
        print("Tax Type =", mTaxTypeIE)
        
        let creditNoteTotal = mCreditData.reduce(0.0) { result, item in
            guard let value = item as? NSDictionary else { return result }
            return result + checkoutAmount("\(value["amount"] ?? "0")")
        }
        creditNoteMethod["ids"] = mCreditData
        creditNoteMethod["amount"] = creditNoteTotal
        creditNoteMethod["Paymentmethod_type"] = "CreditNote"

        payData["cash"] = cashMethod
        // POSCheckout has no separate Internet Banking collection. Preserve its
        // existing empty-IB behavior while using the newer payload shape.
        payData["IB"] = []
        payData["bank"] = mBankPayment
        payData["credit_card"] = mCreditCardMethod
        payData["credit_note"] = creditNoteMethod
        payData["gift_card"] = mGiftCardMethod

        let isoFormatter = ISO8601DateFormatter()
        isoFormatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        let currentDate = isoFormatter.string(from: Date())

        if mOrderType == "gift_card_order" {
            sellInfo["cart"] = giftCardCheckoutCart(currentDate: currentDate)
        } else {
            sellInfo["cart"] = checkoutCartWithDeliveryDates(currentDate: currentDate)
        }
        sellInfo["summary_order"] = summaryOrder
        sellInfo["status_type"] = mOrderType

        let cartTotal = checkoutAmount(mCartTotalAmount)
        sellInfo["totalamount"] = cartTotal > 0 ? cartTotal : checkoutAmount(mTotalWithDiscount)
        

        paymentInfo["debited_amount"] = debitedAmount
        paymentInfo["pay_data"] = payData
        paymentInfo["balance_due"] = ""
        paymentInfo["balance_deposit"] = ""

        mFinalPaymentMethod = [
            "sell_info": sellInfo,
            "payment_info": paymentInfo,
            "transaction_date": "",
            "customer_id": mCustomerId,
            "sales_person_id": "",
            "order_type": mOrderType,
            "order_id": mOrderId,
            "remark": finalRemark,
            "note": mNote
        ]

        let quotationId = UserDefaults.standard.string(forKey: "quotationId") ?? ""
        if !quotationId.isEmpty {
            mFinalPaymentMethod["quatation_id"] = quotationId
        }

        if !mSelectedBillingAddress.isEmpty || !mSelectedShippingAddress.isEmpty {
            mFinalPaymentMethod["shipping_info"] = [
                "billing_address": mSelectedBillingAddress,
                "shipping_address": mSelectedShippingAddress
            ]
        }

        if mOrderType == "custom_order" {
            let deliveryDate = mCartTableData.compactMap { item -> String? in
                guard let item = item as? NSDictionary else { return nil }
                let date = "\(item["delivery_date"] ?? "")"
                return date.isEmpty ? nil : date
            }.first ?? ""
//            mFinalPaymentMethod["delivery_date"] = deliveryDate
        }

        if mOrderType == "reserve" {
            for case let item as NSDictionary in mCartTableData {
                let crossLocationId = "\(item["crossLocationId"] ?? "")"
                guard !crossLocationId.isEmpty else { continue }
                mFinalPaymentMethod["crossLocationId"] = crossLocationId
                mFinalPaymentMethod["crosslocation"] = item["crosslocation"] as? Bool ?? false
                break
            }
        }

        // Preserve the existing POS cross-location reserve route as a fallback.
        if mOrderType == "reserve", mIsCrossLocationReserve, !mCrossLocationId.isEmpty {
            mFinalPaymentMethod["crossLocation"] = true
            mFinalPaymentMethod["crossLocationId"] = mCrossLocationId
        }

        let eligibleOrderTypes: Set<String> = [
            "custom_order", "mix_and_match", "pos_order", "repair_order",
            "exchange_order", "gift_card_order", "refund_order", "reserve",
            "reserve_diamond", "deposit"
        ]
        guard eligibleOrderTypes.contains(mOrderType) else {
            CommonClass.showSnackBar(message: "Unsupported order type.")
            return
        }

        print("POSCheckout DEBUG_VERIFIED_PAYLOAD =", mFinalPaymentMethod)
        CommonClass.showFullLoader(view: view)

        AF.request(
            mFinalCheckoutCustomOrder,
            method: .post,
            parameters: mFinalPaymentMethod,
            encoding: JSONEncoding.default,
            headers: sGisHeaders
        ).responseJSON { response in
            CommonClass.stopLoader()

            switch response.result {
            case .success(let value):
                guard let jsonResult = value as? NSDictionary else { return }
                if let code = jsonResult["code"] as? Int, code == 400 {
                    CommonClass.showSnackBar(message: "\(jsonResult["message"] ?? "OOP's something went wrong!")")
                    return
                }
                guard let data = jsonResult["data"] as? NSDictionary else { return }
                self.showCompletedPayment(data: data)

            case .failure(let error):
                CommonClass.showSnackBar(message: error.localizedDescription)
            }
        }
    }

    private func showCompletedPayment(data: NSDictionary) {
        let storyBoard = UIStoryboard(name: "posBoard", bundle: nil)
        guard let completePayment = storyBoard.instantiateViewController(withIdentifier: "CompletePayment") as? CompletePayment else {
            return
        }

        completePayment.mType = mOrderType
        completePayment.mOrderId = "\(data["id"] ?? "")"
        completePayment.mEmailId = "\(data["email"] ?? "")"
        completePayment.mTotalQuantity = "\(mCartTableData.count)"
        completePayment.mTotalOutstandingBal = mTotalOutstandingAm
        completePayment.mCurrency = mCurrencySymbol
        completePayment.mDepositPercents = mDepositPercents
        completePayment.mDepositAmount = mTotalP
        completePayment.mGrandTotalAmount = mCartTotalAmount
        completePayment.mUrl = "\(data["url"] ?? "")"
        completePayment.mShippingInfo = [
            "billing_address": mSelectedBillingAddress,
            "shipping_address": mSelectedShippingAddress
        ]
        navigationController?.pushViewController(completePayment, animated: true)
    }
    
    func removePaypalView() {

        guard let hosting = paypalHostingController else {

                return

            }
        hosting.willMove(toParent: nil)

        hosting.view.removeFromSuperview()

        hosting.removeFromParent()

        paypalHostingController = nil
//        paypalHostingController?.view.removeFromSuperview()
//
//        paypalHostingController?.removeFromParent()
//
//        paypalHostingController = nil
    }
    
//    func setupPaypalView(showCreditCardButton: Bool) {
//
//        removePaypalView()
//
//        let paypalView = PayPalCheckoutView(
//
//            showCreditCardButton: showCreditCardButton,
//
//            paypalAction: { [weak self] in
//                guard let self = self else { return }
//
//                self.removePaypalView()
//
//                if let paypalData = self.mPaymentData.first(where: {
//
//                    guard let dict = $0 as? NSDictionary else {
//                        return false
//                    }
//
//                    return "\(dict["payment_slag"] ?? "")"
//                        == "paypal-payment"
//
//                }) as? NSDictionary {
//
//                    self.mPaymentMethod =
//                        "\(paypalData["PaymentMethod"] ?? "")"
//
//                    self.mPaymentID =
//                        "\(paypalData["id"] ?? "")"
//
//                    self.mStripPublishKey =
//                        "\(paypalData["key"] ?? "")"
//
//                    self.mPaypalClientID =
//                        "\(paypalData["key"] ?? "")"
//
//                    self.mPaypalEnvironment =
//                        "\(paypalData["environment"] ?? "sandbox")"
//                            .lowercased()
//
//                    self.mCreditBankName.text = "PayPal"
//
//                    self.mSelectdPaymentMethod = "paypal-payment"
//
//                    print("PAYPAL_METHOD =", self.mPaymentMethod)
//                    print("PAYPAL_ID =", self.mPaymentID)
//                    print("PAYPAL_CLIENT_ID =", self.mPaypalClientID)
//                    print("PAYPAL_ENV =", self.mPaypalEnvironment)
//                }
//
//                self.mCardNumberContainer.isHidden = true
//                self.mCardNameContainer.isHidden = true
//
//                self.mCreditFillAmount.text = ""
//
//                self.mCreditFillAmount.becomeFirstResponder()
//            },
//
//            creditCardAction: { [weak self] in
//
//            guard let self = self else { return }
//
//            self.removePaypalView()
//
//            if let stripeData = self.mPaymentData.first(where: {
//
//                guard let dict = $0 as? NSDictionary else {
//                    return false
//                }
//
//                return "\(dict["payment_slag"] ?? "")"
//                    == "stripe-payment"
//
//            }) as? NSDictionary {
//
//                self.mPaymentMethod =
//                    "\(stripeData["PaymentMethod"] ?? "")"
//
//                self.mPaymentID =
//                    "\(stripeData["id"] ?? "")"
//
//                self.mStripPublishKey =
//                    "\(stripeData["key"] ?? "")"
//
//                self.mCreditBankName.text =
//                    "\(stripeData["name"] ?? "")"
//
//                self.mSelectdPaymentMethod =
//                    "stripe-payment"
//            }
//
//            self.mCardNumberContainer.isHidden = true
//            self.mCardNameContainer.isHidden = true
//
//            self.mCreditFillAmount.text = ""
//
//            self.mCreditFillAmount.becomeFirstResponder()
//        }
//    )
//
//        let hosting =
//        UIHostingController(rootView: paypalView)
//
//        addChild(hosting)
//
//        hosting.view.translatesAutoresizingMaskIntoConstraints = false
//
//        mStripeCardView.addSubview(hosting.view)
//
//        NSLayoutConstraint.activate([
//
//            hosting.view.topAnchor.constraint(
//                equalTo: mStripeCardView.topAnchor),
//
//            hosting.view.bottomAnchor.constraint(
//                equalTo: mStripeCardView.bottomAnchor),
//
//            hosting.view.leadingAnchor.constraint(
//                equalTo: mStripeCardView.leadingAnchor),
//
//            hosting.view.trailingAnchor.constraint(
//                equalTo: mStripeCardView.trailingAnchor)
//        ])
//
//        hosting.didMove(toParent: self)
//
//        paypalHostingController = hosting
//    }
//
//    func selectPayment(data: NSDictionary) {
//
//        mPaymentID =
//            "\(data["id"] ?? "")"
//
//        mPaymentMethod =
//            "\(data["PaymentMethod"] ?? "")"
////
////        mStripPublishKey =
////            "\(data["key"] ?? "")"
//
//        mStripPublishKey =
//            "\(data["key"] ?? "")"
//
//        mSelectdPaymentMethod =
//            "\(data["payment_slag"] ?? "")"
//
////        if mSelectdPaymentMethod == "paypal-payment" ||
////            "\(data["payment_slag"] ?? "")" == "paypal-payment" {
////
////            mPaypalClientID =
////                "\(data["key"] ?? "")"
////
////            mPaypalEnvironment =
////                "\(data["environment"] ?? "sandbox")"
////                    .lowercased()
////        }
//
//        if mSelectdPaymentMethod == "paypal-payment" {
//
//            mPaypalClientID =
//                "\(data["key"] ?? "")"
//
//            mPaypalEnvironment =
//                "\(data["environment"] ?? "sandbox")"
//                    .lowercased()
//        }
//        print("PAYPAL CLIENT =", mPaypalClientID)
//        print("PAYPAL ENV =", mPaypalEnvironment)
//        print("PAYPAL PAYMENT METHOD =", mPaymentMethod)
//
//
//        mCreditCardPaymentId =
//            "\(data["id"] ?? "")"
//
//        mCreditCardLogo =
//            "\(data["PayMethod_logo"] ?? "")"
//
//        mCreditCardName =
//            "\(data["name"] ?? "")"
//
//        mCreditBankImage.downlaodImageFromUrl(
//            urlString: mCreditCardLogo
//        )
//
//        if mSelectdPaymentMethod == "paypal-payment" {
//
//            mCreditBankName.text = "PayPal"
//
//        } else {
//
//            mCreditBankName.text =
//                "Debit or Credit Card"
//        }
//
//        mStripeCardView.isHidden = false
//
//        mCardNumberContainer.isHidden = true
//        mCardNameContainer.isHidden = true
//
//        mCreditFillAmount.text = ""
//
//        mCreditFillAmount.becomeFirstResponder()
//    }
    
    func setupPaypalView(showCreditCardButton: Bool) {

        removePaypalView()

//        let paypalView = PayPalCheckoutView(
//
//            showCreditCardButton: showCreditCardButton,
//
//            paypalAction: { [weak self] in
//
//                self?.showPaypalEnvironmentSelector()
//
//            },
//
//            creditCardAction: { [weak self] in
//
//                guard let self = self else { return }
//
//                self.removePaypalView()
//
//                if let stripeData = self.mPaymentData.first(where: {
//
//                    guard let dict = $0 as? NSDictionary else {
//                        return false
//                    }
//
//                    return "\(dict["payment_slag"] ?? "")" == "stripe-payment"
//
//                }) as? NSDictionary {
//
//                    self.selectPayment(data: stripeData)
//                }
//            }
//        )
        
        let paypalView = PayPalCheckoutView(

            showCreditCardButton: showCreditCardButton,

            paypalAction: { [weak self] in

                self?.showPaypalEnvironmentSelector()

            },

            creditCardAction: { [weak self] in

                guard let self = self else { return }

                if let stripeData = self.mPaymentData.first(where: {

                    guard let dict = $0 as? NSDictionary else {
                        return false
                    }

                    return "\(dict["payment_slag"] ?? "")" == "stripe-payment"

                }) as? NSDictionary {

                    self.selectPayment(data: stripeData)
                }
            }
        )

        let hosting = UIHostingController(rootView: paypalView)

        addChild(hosting)

        hosting.view.translatesAutoresizingMaskIntoConstraints = false

        mStripeCardView.addSubview(hosting.view)

        NSLayoutConstraint.activate([

            hosting.view.topAnchor.constraint(equalTo: mStripeCardView.topAnchor),
            hosting.view.bottomAnchor.constraint(equalTo: mStripeCardView.bottomAnchor),
            hosting.view.leadingAnchor.constraint(equalTo: mStripeCardView.leadingAnchor),
            hosting.view.trailingAnchor.constraint(equalTo: mStripeCardView.trailingAnchor)

        ])

        hosting.didMove(toParent: self)

        paypalHostingController = hosting
    }
    
    func showPaypalEnvironmentSelector() {

        let alert = UIAlertController(
            title: "Select PayPal",
            message: nil,
            preferredStyle: .actionSheet
        )

        if mPaypalSandboxData.count > 0 {

            alert.addAction(
                UIAlertAction(
                    title: "Sandbox",
                    style: .default
                ) { _ in

                    self.selectPayment(data: self.mPaypalSandboxData)

                }
            )
        }

        if mPaypalLiveData.count > 0 {

            alert.addAction(
                UIAlertAction(
                    title: "Live",
                    style: .default
                ) { _ in

                    self.selectPayment(data: self.mPaypalLiveData)

                }
            )
        }

        alert.addAction(
            UIAlertAction(
                title: "Cancel",
                style: .cancel
            )
        )

        present(alert, animated: true)
    }
    
    func selectPayment(data: NSDictionary) {

        removePaypalView()

        mSelectedPaypalMethodData = data
        
        mPaymentID =
            "\(data["id"] ?? "")"

        mPaymentMethod =
            "\(data["PaymentMethod"] ?? "")"

        mStripPublishKey =
            "\(data["key"] ?? "")"

        mSelectdPaymentMethod =
            "\(data["payment_slag"] ?? "")"

        if mSelectdPaymentMethod == "paypal-payment" {

            mPaypalClientID =
                "\(data["key"] ?? "")"

            mPaypalEnvironment =
                "\(data["environment"] ?? "sandbox")"
                    .lowercased()

            mCreditBankName.text = "PayPal"

        } else {

            mCreditBankName.text = "Debit or Credit Card"
        }

        print("========== PAYMENT SELECT ==========")
        print("NAME =", data["name"] ?? "")
        print("METHOD =", mPaymentMethod)
        print("CLIENT =", mPaypalClientID)
        print("ENV =", mPaypalEnvironment)

        mCreditCardPaymentId =
            "\(data["id"] ?? "")"

        mCreditCardLogo =
            "\(data["PayMethod_logo"] ?? "")"

        mCreditCardName =
            "\(data["name"] ?? "")"

//        mCreditBankImage.downlaodImageFromUrl(
//            urlString: mCreditCardLogo
//        )
//        mCreditBankName.text = mCreditCardName
        mCreditBankImage.downlaodImageFromUrl(urlString: mCreditCardLogo)

        mStripeCardView.isHidden = false

        mCardNumberContainer.isHidden = true
        mCardNameContainer.isHidden = true

//        mCreditFillAmount.text = ""
//        mCreditFillAmount.becomeFirstResponder()
        mCreditFillAmount.text =
        mBALANCEDUE.text?
            .replacingOccurrences(of: "$", with: "")
            .replacingOccurrences(of: ",", with: "")
            .trimmingCharacters(in: .whitespaces)

        mCreditFillAmount.becomeFirstResponder()
    }
    
    
    @IBAction func mPayNow(_ sender: UIButton) {
        sender.showAnimation{}
        if mOrderType == "refund_order" {
            mPayNowAlert()
            return
        }
        if (Double(mBALANCEDUE.text?.replacingOccurrences(of: ",", with: "") ?? "") ?? 0.00) == 0 {
            mPayNowAlert()
        }else{
            CommonClass.showSnackBar(message: "Please enter valid amount!")
        }
    }
    
    func mPayNowAlert(){
        mConfirmationPopUp.frame = self.view.bounds
        mConfirmationPopUp.delegate = self
        mConfirmationPopUp.mMessage.text = "Are you sure want to proceed ?".localizedString
        mConfirmationPopUp.mCancelButton.setTitle("CANCEL".localizedString, for: .normal)
        mConfirmationPopUp.mConfirmButton.setTitle("CONFIRM".localizedString, for: .normal)
        self.view.addSubview(mConfirmationPopUp)
    }

    // MARK: - PAY NOW
    func PayNow() {
        mFinalPaymentMethod = [String: Any]()
        let mCashMethod = NSMutableDictionary()
        let mCreditNoteMethod = NSMutableDictionary()
        let mDebitedAmount = NSMutableDictionary()
        let mPayData = NSMutableDictionary()
        let mPaymentInfo = NSMutableDictionary()
        let mSummaryOrder = NSMutableDictionary()
        let mSellInfo = NSMutableDictionary()

        if let mCashData = UserDefaults.standard.object(forKey: "CASHDATA") as? NSDictionary {
            mCashMethod.setValue("\(mCashData.value(forKey: "id") ?? "")", forKey: "payment_method_id")
            mCashMethod.setValue("cash", forKey: "Paymentmethod_type")
            mCashMethod.setValue(Double(self.mSubmittedCash.text ?? "") ?? 0.00, forKey: "amount")
        }

        mDebitedAmount.setValue(Double(self.mSubmittedCash.text ?? "") ?? 0.00, forKey: "cash")
        mDebitedAmount.setValue(Double(self.mSubmittedBankAmount.text ?? "") ?? 0.00, forKey: "bank")
        mDebitedAmount.setValue(Double(self.mSubmittedCreditCard.text ?? "") ?? 0.00, forKey: "credit_card")
        mDebitedAmount.setValue(Double(self.mSubmittedCreditNote.text ?? "") ?? 0.00, forKey: "credit_notes")

        mSummaryOrder.setValue(mLabourPoints, forKey: "labour")
        mSummaryOrder.setValue(mShippingPoints, forKey: "shipping")
        mSummaryOrder.setValue(mLoyaltyPoints, forKey: "loyalty_points")
        mSummaryOrder.setValue(mTaxAmount, forKey: "tax_amount")
        mSummaryOrder.setValue(mTaxAmountInt, forKey: "tax_amount_int")
        mSummaryOrder.setValue(mTaxInPercent, forKey: "tax_prect")
        mSummaryOrder.setValue(mTaxTypeIE, forKey: "tax_type")
        mSummaryOrder.setValue(mTaxDiscountAmount, forKey: "discount")
        mSummaryOrder.setValue(mTaxDiscountPercent, forKey: "discount_percent")
//        mSummaryOrder.setValue(self.mRemark, forKey: "remark")
        mSummaryOrder.setValue(mCustomerId, forKey: "customer_id")
        mSummaryOrder.setValue("", forKey: "sales_person_id")
        mSummaryOrder.setValue(Int(mDepositPercents), forKey: "deposit")
        mSummaryOrder.setValue(Double(mTotalP), forKey: "deposit_amount")

        var mCreditFinalTotalAmountObj = "0"
        var mAmount = [Double]()
        for item in mCreditData {
            if let value = item as? NSDictionary {
                mAmount.append(Double("\(value.value(forKey: "amount") ?? 0.00)") ?? 0.00)
            }
        }
        mCreditFinalTotalAmountObj = "\(mAmount.reduce(0, {$0 + $1}))"
        mCreditNoteMethod.setValue(mCreditData, forKey: "ids")
        mCreditNoteMethod.setValue(Double(mCreditFinalTotalAmountObj) ?? 0.00, forKey: "amount")
        mCreditNoteMethod.setValue("CreditNote", forKey: "Paymentmethod_type")

        mPayData.setValue(mCashMethod, forKey: "cash")
        mPayData.setValue(mBankPayment, forKey: "bank")
        mPayData.setValue([], forKey: "IB")
        mPayData.setValue(mCreditCardMethod, forKey: "credit_card")
        mPayData.setValue(mCreditNoteMethod, forKey: "credit_note")
        mPayData.setValue("", forKey: "gift_card")

        print("DEBUG_CART_DATA POSCheckout mPayNow = \(mCartTableData)")
        mSellInfo.setValue(mCartTableData, forKey: "cart")
        mSellInfo.setValue(mSummaryOrder, forKey: "summary_order")
        mSellInfo.setValue(mOrderType, forKey: "status_type")
        mSellInfo.setValue(Double(mTotalWithDiscount) ?? 0.00, forKey: "totalamount")
        
//        mSellInfo.setValue(mCartTableData, forKey: "cart")
        
        print("========== CART ITEMS ==========")

        for case let item as NSDictionary in mCartTableData {

            print(item)

        }

        print("===============================")

        print("========== CART DATA ==========")

        for item in mCartTableData {
            print(item)
        }

        print("===============================")

        mSellInfo.setValue(mSummaryOrder, forKey: "summary_order")
        mSellInfo.setValue(mOrderType, forKey: "status_type")
        mSellInfo.setValue(Double(mTotalWithDiscount) ?? 0.00, forKey: "totalamount")

        mPaymentInfo.setValue(mDebitedAmount, forKey: "debited_amount")
        mPaymentInfo.setValue(mPayData, forKey: "pay_data")
        mPaymentInfo.setValue("", forKey: "balance_due")
        mPaymentInfo.setValue("", forKey: "balance_deposit")

        mFinalPaymentMethod = [
            "sell_info": mSellInfo,
            "payment_info": mPaymentInfo,
            "transaction_date": "",
            "customer_id": self.mCustomerId,
            "sales_person_id": "",
            "order_type": self.mOrderType,
            "order_id": self.mOrderId,
            "remark": self.mRemark,
            "note": self.mNote
        ]
        
        var finalRemark = self.mRemark
        print("mSellInfo = \(mSellInfo)")
        print("mFinalPaymentMethod = \(mFinalPaymentMethod)")

        if let cartItems = self.mCartTableData as? NSArray {
            for item in cartItems {
                guard let data = item as? NSDictionary,
                      let serviceLabour = data["Service_labour"] as? NSDictionary else {
                    continue
                }

                let serviceRemark = "\(serviceLabour["service_remark"] ?? "")"
                    .trimmingCharacters(in: .whitespacesAndNewlines)

                if !serviceRemark.isEmpty {
                    finalRemark = serviceRemark
                    break
                }
            }
        }

        mFinalPaymentMethod["remark"] = finalRemark
        mFinalPaymentMethod["note"] = self.mNote
        print("DEBUG_ORDER_TYPE_API =", self.mOrderType)
        let mQuotationId = UserDefaults.standard.string(forKey: "quotationId") ?? ""
        if !mQuotationId.isEmpty {
            self.mFinalPaymentMethod["quatation_id"] = mQuotationId
        }

        if !mSelectedBillingAddress.isEmpty || !mSelectedShippingAddress.isEmpty {
            self.mFinalPaymentMethod["shipping_info"] = [
                "billing_address": self.mSelectedBillingAddress,
                "shipping_address": self.mSelectedShippingAddress
            ]
        }
        
        print("DEBUG_ORDER_TYPE =", mOrderType)

        if let shippingInfo = mFinalPaymentMethod["shipping_info"] {
            print("DEBUG_SHIPPING_INFO =", shippingInfo)
        } else {
            print("DEBUG_SHIPPING_INFO = NIL")
        }
        
        

//        let eligibleOrderTypes = ["custom_order", "mix_and_match", "pos_order", "repair_order", "exchange_order", "gift_card_order", "refund_order", "reserve", "deposit_order", "deposit"]
        let eligibleOrderTypes = [
            "custom_order",
            "mix_and_match",
            "pos_order",
            "repair_order",
            "exchange_order",
            "gift_card_order",
            "refund_order",
            "reserve",
            "reserve_diamond",
            "deposit"
        ]
        
        if self.mOrderType == "reserve",
           self.mIsCrossLocationReserve,
           !self.mCrossLocationId.isEmpty {

            mFinalPaymentMethod["crossLocation"] = true
            mFinalPaymentMethod["crossLocationId"] = self.mCrossLocationId
        }
        
        print("POSCheckout DEBUG_REMARK = \(self.mRemark)")
        print("POSCheckout DEBUG_PAYLOAD = \(mFinalPaymentMethod)")
        print("DEBUG_FINAL_PAYMENT POSCheckout =", mFinalPaymentMethod)
        if eligibleOrderTypes.contains(mOrderType) {
            CommonClass.showFullLoader(view: self.view)
            
            AF.request(mFinalCheckoutCustomOrder, method: .post, parameters: mFinalPaymentMethod, encoding: JSONEncoding.default, headers: sGisHeaders).responseJSON { response in
                CommonClass.stopLoader()
                
                switch response.result {
                case .success(let value):
                    guard let jsonResult = value as? NSDictionary else { return }
                    if let mCode = jsonResult.value(forKey: "code") as? Int, mCode == 400 {
                        CommonClass.showSnackBar(message: "\(jsonResult.value(forKey: "message") ?? "OOP's something went wrong!")")
                        return
                    }
                    if let mData = jsonResult.value(forKey: "data") as? NSDictionary {
                        let storyBoard: UIStoryboard = UIStoryboard(name: "posBoard", bundle: nil)
                        if let mCompletePayment = storyBoard.instantiateViewController(withIdentifier: "CompletePayment") as? CompletePayment {
                            print("====================================")
                            print("DEBUG CHECKOUT mOrderType =", self.mOrderType)
                            print("DEBUG ORDER ID =", "\(mData.value(forKey: "id") ?? "")")
                            print("====================================")
//                            if self.mOrderType == "refund_order" {
                                mCompletePayment.mType = self.mOrderType
//                            }
                            print("DEBUG COMPLETE mType =", mCompletePayment.mType)
                            mCompletePayment.mOrderId = "\(mData.value(forKey: "id") ?? "")"
                            mCompletePayment.mEmailId = "\(mData.value(forKey: "email") ?? "")"
                            mCompletePayment.mTotalQuantity = "\(self.mCartTableData.count)"
                            mCompletePayment.mTotalOutstandingBal = self.mTotalOutstandingAm
                            mCompletePayment.mCurrency = self.mCurrencySymbol
                            mCompletePayment.mDepositPercents = self.mDepositPercents
                            mCompletePayment.mDepositAmount = self.mTotalP
                            mCompletePayment.mGrandTotalAmount = self.mCartTotalAmount
                            mCompletePayment.mUrl = "\(mData.value(forKey: "url") ?? "")"
                            mCompletePayment.mShippingInfo = [
                                "billing_address": self.mSelectedBillingAddress,
                                "shipping_address":self.mSelectedShippingAddress
                            ]
                            
                            print("BILLING =", self.mSelectedBillingAddress)
                            print("SHIPPING =", self.mSelectedShippingAddress)
                            self.navigationController?.pushViewController(mCompletePayment, animated:true)
                        }
                    }
                case .failure(let error):
                    CommonClass.showSnackBar(message: error.localizedDescription)
                }
            }
        }
    }

    // MARK: - Actions
    @IBAction func mDeleteIBAmount(_ sender: Any) {
        if let text = mEnterAmountText?.text, text != "" {
            var newText = text
            newText.removeLast()
            mEnterAmountText?.text = newText
        }
    }
    
    @IBAction func mIBTabButton(_ sender: Any) {
        mSelectPaymentOptionContainer.isHidden = false
        mChequeDetailsView.isHidden = true
        if let ibBtn = mIBSelect { ibBtn.isSelected = true }
        if let chqBtn = mChequeSelect { chqBtn.isSelected = false }
        if let ibLbl = mIBTabSelect { ibLbl.backgroundColor = UIColor(named: "themeColor") }
        if let chqLbl = mChequeTabSelect { chqLbl.backgroundColor = UIColor(named: "themeExtraLightText") }
    }
    
    @IBAction func mChequeTabButton(_ sender: Any) {
        mSelectPaymentOptionContainer.isHidden = true
        mChequeDetailsView.isHidden = false
        if let chqBtn = mChequeSelect { chqBtn.isSelected = true }
        if let ibBtn = mIBSelect { ibBtn.isSelected = false }
        if let chqLbl = mChequeTabSelect { chqLbl.backgroundColor = UIColor(named: "themeColor") }
        if let ibLbl = mIBTabSelect { ibLbl.backgroundColor = UIColor(named: "themeExtraLightText") }
    }
    
    @IBAction func mBankSelect(_ sender: Any) {
        var mBankNames = ["Choose Bank"]
        let mBankTypeFilter = "IB"
        var mBankImage = ["https://art.gis247.net/assets/images/icon/camera_profile.png"]
        var mPMId = [""]
        if let mBankData = UserDefaults.standard.object(forKey: "BANKDATA") as? NSArray {
            if mBankData.count > 0 {
                for i in mBankData {
                    if let data = i as? NSDictionary {
                        if "\(data.value(forKey: "BankPaymenttype") ?? "")" == mBankTypeFilter {
                            mBankNames.append("\(data.value(forKey: "name") ?? "")")
                            mBankImage.append("\(data.value(forKey: "PayMethod_logo") ?? "")")
                            mPMId.append("\(data.value(forKey: "PaymentMethod") ?? "")")
                        }
                    }
                }
                let dropdown = DropDown()
                dropdown.anchorView = self.mCheqBankName
                dropdown.direction = .bottom
                dropdown.layer.cornerRadius = 15
                dropdown.backgroundColor = .white
                dropdown.bottomOffset = CGPoint(x: 0, y: 50)
                dropdown.width = self.view.frame.width - 32
                dropdown.dataSource = mBankNames
                dropdown.cellNib = UINib(nibName: "Currency", bundle: nil)
                dropdown.customCellConfiguration = { (index: Int, item: String, cell: DropDownCell) in
                    guard let cell = cell as? CurrencyCell else { return }
                    cell.mCurrencyImage.downlaodImageFromUrl(urlString: "\(mBankImage[index])")
                }
                dropdown.selectionAction = { [unowned self] (index: Int, item: String) in
                    self.mChequePaymentId = mPMId[index]
                    print("DEBUG_CURRENCY =", item)

                        print("DEBUG_RATE_ARRAY =",
                              self.mExchangeRateData)

                        print("DEBUG_SELECTED_RATE =",
                              index < self.mExchangeRateData.count
                              ? self.mExchangeRateData[index]
                              : "N/A")
                    if let sbn = self.mSelectedBankName { sbn.text = item }
                    if let sbi = self.mSelectedBankImage { sbi.downlaodImageFromUrl(urlString: mBankImage[index]) }
                }
                dropdown.show()
            } else {
                CommonClass.showSnackBar(message: "Please add authorised bank!")
            }
        }
    }
    
    @IBAction func mTakePhoto(_ sender: Any) {}
    
    @IBAction func mScanQRCOde(_ sender: Any) {
        if mEnterQRAmount?.text?.isEmpty == true || (Double(mEnterQRAmount?.text ?? "") ?? 0.0) == 0 {
            CommonClass.showSnackBar(message: "Please fill amount!")
            return
        }
        if let balanceDue = mBALANCEDUE.text {
            let formattedBalanceDue = balanceDue.replacingOccurrences(of: ",", with: "")
            let balanceDueInDouble = Double(formattedBalanceDue) ?? 0.0
            let inputAmount = Double(mEnterQRAmount?.text ?? "") ?? 0.0
            if (balanceDueInDouble - inputAmount) < 0 {
                CommonClass.showSnackBar(message: "Please fill valid amount!")
                return
            }
        }
        if mSelectedBankName?.text == "Choose Bank" || mSelectedBankName?.text?.isEmpty == true {
            CommonClass.showSnackBar(message: "Please choose a bank name!")
            return
        }
        mGenerateQRCode()
    }
    
    @IBAction func mGiftCardScan(_ sender: UIButton) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "transactions", bundle: nil)
        if let mCommonScanner = storyBoard.instantiateViewController(withIdentifier: "CommonScanner") as? CommonScanner {
            mCommonScanner.delegate = self
            mCommonScanner.mType = "GiftCard"
            mCommonScanner.modalPresentationStyle = .overFullScreen
            mCommonScanner.transitioningDelegate = self
            self.present(mCommonScanner,animated: true)
        }
    }
    
    @IBAction func mPaymentOptions(_ sender: UIButton) {
        mPaymentOptionIcon?.tintColor = UIColor(named: "themeColor")
        UIView.animate(withDuration: 1.0) {
            self.mPaymentOptionView?.isHidden = false
            self.view.layoutIfNeeded()
        }
    }
    
    @IBAction func mFullPaymentOption(_ sender: Any) {
        mPaymentOptionIcon?.tintColor = UIColor(named: "themeExtraLightText")
        UIView.animate(withDuration: 1.0) {
            self.mPaymentOptionView?.isHidden = true
            self.view.layoutIfNeeded()
        }
    }
    
    @IBAction func mLaybyOption(_ sender: Any) {
        mPaymentOptionIcon?.tintColor = UIColor(named: "themeExtraLightText")
        UIView.animate(withDuration: 1.0) {
            self.mPaymentOptionView?.isHidden = true
            self.view.layoutIfNeeded()
        }
    }
    
    @IBAction func mInstallmentOption(_ sender: Any) {
        mPaymentOptionIcon?.tintColor = UIColor(named: "themeExtraLightText")
        UIView.animate(withDuration: 1.0) {
            self.mPaymentOptionView?.isHidden = true
            self.view.layoutIfNeeded()
        }
    }
    
    func mResetPricings() {
        self.mSubmittedCash.text = "0.00"
        self.mSubmittedCreditCard.text = "0.00"
        self.mSubmittedCreditNote.text = "0.00"
        self.mSubmittedBankAmount.text = "0.00"
        self.mConvertedAmounts = "0"
        self.mConvertedAmount.text = ""
        self.mCashAmounts = ""
        self.mCashAmount.text = ""
        mFetchCreditNoteData(value: "")
    }
    
    @IBAction func mInstallmentDetails(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "laybyInstallment", bundle: nil)
        if let mInstallmentPicker = storyBoard.instantiateViewController(withIdentifier: "InstallmentPicker") as? InstallmentPicker {
            mInstallmentPicker.delegate = self
            mInstallmentPicker.mTotalAmount = Double(self.mTOTALAMOUNT.text ?? "0.00") ?? 0.00
            mInstallmentPicker.modalPresentationStyle = .overFullScreen
            mInstallmentPicker.transitioningDelegate = self
            self.present(mInstallmentPicker,animated: true)
        }
    }
    
    func mShowDatePicker(){
        let currentDate = Date()
        var datecomp = DateComponents()
        let min = Calendar.init(identifier: .gregorian)
        mDatePicker.preferredDatePickerStyle = .wheels
        datecomp.day = 0
        let minDates = min.date(byAdding: datecomp, to: currentDate)
        datecomp.year = 5
        let maxDates = min.date(byAdding: datecomp, to: currentDate)
        mDatePicker.minimumDate = minDates
        mDatePicker.maximumDate = maxDates
        mDatePicker.datePickerMode = .date
        mDatePicker.backgroundColor = .white
        let mToolBar = UIToolbar()
        mToolBar.sizeToFit()
        mToolBar.backgroundColor = .white
        mToolBar.barTintColor = .white
        let mDone = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(donePick))
        let mSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let mCancel = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(mCancelPick))
        mToolBar.setItems([mCancel, mSpace,mDone], animated: false)
        mPaymentConfirmation.mDueDate.inputAccessoryView = mToolBar
        mPaymentConfirmation.mDueDate.inputView = mDatePicker
        mPaymentConfirmation.mDueDate.becomeFirstResponder()
    }
    
    @objc func donePick(){
        let formatter = DateFormatter()
        formatter.calendar = Calendar(identifier: .gregorian)
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "dd/MM/yyyy"

        mConfirmQuote.mCurrentDate.text = formatter.string(from: mDatePicker.date)
        self.view.endEditing(true)
    }
    @objc func mCancelPick(){ self.view.endEditing(true) }
    
    @IBAction func mApplyGiftCard(_ sender: UIButton) {
        sender.showAnimation{}
        if mGiftCardAmount.text != "" {
            mApplyGiftCards(cardNumber: mGiftCardAmount.text ?? "")
        }else{
            CommonClass.showSnackBar(message: "Please fill valid details!")
        }
    }
    
    func mApplyGiftCards(cardNumber:String){
        let mLocation = UserDefaults.standard.string(forKey: "location") ?? ""
        let urlPath =  mApplyForGiftCard
        let params = ["Giftcard_code": cardNumber, "location_id":mLocation]
        if Reachability.isConnectedToNetwork() == true {
            CommonClass.showFullLoader(view: self.view)
            AF.request(urlPath, method:.post, parameters:params, headers: sGisHeaders2).responseJSON { [self] response in
                CommonClass.stopLoader()
                if(response.error != nil){
                    CommonClass.showSnackBar(message: "OOP's something went wrong!")
                }else{
                    guard let jsonData = response.data else { return }
                    let json = try? JSONSerialization.jsonObject(with: jsonData, options: [])
                    guard let jsonResult = json as? NSDictionary else { return }
                    if jsonResult.value(forKey: "code") as? Int == 200 {
                        guard let mCreditRow = jsonResult.value(forKey: "creditNote_row") as? NSDictionary else { return }
                        var isExist = false
                        for item in mCreditNoteData {
                            if let value = item as? NSDictionary {
                                if let id = value.value(forKey: "id") , "\(id)" == "\(mCreditRow.value(forKey: "id") ?? "")"{
                                    isExist = true
                                }
                            }
                        }
                        if !isExist {
                            CommonClass.showSnackBar(message: "Gift Card Added Successfully")
                            self.mSelectedIndex = [IndexPath]()
                            let mNewData = NSMutableDictionary()
                            mNewData.setValue("\(mCreditRow.value(forKey: "amount") ?? "0.0")", forKey: "amount")
                            mNewData.setValue("\(mCreditRow.value(forKey: "type") ?? "")", forKey: "type")
                            mNewData.setValue("\(mCreditRow.value(forKey: "date") ?? "")", forKey: "date")
                            mNewData.setValue("\(mCreditRow.value(forKey: "Ref_No") ?? "")", forKey: "Ref_No")
                            mNewData.setValue("\(mCreditRow.value(forKey: "id") ?? "")", forKey: "id")
                            mNewData.setValue(
                                "\(mCreditRow["currency"] ?? "")",
                                forKey: "currency"
                            )

                            mNewData.setValue(
                                "\(mCreditRow["diff_currency"] ?? "0")",
                                forKey: "diff_currency"
                            )
                            self.mCreditNoteData.add(mNewData)
                            var mAmount = [Double]()
                            self.mAmountData = NSMutableArray()
                            for item in mCreditNoteData {
                                if let value = item as? NSDictionary {
                                    let mCData = NSMutableDictionary()
                                    mAmount.append(Double("\(value.value(forKey: "amount") ?? "0.0")") ?? 0.0)
                                    mCData.setValue("\(value.value(forKey: "amount") ?? "0.0")", forKey: "amount")
                                    self.mTotalCreditAmount.text = String(format:"%.02f",locale:Locale.current,mAmount.reduce(0, {$0 + $1}))
                                    self.mAmountData.add(mCData)
                                }
                            }
                            self.mCreditNoteTable.delegate = self
                            self.mCreditNoteTable.dataSource = self
                            self.mCreditNoteTable.reloadData()
                            self.mGetTotalAmount()
                        }else{
                            CommonClass.showSnackBar(message: "Already Added!")
                        }
                    }else {
                        CommonClass.showSnackBar(message: "Invalid Card!")
                    }
                }
            }
        }
    }
    
    @IBAction func mDeleteCreditFillAmount(_ sender: Any) {
        var text = mCreditFillAmount.text ?? ""
        if text != "" {
            text.removeLast()
            mCreditFillAmount.text = text
        }
    }
    
    @IBAction func mCloseCreditView(_ sender: Any) {
        self.mCreditCardPaymentView.isHidden = true
    }
    
    @IBAction func mSubmitCreditAmount(_ sender: UIButton) {
        print("DEBUG_SUBMIT_PAYPAL")
        print("DEBUG_TEXT =", self.mCreditFillAmount.text ?? "nil")
        print("DEBUG_DOUBLE =", Double(self.mCreditFillAmount.text ?? "") ?? -1)
//        if let balanceDue = self.mBALANCEDUE.text {
//            let formattedBalanceDue = balanceDue.replacingOccurrences(of: ",", with: "")
//            let balanceDueInDouble = Double(formattedBalanceDue) ?? 0.0
//            let inputAmount = Double(self.mCreditFillAmount.text ?? "") ?? 0.0
//
//            print("DEBUG_AMOUNT =", inputAmount)
//            print("DEBUG_PAYMENT_SLAG =", mSelectdPaymentMethod)
//
//            if inputAmount <= balanceDueInDouble {
//                self.mGetStripeDataBackEnd()
//            } else {
//                CommonClass.showSnackBar(message: "Please fill a valid amount!")
//            }
//        }
        guard let balanceDue = self.mBALANCEDUE.text else {
                return
            }

            let formattedBalanceDue =
                balanceDue.replacingOccurrences(of: ",", with: "")

            let balanceDueInDouble =
                Double(formattedBalanceDue) ?? 0.0

            let inputAmount =
                Double(self.mCreditFillAmount.text ?? "") ?? 0.0
            print("INPUT =", inputAmount)
            print("BALANCE =", balanceDueInDouble)
            if inputAmount <= 0 {

                CommonClass.showSnackBar(
                    message: "Please fill valid amount!"
                )

                return
            }

            if inputAmount > balanceDueInDouble {

                CommonClass.showSnackBar(
                    message: "Please fill valid amount!"
                )

                return
            }

            if mSelectdPaymentMethod == "paypal-payment" {

                print("DEBUG_SUBMIT_PAYPAL")

//                mGetStripeDataBackEnd()
//                openPayPalCheckout()
                print("PayPal selected")
//                print("Waiting for PayPal backend flow")
//
//                CommonClass.showSnackBar(
//                    message: "Waiting for PayPal integration."
//                )
                mGetPaypalDataBackEnd()

                    return

            } else if mSelectdPaymentMethod == "stripe-payment" {

                print("DEBUG_SUBMIT_STRIPE")

                mGetStripeDataBackEnd()

            }
    }
    
    func mAddCredit(cardNumber:String, cardExp:String, cardCvc:String, amount:String){
        CommonClass.showFullLoader(view: self.view)
        let urlPath =  mCreditCardAdd
        let params = ["card_no": cardNumber, "card_cvc":cardCvc,"exp_month":cardExp,"card_holderName":UserDefaults.standard.string(forKey: "CUSTOMERID") ?? "" ,"method_id":mCreditCardPaymentId,"salesPerson_val": UserDefaults.standard.string(forKey: "SALESPERSONID") ?? "" ,"amount":amount]
        if Reachability.isConnectedToNetwork() == true {
            AF.request(urlPath, method:.post, parameters:params, headers: sGisHeaders2).responseJSON { [self] response in
                CommonClass.stopLoader()
                guard let jsonData = response.data, let json = try? JSONSerialization.jsonObject(with: jsonData, options: []) as? NSDictionary else { return }
                if json.value(forKey: "code") as? Int == 200 {
                    if let mData = json.value(forKey: "data") as? NSDictionary {
                        let mId = "\(mData.value(forKey: "insert_id") ?? "")"
                        let mCreditCardOptions = NSMutableDictionary()
                        mCreditCardOptions.setValue(self.mCreditCardPaymentId, forKey: "cardPaymentId")
                        mCreditCardOptions.setValue(amount, forKey: "amount")
                        mCreditCardOptions.setValue(mId, forKey: "id")
                        self.mCreditCardMethod.add(mCreditCardOptions)
                        var mAmount = [Double]()
                        for i in self.mCreditCardMethod {
                            if let mAM = i as? NSDictionary, let amt = mAM.value(forKey: "amount"), let dAmt = Double("\(amt)") {
                                mAmount.append(dAmt)
                            }
                        }
                        self.mSubmittedCreditCard.text = "\( mAmount.reduce(0, {$0 + $1}))"
                        recheckBalanceDue()
                    }
                }
            }
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return mPaymentData.count
    }
    
//    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
//        guard let cells = collectionView.dequeueReusableCell(withReuseIdentifier: "Collect",for:indexPath) as? Collect,
//              let mData = mPaymentData[indexPath.row] as? NSDictionary else { return UICollectionViewCell() }
//        cells.mImage.downlaodImageFromUrl(urlString: "\(mData.value(forKey: "PayMethod_logo") ?? "")")
//        cells.mName.text = mData.value(forKey: "name") as? String ?? ""
//        if mStripeIndex == indexPath.row {
//            mCreditCardPaymentId = "\(mData.value(forKey: "id") ?? "")"
//            mCreditCardName = "\(mData.value(forKey: "name") ?? "")"
//            mCreditCardLogo = "\(mData.value(forKey: "PayMethod_logo") ?? "")"
//            cells.mView.borderColor = UIColor(named: "themeColor")
//            cells.mView.borderWidth = 1
//            cells.mView.layer.cornerRadius = 10
//        }else {
//            cells.mView.borderWidth = 0
//            cells.mView.layer.cornerRadius = 10
//        }
//        return cells
//    }
    
    func collectionView(_ collectionView: UICollectionView,
                        cellForItemAt indexPath: IndexPath)
    -> UICollectionViewCell {

        guard let cells = collectionView.dequeueReusableCell(
            withReuseIdentifier: "Collect",
            for: indexPath
        ) as? Collect,
        let mData = mPaymentData[indexPath.row] as? NSDictionary
        else {
            return UICollectionViewCell()
        }

        let slug = "\(mData.value(forKey: "payment_slag") ?? "")"

//        if slug == "stripe-payment" {
//
//            cells.mName.text = "Debit or Credit Card"
//
//        } else if slug == "paypal-payment" {
//
//            cells.mName.text = "PayPal"
//
//        } else {
//
//            cells.mName.text =
//                "\(mData.value(forKey: "name") ?? "")"
//        }
        if slug == "stripe-payment" {

            cells.mName.text = "Debit or Credit Card"

        } else if slug == "paypal-payment" {

            let env = "\(mData["environment"] ?? "")".lowercased()

            if env == "sandbox" {

                cells.mName.text = "PayPal Sandbox"

            } else {

                cells.mName.text = "PayPal"

            }

        } else {

            cells.mName.text =
                "\(mData["name"] ?? "")"

        }

        cells.mImage.downlaodImageFromUrl(
            urlString: "\(mData.value(forKey: "PayMethod_logo") ?? "")"
        )

        return cells
    }
     
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        guard let layout = collectionViewLayout as? UICollectionViewFlowLayout else { return CGSize.zero }
        layout.minimumLineSpacing = 16
        return CGSize(width: (collectionView.frame.width / 2) - 16, height: (collectionView.frame.height / 2) - 16)
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
//        mStripeIndex = indexPath.row
        if let mData = mPaymentData[indexPath.row] as? NSDictionary {
            print(mData,"check payment data ")
            
            let env = "\(mData["environment"] ?? "")".lowercased()
            print("Selected PayPal Environment =", env)
            mCreditFillAmount.text = "\(Double(self.mCartTotalAmount) ?? 0)"
            
            mCreditFillAmount.text = "\(Double(self.mCartTotalAmount) ?? 0)"
            
            let slug = "\(mData["payment_slag"] ?? "")"
            
            if slug == "paypal-payment" {
                
                let env = "\(mData["environment"] ?? "")".lowercased()
                
                if env == "sandbox" {
                    self.selectPayment(data: self.mPaypalSandboxData)
                } else {
                    self.selectPayment(data: self.mPaypalLiveData)
                }
                
            } else {
                
                // Stripe และ Payment อื่น ๆ ใช้ตัวที่ผู้ใช้เลือก
                self.selectPayment(data: mData)
            }
            
            self.mCreditCardBanksView.isHidden = true
            self.mStripeCardView.isHidden = false
        }
//        if let mData = mPaymentData[indexPath.row] as? NSDictionary {
//            print("DEBUG_CELL =", mData)
//            mCreditCardPaymentId = "\(mData.value(forKey: "id") ?? "")"
//            mCreditCardName = "\(mData.value(forKey: "name") ?? "")"
//            mCreditCardLogo = "\(mData.value(forKey: "PayMethod_logo") ?? "")"
//            mPaymentID = "\(mData.value(forKey: "id") ?? "")"
//            mPaymentMethod = "\(mData.value(forKey: "PaymentMethod") ?? "")"
//            mStripPublishKey = "\(mData.value(forKey: "key") ?? "")"
//
//            mPaypalClientID =
//                "\(mData["key"] ?? "")"
//
//            mPaypalEnvironment =
//                "\(mData["environment"] ?? "live")"
//                    .lowercased()
//
//            print("PAYPAL CLIENT =", mPaypalClientID)
//            print("PAYPAL ENV =", mPaypalEnvironment)
//
//            print("DEBUG_SELECTED_ROW =", indexPath.row)
//            print("DEBUG_SELECTED_NAME =", mData.value(forKey: "name") ?? "")
//            print("DEBUG_SELECTED_SLAG =", mData.value(forKey: "payment_slag") ?? "")
//
//            mSelectdPaymentMethod = "\(mData.value(forKey: "payment_slag") ?? "")"
//            self.mCreditBankImage.downlaodImageFromUrl(urlString: "\(mData.value(forKey: "PayMethod_logo") ?? "")")
//            self.mCreditBankName.text = mData.value(forKey: "name") as? String
//            mCardNumber.text = ""
//            mCardName.text = ""
//            mCreditFillAmount.text = ""
//            self.mStripeCardView.isHidden = false
//            print("DEBUG_STRIPE_FRAME =", self.mStripeCardView.frame)
//            print("DEBUG_STRIPE_BOUNDS =", self.mStripeCardView.bounds)
//            self.mCreditCardBanksView.isHidden = true
////            if mSelectdPaymentMethod == "stripe-payment" || mSelectdPaymentMethod == "paypal-payment" {
////                self.mCardNumberContainer.isHidden = true
////                self.mCardNameContainer.isHidden = true
////                setupPaypalView()
////            }else {
////                self.mCardNumberContainer.isHidden = false
////                self.mCardNameContainer.isHidden = false
////            }
////            if mSelectdPaymentMethod == "stripe-payment" {
////
////                self.mCreditBankName.text = "Debit or Credit Card"
////
////            } else if mSelectdPaymentMethod == "paypal-payment" {
////
////                self.mCreditBankName.text = "PayPal"
////
////            } else {
////
////                self.mCreditBankName.text =
////                    mData.value(forKey: "name") as? String
////            }
//
//            if mSelectdPaymentMethod == "stripe-payment" {
//
//                self.mCreditBankName.text =
//                    "Debit or Credit Card"
//
//            } else if mSelectdPaymentMethod == "paypal-payment" {
//
//                if mPaypalEnvironment == "sandbox" {
//
//                    self.mCreditBankName.text =
//                        "PayPal Sandbox"
//
//                } else {
//
//                    self.mCreditBankName.text =
//                        "PayPal"
//
//                }
//
//            } else {
//
//                self.mCreditBankName.text =
//                    mData.value(forKey: "name") as? String
//            }
//
//            mCardNumber.text = ""
//            mCardName.text = ""
//            mCreditFillAmount.text = ""
//
//            self.mCreditCardBanksView.isHidden = true
//            self.mStripeCardView.isHidden = false
//
//            self.mCardNumberContainer.isHidden = true
//            self.mCardNameContainer.isHidden = true
//
//            self.mCollectionView.reloadData()
//        }
//        print("DEBUG_PAYMENT_VIEW_HIDDEN =", mCreditCardPaymentView.isHidden)
//        print("DEBUG_STRIPE_HIDDEN =", mStripeCardView.isHidden)
//        print("DEBUG_BANK_VIEW_HIDDEN =", mCreditCardBanksView.isHidden)
//
//        print("DEBUG_CARD_CONTAINER =", mCardNumberContainer.isHidden)
//        print("DEBUG_NAME_CONTAINER =", mCardNameContainer.isHidden)
//        print("DEBUG_PAYMENT_SLAG =", mSelectdPaymentMethod)
//        print("DEBUG_STRIPE_HIDDEN =", mStripeCardView.isHidden)
//        print("DEBUG_BANK_HIDDEN =", mCreditCardBanksView.isHidden)
    }
    
    func mFetchStore(key: String){
        let mLocation = UserDefaults.standard.string(forKey: "location") ?? ""
        let urlPath =  mFetchPaymentMethod
        if Reachability.isConnectedToNetwork() == true {
            AF.request(urlPath, method:.post, parameters:["login_token": mUserLoginToken ?? "", "location_id":mLocation], headers: sGisHeaders2).responseJSON { response in
                print("DEBUG_PAYMENT_RESPONSE_DATA = ", response)
                guard let jsonData = response.data, let json = try? JSONSerialization.jsonObject(with: jsonData, options: []) as? NSDictionary else { return }
                if json.value(forKey: "code") as? Int == 200 {
                    if let mPaymentMethod = json.value(forKey: "data") as? NSDictionary {
                        
                        print("mFetchStore mPaymentMethod = \(mPaymentMethod)")
                        
                        
                        
//                        if let mData = mPaymentMethod["Credit_Card"] as? NSArray,
//                           mData.count > 0 {
//
//                            self.mPaymentData = mData
//
//                        } else if let mData = mPaymentMethod["Bank"] as? NSArray,
//                                  mData.count > 0 {
//
//                            self.mPaymentData = mData
//                        }
                        
                        if let mData = mPaymentMethod["Credit_Card"] as? NSArray,
                           mData.count > 0 {

                            self.mPaymentData = mData

                        } else {

                            self.mPaymentData = []
                        }
                        
                        
                        
                        self.mCollectionView.reloadData()

                        print("DEBUG_PAYMENT_COUNT =", self.mPaymentData.count)
                        print("DEBUG_PAYMENT_DATA =", self.mPaymentData)
                        
                        for item in self.mPaymentData {

                            guard let dict = item as? NSDictionary else {
                                continue
                            }

                            let slug = "\(dict["payment_slag"] ?? "")"

                            let env = "\(dict["environment"] ?? "")".lowercased()

                            if slug == "paypal-payment" {

                                if env == "sandbox" {

                                    self.mPaypalSandboxData = dict

                                } else if env == "live" {

                                    self.mPaypalLiveData = dict

                                }

                            }

                        }

                        self.mCollectionView.delegate = self
                        self.mCollectionView.dataSource = self
                        self.mCollectionView.reloadData()
                    }
                    
//                    if let mPaymentMethod = json.value(forKey: "data") as? NSDictionary, let mData = mPaymentMethod.value(forKey: "Credit_Card") as? NSArray, mData.count > 0 {
//                        self.mPaymentData = mData
//                        print("DEBUG_PAYMENT_COUNT =", self.mPaymentData.count)
//                        print("DEBUG_PAYMENT_DATA =", self.mPaymentData)
//                        self.mCollectionView.delegate = self
//                        self.mCollectionView.dataSource = self
//                        self.mCollectionView.reloadData()
//                    }
                }
            }
        }
    }
    
    @IBAction func mDeleteChequeAmount(_ sender: Any) {
        var text = mChequeAmount.text ?? ""
        if text != "" {
            text.removeLast()
            mChequeAmount.text = text
            if text == "" {
                self.mSubmittedBankAmount.text = "0.0"
                mChequePaymentId = ""
                mChequeData = NSMutableDictionary()
                recheckBalanceDue()
            }
        }
    }
    
    @IBAction func mChooseCheqDate(_ sender: Any) {}
    
    @IBAction func mChooseBanks(_ sender: Any) {
        var mBankNames = ["Choose Bank"]
        let mBankTypeFilter = "Cheque"
        var mBankImage = ["https://art.gis247.net/assets/images/icon/camera_profile.png"]
        var mPMId = [""]
        if let mBankData = UserDefaults.standard.object(forKey: "BANKDATA") as? NSArray {
            if mBankData.count > 0 {
                for i in mBankData {
                    if let data = i as? NSDictionary {
                        if "\(data.value(forKey: "BankPaymenttype") ?? "")" == mBankTypeFilter {
                            mBankNames.append("\(data.value(forKey: "name") ?? "")")
                            mBankImage.append("\(data.value(forKey: "PayMethod_logo") ?? "")")
                            mPMId.append("\(data.value(forKey: "id") ?? "")")
                        }
                    }
                }
                let dropdown = DropDown()
                dropdown.anchorView = self.mCheqBankName
                dropdown.direction = .bottom
                dropdown.layer.cornerRadius = 15
                dropdown.backgroundColor = .white
                dropdown.bottomOffset = CGPoint(x: 0, y: 50)
                dropdown.width = self.view.frame.width - 32
                dropdown.dataSource = mBankNames
                dropdown.cellNib = UINib(nibName: "Currency", bundle: nil)
                dropdown.customCellConfiguration = { (index: Int, item: String, cell: DropDownCell) in
                    guard let cell = cell as? CurrencyCell else { return }
                    cell.mCurrencyImage.downlaodImageFromUrl(urlString: "\(mBankImage[index])")
                }
                dropdown.selectionAction = { [unowned self] (index: Int, item: String) in
                    print("DEBUG_CURRENCY =", item)

                        print("DEBUG_RATE_ARRAY =",
                              self.mExchangeRateData)

                        print("DEBUG_SELECTED_RATE =",
                              index < self.mExchangeRateData.count
                              ? self.mExchangeRateData[index]
                              : "N/A")
                    self.mChequePaymentId = mPMId[index]
                    self.mCheqBankName.text = item
                    self.mCheqBankImage.downlaodImageFromUrl(urlString: mBankImage[index])
                }
                dropdown.show()
            } else {
                CommonClass.showSnackBar(message: "Please add authorised bank!")
            }
        }
    }
    
    @IBAction func mSubmitCheque(_ sender: UIButton) {
        sender.showAnimation{}
        if mChequeAmount.text == "" || (Double(mChequeAmount.text!) ?? 0.0) == 0 {
            CommonClass.showSnackBar(message: "Please fill amount!")
        } else if mCheqDate.text == "" {
            CommonClass.showSnackBar(message: "Please choose date!")
        }else if mCheqAccountNumber.text == "" {
            CommonClass.showSnackBar(message: "Please fill account number!")
        }else if mCheqAccountName.text == "" {
            CommonClass.showSnackBar(message: "Please fill acoount holder name!")
        }else if mCheqBankName.text == "Choose Bank" {
            CommonClass.showSnackBar(message: "Please choose bank name!")
        }else if mCheqRefNumber.text == "" {
            CommonClass.showSnackBar(message: "Please fill reference number!")
        }else if mCheqInstNumber.text == "" {
            CommonClass.showSnackBar(message: "Please fill Inst number!")
        }else{
            if let balanceDue = mBALANCEDUE.text {
                let formattedBalanceDue = balanceDue.replacingOccurrences(of: ",", with: "")
                let balanceDueInDouble = Double(formattedBalanceDue) ?? 0.0
                let inputAmount = Double(mChequeAmount.text ?? "") ?? 0.0
                if (balanceDueInDouble - inputAmount) < 0 {
                    CommonClass.showSnackBar(message: "Please fill valid amount!")
                    recheckBalanceDue()
                    return
                }
            }
            mChequeData = NSMutableDictionary()
            mChequeData.setValue(mCheqDate.text ?? "", forKey: "transaction_date")
            mChequeData.setValue(mCheqAccountNumber.text ?? "", forKey: "ac_no")
            mChequeData.setValue(mCheqAccountName.text ?? "", forKey: "ac_name")
            mChequeData.setValue(mChequePaymentId, forKey: "payment_method_id")
            mChequeData.setValue(mCheqRefNumber.text ?? "", forKey: "ref_no")
            mChequeData.setValue(mCheqInstNumber.text ?? "", forKey: "inst_no")
            mChequeData.setValue(mChequeAmount.text ?? "", forKey: "amount")
            mChequeData.setValue("Bank", forKey: "Paymentmethod_type")
            self.mBankPayment.add(mChequeData)

            var mAmounts = [Double]()
            for i in mBankPayment{
                if let mData = i as? NSDictionary {
                    mAmounts.append(Double("\(mData.value(forKey: "amount") ?? "0.0")".replacingOccurrences(of: ",", with: "")) ?? 0.00)
                }
            }
            mSubmittedBankAmount.text = "\(mAmounts.reduce(0, {$0 + $1}))"
            recheckBalanceDue()
            self.mCheqDate.text = ""
            self.mCheqAccountNumber.text = ""
            self.mCheqAccountName.text = ""
            self.mChequePaymentId = ""
            mCheqBankName.text = "Choose Bank"
            self.mCheqRefNumber.text = ""
            self.mChequeAmount.text = ""
            self.mCheqInstNumber.text = ""
            CommonClass.showSnackBar(message: "Amount added successfully")
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return mCreditNoteData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        tableView.showsVerticalScrollIndicator = false
        tableView.showsHorizontalScrollIndicator = false
        guard let cells = tableView.dequeueReusableCell(withIdentifier: "CreditNoteList") as? CreditNoteList else { return UITableViewCell() }
        if let mData =  mCreditNoteData[indexPath.row] as? NSDictionary {
            cells.mType.text = mData.value(forKey: "type") as? String
            cells.mRefNo.text = mData.value(forKey: "Ref_No") as? String
            cells.mDate.text = mData.value(forKey: "date") as? String
            cells.mAmount.tag = indexPath.row
            cells.mView.backgroundColor = (indexPath.row % 2 == 0) ? UIColor(named: "themeBackground") : UIColor(red: 0.95, green: 0.95, blue: 0.95, alpha: 1)
            
            if mSelectedCustomIndex.contains(indexPath) {
                if let mDataSet = mAmountData[indexPath.row] as? NSDictionary {
                    cells.mAmount.text = "\(mDataSet.value(forKey: "amount") ?? "0.0")"
                }
            }else{
                cells.mAmount.text = "\(mData.value(forKey: "amount") ?? "0.0")"
            }
            cells.mCheckImage.image = UIImage(named: mSelectedIndex.contains(indexPath) ? "check_item" : "uncheck_item" )
            cells.layoutSubviews()
        }
        return cells
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let mData = mCreditNoteData[indexPath.row] as? NSDictionary else {
            return
        }

        let diffCurrency = "\(mData["diff_currency"] ?? "0")"

        if diffCurrency == "1" {

            CommonClass.showSnackBar(
                message: "Apologies for the inconvenience!\nThis credit note is in a different currency and cannot be encashed here."
            )

            return
        }
        if mSelectedIndex.contains(indexPath) {
            mSelectedIndex = mSelectedIndex.filter {$0 != indexPath }
        }else{
            mSelectedIndex.append(indexPath)
        }
        self.mGetTotalAmount()
        self.mCreditNoteTable.reloadData()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat { return 60 }
    
    @IBAction func mAmountEdit(_ sender: UITextField) {
        if let mMaxData = mCreditNoteData[sender.tag] as? NSDictionary{
            let mMaxAmount = Double("\(mMaxData.value(forKey: "amount") ?? "0.0")") ?? 0
            if sender.text == ""  {
                mAddCreditAmount(text: "0", index: sender.tag)
                return
            }
            if Double("\(sender.text ?? "")") ?? 0 > mMaxAmount   {
                sender.text = "\(mMaxData.value(forKey: "amount") ?? "0.0")"
            }
            mAddCreditAmount(text: sender.text ?? "", index: sender.tag)
        }
    }
    
    func mAddCreditAmount(text : String , index : Int ){
        let mIndexPath = IndexPath(row:index,section: 0)
        let mData = NSMutableDictionary()
        mData.setValue(text, forKey: "amount")
        mAmountData.removeObject(at: index)
        mAmountData.insert(mData, at:  index)
        if !self.mSelectedCustomIndex.contains(mIndexPath) {
            self.mSelectedCustomIndex.append(mIndexPath)
        }
        mGetTotalAmount()
    }
    
    func mGetTotalAmount(){
        var mAmount = [Double]()
        var indexPath = IndexPath()
        mCreditData = NSMutableArray()
        mCreditDataMerged = NSMutableArray()
        mGiftCardMethod =  NSMutableArray()
        for index in 0...mAmountData.count - 1 {
            indexPath = IndexPath(row:index,section: 0)
            if mSelectedIndex.contains(indexPath){
                if let mData = mAmountData[index] as? NSDictionary {
                    mAmount.append(Double("\(mData.value(forKey: "amount") ?? "0.0")") ?? 0.0)
                    let mCData = NSMutableDictionary()
                    mCData.setValue("\(mData.value(forKey: "amount") ?? "0.0")", forKey: "amount")
                    if let mMaxData =  mCreditNoteData[index] as? NSDictionary {
                        mCData.setValue("\(mMaxData.value(forKey: "id") ?? "")", forKey: "payment_method_id")
                    }
                    mCreditData.add(mCData)
                    mCreditDataMerged.add(mCData)
                }
            }
        }
        
        mItemsSelected.text = "\(mSelectedIndex.count) " + (mSelectedIndex.count == 1 ? "Item Selected".localizedString : "Items Selected".localizedString)
        mTotalSelectedAmount.text = String(format:"%.02f",locale:Locale.current,mAmount.reduce(0, {$0 + $1}))
        self.mSubmittedCreditNote.text = mTotalSelectedAmount.text?.replacingOccurrences(of: ",", with: "")
        recheckBalanceDue()
    }
    
    @IBAction func mSubmitCredit(_ sender: Any) { mGetTotalAmount() }
    @IBAction func mBack(_ sender: Any) { self.navigationController?.popViewController(animated: true) }
    @IBAction func mAddCustomer(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        if let home = storyBoard.instantiateViewController(withIdentifier: "RegisterCustomer") as? RegisterCustomer {
            self.navigationController?.pushViewController(home, animated:true)
        }
    }
    
    func setupPapalAllView() {
        mTabBarContainer.isHidden = true
        mSelectPaymentOptionContainer.isHidden = true
        guard mOrderType != "refund_order" else {
            return
        }
        mTransactionType = "CreditCard"
        mTaxInfoView.isHidden = true
        mKeyBoardView.isHidden = true
        mChequeDetailsView.isHidden = true
        mCreditCardView.isHidden = true
        mCreditNoteDetailsView.isHidden = true
        mEditCashView.isHidden = true
        self.mCreditCardPaymentView.isHidden = false
        self.mCreditCardBanksView.isHidden = false
        self.mStripeCardView.isHidden = true

        mCardView.backgroundColor = .clear
        mCashView.backgroundColor = UIColor(named: "themeShades")
        mBankView.backgroundColor = UIColor(named: "themeShades")
        mCreditNoteView.backgroundColor = UIColor(named: "themeShades")

        self.mCashLABEL.textColor = UIColor(named:"theme6A")
        self.mCreditCardLABEL.textColor = UIColor(named:"themeColor")
        self.mBankLABEL.textColor = UIColor(named:"theme6A")
        self.mCreditNoteLABEL.textColor = UIColor(named:"theme6A")
        self.mCashIcon.image = UIImage(named: "cashgrey_ic")
        self.mCreditNoteIcon.image = UIImage(named: "creditnotegrey_ic")
        self.mCreditCardIcon.image = UIImage(named: "cardGreen")
        self.mBankIcon.image = UIImage(named: "bankgrey_ic")
        self.mCreditCardIcon.showAnimation {}
        self.mCreditCardLABEL.showAnimation {}
    }
    
    @IBAction func mBackCreditCardForm(_ sender: Any) {
//        self.mCreditCardBanksView.isHidden = false
//        self.mStripeCardView.isHidden = true
//        self.mCreditCardBanksView.isHidden = false
//        self.mStripeCardView.isHidden = true
        view.endEditing(true)

        mCreditFillAmount.text = ""

//        let hasStripe = mPaymentData.contains {
//
//            guard let dict = $0 as? NSDictionary else {
//                return false
//            }
//
//            return "\(dict["payment_slag"] ?? "")"
//                == "stripe-payment"
//        }
//
//        setupPaypalView(
//            showCreditCardButton: hasStripe
//        )
        
        setupPapalAllView()
    }
    
    @IBAction func mCreditCard(_ sender: Any) {
        mPageControl.isHidden = true
        mTabBarContainer.isHidden = true
        mSelectPaymentOptionContainer.isHidden = true
        guard mOrderType != "refund_order" else {
            return
        }
        mTransactionType = "CreditCard"
        mTaxInfoView.isHidden = true
        mKeyBoardView.isHidden = true
        mChequeDetailsView.isHidden = true
        mCreditCardView.isHidden = true
        mCreditNoteDetailsView.isHidden = true
        mEditCashView.isHidden = true
        self.mCreditCardPaymentView.isHidden = false
        self.mCreditCardBanksView.isHidden = false
        self.mStripeCardView.isHidden = true
        
        mCardView.backgroundColor = .clear
        mCashView.backgroundColor = UIColor(named: "themeShades")
        mBankView.backgroundColor = UIColor(named: "themeShades")
        mCreditNoteView.backgroundColor = UIColor(named: "themeShades")
        
        self.mCashLABEL.textColor = UIColor(named:"theme6A")
        self.mCreditCardLABEL.textColor = UIColor(named:"themeColor")
        self.mBankLABEL.textColor = UIColor(named:"theme6A")
        self.mCreditNoteLABEL.textColor = UIColor(named:"theme6A")
        self.mCashIcon.image = UIImage(named: "cashgrey_ic")
        self.mCreditNoteIcon.image = UIImage(named: "creditnotegrey_ic")
        self.mCreditCardIcon.image = UIImage(named: "cardGreen")
        self.mBankIcon.image = UIImage(named: "bankgrey_ic")
        self.mCreditCardIcon.showAnimation {}
        self.mCreditCardLABEL.showAnimation {}
//        mTabBarContainer.isHidden = true
//        mSelectPaymentOptionContainer.isHidden = true
//
//        guard mOrderType != "refund_order" else { return }
//
//        mTransactionType = "CreditCard"
//        mPageControl.isHidden = true
//
//        mTaxInfoView.isHidden = true
//        mKeyBoardView.isHidden = true
//        mChequeDetailsView.isHidden = true
//        mCreditCardView.isHidden = true
//        mCreditNoteDetailsView.isHidden = true
//        mEditCashView.isHidden = true
//
//        self.mCreditCardPaymentView.isHidden = false
//
//        let hasPaypal = mPaymentData.contains {
//            (($0 as? NSDictionary)?
//                .value(forKey: "payment_slag") as? String)
//                == "paypal-payment"
//        }
//
//        let hasStripe = mPaymentData.contains {
//            (($0 as? NSDictionary)?
//                .value(forKey: "payment_slag") as? String)
//                == "stripe-payment"
//        }
//
//        if hasPaypal {
//
//            mCreditCardBanksView.isHidden = true
//            mStripeCardView.isHidden = false
//
//            setupPaypalView(
//                showCreditCardButton: hasStripe
//            )
//
//        } else {
//
//            mCreditCardBanksView.isHidden = false
//            mStripeCardView.isHidden = true
//        }
//
//        mCardView.backgroundColor = .clear
//        mCashView.backgroundColor = UIColor(named: "themeShades")
//        mBankView.backgroundColor = UIColor(named: "themeShades")
//        mCreditNoteView.backgroundColor = UIColor(named: "themeShades")
//
//        mCashLABEL.textColor = UIColor(named:"theme6A")
//        mCreditCardLABEL.textColor = UIColor(named:"themeColor")
//        mBankLABEL.textColor = UIColor(named:"theme6A")
//        mCreditNoteLABEL.textColor = UIColor(named:"theme6A")
    }
    
    @IBAction func mCash(_ sender: Any) {
        mTabBarContainer.isHidden = true
        mSelectPaymentOptionContainer.isHidden = true
        mTransactionType = "Cash"
        refreshCashPage()
        mChequeDetailsView.isHidden = true
        mTaxInfoView.isHidden = true
        mKeyBoardView.isHidden = false
        mCreditCardView.isHidden = true
        mEditCashView.isHidden = false
        mCreditNoteDetailsView.isHidden = true
        self.mCreditCardPaymentView.isHidden = true
        mCashView.backgroundColor = .clear
        mCardView.backgroundColor = UIColor(named: "themeShades")
        mBankView.backgroundColor = UIColor(named: "themeShades")
        mCreditNoteView.backgroundColor = UIColor(named: "themeShades")
        self.mCashLABEL.textColor = UIColor(named:"themeColor")
        self.mCreditCardLABEL.textColor = UIColor(named:"theme6A")
        self.mBankLABEL.textColor = UIColor(named:"theme6A")
        self.mCreditNoteLABEL.textColor = UIColor(named:"theme6A")
        self.mCashIcon.image = UIImage(named: "cashGreen")
        self.mCreditNoteIcon.image = UIImage(named: "creditnotegrey_ic")
        self.mCreditCardIcon.image = UIImage(named: "card_grey_ic")
        self.mBankIcon.image = UIImage(named: "bankgrey_ic")
        self.mCashIcon.showAnimation {}
        self.mCashLABEL.showAnimation {}
    }
    
    @IBAction func mBank(_ sender: Any) {
        mChequeDetailsView.isHidden = true
        if let ibs = mIBSelect { ibs.isSelected = true }
        if let chs = mChequeSelect { chs.isSelected = false }
        mTabBarContainer.isHidden = false
        mSelectPaymentOptionContainer.isHidden = false
        mIBTabSelect?.backgroundColor = UIColor(named: "themeColor")
        mChequeTabSelect?.backgroundColor = UIColor(named: "themeExtraLightText")
        mTransactionType = "Bank"
        mPageControl.isHidden = true
        mChequeDetailsView.isHidden = true
        mCreditNoteDetailsView.isHidden = true
        mTaxInfoView.isHidden = true
        mKeyBoardView.isHidden = true
        mCreditCardView.isHidden = true
        mEditCashView.isHidden = true
        self.mCreditCardPaymentView.isHidden = true
        mBankView.backgroundColor = .clear
        mCardView.backgroundColor = UIColor(named: "themeShades")
        mCashView.backgroundColor = UIColor(named: "themeShades")
        mCreditNoteView.backgroundColor = UIColor(named: "themeShades")
        self.mCashLABEL.textColor = UIColor(named:"theme6A")
        self.mCreditCardLABEL.textColor = UIColor(named:"theme6A")
        self.mBankLABEL.textColor = UIColor(named:"themeColor")
        self.mCreditNoteLABEL.textColor = UIColor(named:"theme6A")
        self.mCashIcon.image = UIImage(named: "cashgrey_ic")
        self.mCreditNoteIcon.image = UIImage(named: "creditnotegrey_ic")
        self.mCreditCardIcon.image = UIImage(named: "card_grey_ic")
        self.mBankIcon.image = UIImage(named: "bankGreen")
        self.mBankIcon.showAnimation {}
        self.mBankLABEL.showAnimation {}
    }
    
    @IBAction func mCreditNot(_ sender: Any) {
        mTabBarContainer.isHidden = true
        mSelectPaymentOptionContainer.isHidden = true
        guard mOrderType != "refund_order" else { return }
        mTransactionType = "CreditNote"
        mPageControl.isHidden = true
        mCreditNoteDetailsView.isHidden = false
        mTaxInfoView.isHidden = true
        mChequeDetailsView.isHidden = true
        mKeyBoardView.isHidden = true
        mCreditCardView.isHidden = true
        mEditCashView.isHidden = true
        self.mCreditCardPaymentView.isHidden = true
        mCreditNoteView.backgroundColor = .clear
        mCardView.backgroundColor = UIColor(named: "themeShades")
        mCashView.backgroundColor = UIColor(named: "themeShades")
        mBankView.backgroundColor = UIColor(named: "themeShades")
        self.mCashLABEL.textColor = UIColor(named:"theme6A")
        self.mCreditCardLABEL.textColor = UIColor(named:"theme6A")
        self.mBankLABEL.textColor = UIColor(named:"theme6A")
        self.mCreditNoteLABEL.textColor = UIColor(named:"themeColor")
        self.mCashIcon.image = UIImage(named: "cashgrey_ic")
        self.mCreditNoteIcon.image = UIImage(named: "creditNoteGreen")
        self.mCreditCardIcon.image = UIImage(named: "card_grey_ic")
        self.mBankIcon.image = UIImage(named: "bankgrey_ic")
        self.mCreditNoteIcon.showAnimation {}
        self.mCreditNoteLABEL.showAnimation {}
    }
    
    @IBAction func mTax(_ sender: Any) {
        mTaxInfoView.isHidden = false
        mKeyBoardView.isHidden = true
        mCreditCardView.isHidden = true
        mEditCashView.isHidden = true
        mChequeDetailsView.isHidden = true
        mCreditNoteDetailsView.isHidden = true
        mCardView.layer.sublayers?.remove(at: 0)
        mCashView.layer.sublayers?.remove(at: 0)
        mBankView.layer.sublayers?.remove(at: 0)
        mCreditNoteView.layer.sublayers?.remove(at: 0)
    }
    
    @IBAction func mPressOne(_ sender: UIButton) { sender.showAnimation{}; mInsertAmount(num:"1") }
    @IBAction func mPressTwo(_ sender: UIButton) { sender.showAnimation{}; mInsertAmount(num:"2") }
    @IBAction func mPressThree(_ sender: UIButton) { sender.showAnimation{}; mInsertAmount(num:"3") }
    @IBAction func mPressFour(_ sender: UIButton) { sender.showAnimation{}; mInsertAmount(num:"4") }
    @IBAction func mPressFive(_ sender:UIButton) { sender.showAnimation{}; mInsertAmount(num:"5") }
    @IBAction func mPressSix(_ sender: UIButton) { sender.showAnimation{}; mInsertAmount(num:"6") }
    @IBAction func mPressSeven(_ sender: UIButton) { sender.showAnimation{}; mInsertAmount(num:"7") }
    @IBAction func mPressEight(_ sender: UIButton) { sender.showAnimation{}; mInsertAmount(num:"8") }
    @IBAction func mPressNine(_ sender: UIButton) { sender.showAnimation{}; mInsertAmount(num:"9") }
    @IBAction func mPressSingleZero(_ sender: UIButton) { sender.showAnimation{}; mInsertAmount(num:"0") }
    @IBAction func mPressDoubleZero(_ sender: UIButton) { sender.showAnimation{}; mInsertAmount(num:"00") }
    @IBAction func mPressDot(_ sender:UIButton) { sender.showAnimation{}; if mCashAmounts != "" { mInsertAmount(num:".") } }
    
    @IBAction func mSub(_ sender: Any) {
        mSUBLABEL.showAnimation{}
        guard mTransactionType == "Cash" else { return }
        guard mCashPages.indices.contains(mCurrentCashPage) else { return }

        if mCashPages[mCurrentCashPage].isSubmitted {
            CommonClass.showSnackBar(message: "Amount already added!")
            return
        }

        let enteredAmount = Double(mCashAmounts) ?? 0
        guard enteredAmount > 0 else {
            CommonClass.showSnackBar(message: "Please fill valid amount!")
            return
        }

        // Customer input is in the selected currency.
        // Only the converted STORE-currency amount is deducted from Balance Due.
        syncCurrentCashPageFromInput()
        let convertedAmount = mCashPages[mCurrentCashPage].amount
        guard convertedAmount > 0 else {
            CommonClass.showSnackBar(message: "Please fill valid amount!")
            return
        }

        let balance = checkoutAmount(mBALANCEDUE.text)

        print("========== CASH SUB DEBUG ==========")
        print("Store Currency =", mStoreCurrency)
        print("Selected Currency =", mCurrencyName.text ?? "")
        print("Input Amount =", enteredAmount)
        print("Exchange Rate =", mExchangeRateValue.text ?? "")
        print("Converted Amount (Store Currency) =", convertedAmount)
        print("Balance Due (Store Currency) =", balance)
        print("====================================")

        guard convertedAmount <= balance + 0.000001 else {
            CommonClass.showSnackBar(message: "Please fill valid amount!")
            return
        }

        mCashPages[mCurrentCashPage].isSubmitted = true
        mSubmittedCash.text = String(format: "%.2f", totalSubmittedCash()).formatPrice()
        recheckBalanceDue()

        let remainingBalance = checkoutAmount(mBALANCEDUE.text)
        if remainingBalance > 0 {
            let nextCurrency = mCurrencyName.text ?? mStoreCurrency
            let nextRate = nextCurrency == mStoreCurrency
                ? 1
                : (Double(mExchangeRateValue.text ?? "") ?? 0)

            mCashPages.append(
                CashPaymentPage(
                    amount: 0,
                    enteredAmount: 0,
                    currency: nextCurrency,
                    exchangeRate: nextRate,
                    isSubmitted: false
                )
            )
            mCurrentCashPage = mCashPages.count - 1

            UIView.animate(withDuration: 0.15, animations: {
                self.mPageControl.currentPage = self.mCurrentCashPage
                self.mPageControl.transform = CGAffineTransform(scaleX: 1.2, y: 1.2)
            }) { _ in
                UIView.animate(withDuration: 0.15) {
                    self.mPageControl.transform = .identity
                }
            }

            mCashAmount.text = ""
            mCashAmounts = ""
            mConvertedAmounts = "0"
            mConvertedAmount.text = ""
            mPageControl.isHidden = false
            refreshCashPage()
        }

        CommonClass.showSnackBar(message: "Amount Added Successfully!")
    }
    
    @IBAction func mShowTaxView(_ sender: Any) {}
    @IBAction func mCashAmountField(_ sender: Any) {}
    
    @IBAction func mChooseCurrency(_ sender: Any) {
        let dropdown = DropDown()
        dropdown.anchorView = self.mChooseCurrencyButt
        dropdown.direction = .bottom
        dropdown.bottomOffset = CGPoint(x: 0, y: 50)
        dropdown.width = 200
        dropdown.dataSource = self.mCurrencyNameData
        dropdown.cellNib = UINib(nibName: "Currency", bundle: nil)

        dropdown.customCellConfiguration = {
            (index: Index, item: String, cell: DropDownCell) -> Void in
            guard let cell = cell as? CurrencyCell else { return }
            guard index < self.mCurrencyImageData.count else { return }
            cell.mCurrencyImage.downlaodImageFromUrl(
                urlString: self.mCurrencyImageData[index]
            )
        }

        dropdown.selectionAction = { [unowned self] (index: Int, item: String) in
            guard self.mCashPages.indices.contains(self.mCurrentCashPage) else { return }

            if self.mCashPages[self.mCurrentCashPage].isSubmitted {
                CommonClass.showSnackBar(
                    message: "Please use the new payment page for another currency."
                )
                return
            }

            self.mCurrencyName.text = item
            self.mSelectedStoreCurrency = item

            if index < self.mCurrencyImageData.count {
                self.mCashCurrencyImage.downlaodImageFromUrl(
                    urlString: self.mCurrencyImageData[index]
                )
            }

            if item == self.mStoreCurrency {
                self.mExchangeRateLabel.isHidden = true
                self.mExchangeRateValue.isHidden = true
                self.mExchangeRateValue.text = ""
            } else {
                self.mExchangeRateLabel.isHidden = false
                self.mExchangeRateValue.isHidden = false

                guard index < self.mExchangeRateData.count else {
                    self.mExchangeRateValue.text = ""
                    self.syncCurrentCashPageFromInput()
                    return
                }

                // Use the backend rate directly.
                // Example: THB rate 0.03 -> 10,000 THB = 300 USD.
                self.mExchangeRateValue.text = self.mExchangeRateData[index]
            }

            self.syncCurrentCashPageFromInput()
        }

        dropdown.show()
    }
    
    @IBAction func mExchangeRate(_ sender: UITextField!) {
        guard mTransactionType == "Cash" else { return }
        // Backend rate is used directly: converted STORE amount = entered amount × rate.
        syncCurrentCashPageFromInput()
    }
    
    private func recheckBalanceDue() {
        let totalAmount = checkoutAmount(mTOTALAMOUNT.text)
        let submittedCash = totalSubmittedCash()
        let submittedCreditNote = checkoutAmount(mSubmittedCreditNote.text)
        let submittedBankAmount = checkoutAmount(mSubmittedBankAmount.text)
        let submittedCreditCard = checkoutAmount(mSubmittedCreditCard.text)

        let balance = max(
            0,
            totalAmount
                - submittedCash
                - submittedCreditNote
                - submittedBankAmount
                - submittedCreditCard
        )

        self.mBALANCEDUE.text = "\(balance)".formatPrice()

        print("========== Multiple Payment ==========")
        print("Total =", totalAmount)
        print("Cash (Store Currency) =", submittedCash)
        print("Bank =", submittedBankAmount)
        print("Credit Card =", submittedCreditCard)
        print("Credit Note =", submittedCreditNote)
        print("Balance =", balance)
        print("======================================")
    }
    
    @IBAction func mClear(_ sender: UIButton) {
        sender.showAnimation{}
        guard mCashPages.indices.contains(mCurrentCashPage) else { return }
        guard !mCashPages[mCurrentCashPage].isSubmitted else {
            CommonClass.showSnackBar(message: "Submitted amount cannot be cleared.")
            return
        }

        mCashAmount.text = ""
        mConvertedAmount.text = ""
        mConvertedAmounts = "0"
        mCashAmounts = ""
        mCashPages[mCurrentCashPage].enteredAmount = 0
        mCashPages[mCurrentCashPage].amount = 0

        mSubmittedCash.text = String(format: "%.2f", totalSubmittedCash()).formatPrice()
        recheckBalanceDue()
    }
    
    @IBAction func mDeleteCashAmount(_ sender: Any) {
        guard mCashPages.indices.contains(mCurrentCashPage) else { return }
        guard !mCashPages[mCurrentCashPage].isSubmitted else {
            CommonClass.showSnackBar(message: "Submitted amount cannot be edited.")
            return
        }
        guard !mCashAmounts.isEmpty else { return }

        mCashAmounts.removeLast()
        mCashAmount.text = mCashAmounts
        syncCurrentCashPageFromInput()

        if mCashAmounts.isEmpty {
            mConvertedAmounts = "0"
            mConvertedAmount.text = ""
        }

        mSubmittedCash.text = String(format: "%.2f", totalSubmittedCash()).formatPrice()
        recheckBalanceDue()
    }
    
//    func mInsertAmount(num : String){
//        mCashAmounts.insert(contentsOf: num, at: mCashAmounts.endIndex)
//        if mCashAmounts.filter({$0 == "."}).count > 1 {
//            mCashAmounts.removeLast()
//            return
//        }
//        mCashAmount.text! = mCashAmounts
//        if mTransactionType == "Cash" {
//            if mExchangeRateLabel.isHidden == false {
//                if mExchangeRateValue.text != "" {
//                    let mVal = Double(mExchangeRateValue.text ?? "") ?? 0.0
//                    if mCashAmount.text != "" && mCashAmount.text != "."  {
//                        let cashAmount = Double(mCashAmounts) ?? 0
//                        mConvertedAmounts = "\(cashAmount * mVal)"
//                        let mDecimalAmount = ((Double(mConvertedAmounts) ?? 0) * 100).rounded() / 100
//                        print("DEBUG_STORE_CURRENCY =", mStoreCurrency)
//
//                        print("DEBUG_SELECTED_CURRENCY =",
//                              mCurrencyName.text ?? "")
//
//                        print("DEBUG_RATE =",
//                              mExchangeRateValue.text ?? "")
//
//                        print("DEBUG_CASH_AMOUNT =",
//                              mCashAmounts)
//
//                        print("DEBUG_CONVERTED =",
//                              mConvertedAmounts)
//                        mConvertedAmount.text = "=  \(self.mCurrencyName.text ?? "") \(mDecimalAmount)"
//                    }
//                }
//            }else{
//                if mCashAmount.text != "" && mCashAmount.text != "."  {
//                    mConvertedAmounts = "\(Double(mCashAmounts) ?? 0)"
//                    let mDecimalAmount = ((Double(mConvertedAmounts) ?? 0) * 100).rounded() / 100
//                    print("DEBUG_STORE_CURRENCY =", mStoreCurrency)
//
//                    print("DEBUG_SELECTED_CURRENCY =",
//                          mCurrencyName.text ?? "")
//
//                    print("DEBUG_RATE =",
//                          mExchangeRateValue.text ?? "")
//
//                    print("DEBUG_CASH_AMOUNT =",
//                          mCashAmounts)
//
//                    print("DEBUG_CONVERTED =",
//                          mConvertedAmounts)
//                    mConvertedAmount.text = "= \(self.mCurrencyName.text ?? "") \(mDecimalAmount)"
//                }
//            }
//        }
//    }
    
    func mInsertAmount(num: String) {
        guard mCashPages.indices.contains(mCurrentCashPage) else { return }
        guard !mCashPages[mCurrentCashPage].isSubmitted else { return }

        mCashAmounts.insert(contentsOf: num, at: mCashAmounts.endIndex)
        if mCashAmounts.filter({ $0 == "." }).count > 1 {
            mCashAmounts.removeLast()
            return
        }

        mCashAmount.text = mCashAmounts

        if mTransactionType == "Cash" {
            syncCurrentCashPageFromInput()
        }
    }

    @IBAction func mStartSearch(_ sender: Any) {}
    @IBAction func mEndSearch(_ sender: Any) {}
    @IBAction func mEditChanged(_ sender: Any) {
        let value  = mCustomerSearch.text?.count ?? 0
        if value == 0 && mCustomerSearch.text == "" {
            mCustomerSearchTableView.removeFromSuperview()
            self.view.endEditing(true)
        }
    }
    @IBAction func mValueChanged(_ sender: UITextField!) {}
    @IBAction func mEditCustSearch(_ sender: Any) {}
    
    @IBAction func mLabourAmount(_ sender: UITextField) {
        if sender.text == "" { sender.text = "0" }
        calculateTax()
    }
    @IBAction func mShippingAmount(_ sender: UITextField) {
        if sender.text == "" { sender.text = "0" }
        calculateTax()
    }
    @IBAction func mDiscountPercent(_ sender: UITextField) {
        var mCount = Int()
        if sender.text == "" { mCount = 0 } else { mCount = Int(Double(sender.text ?? "") ?? 0) }
        if sender.text! == "" || sender.text == "0"  || mCount > 100 {
            sender.text = "0"
            self.mDiscountAmounts.text = "0"
            calculateTax()
        }else {
            self.mDiscountAmounts.text = "\(calculatePercentage(value: (Double(mTotalAm) ?? 0), percent: Double(sender.text ?? "") ?? 0 ))"
            calculateTax()
        }
    }
    
    @IBAction func mDiscountAmount(_ sender: UITextField) {
        if sender.text == "" {
            sender.text = "0"
            self.mDiscountPercents.text = "0"
            calculateTax()
        }else{
            let mPercent = (Double(sender.text ?? "") ?? 0) / (Double(mTotalAm) ?? 0 * 100)
            self.mDiscountPercents.text = String(format: "%.2f", mPercent)
            calculateTax()
        }
    }
    
    func calculatePercentage(value:Double,percent: Double) -> Double {
        return (value * percent)/100.00
    }
    func calculateInclusiveTax(value:Double,percent: Double) -> Double {
        return (value * percent)/(100.00 + (Double(mTaxP) ?? 0))
    }
    func calculateExclusiveTax(value:Double,percent: Double) -> Double {
        return (value * percent)/100.00
    }
    
    func calculateTax(){
        var mAmount = Double()
        let mDiscountA = Double(self.mDiscountAmounts.text ?? "") ?? 0
        let mLabour = Double(self.mLabourCharge.text ?? "") ?? 0
        let mShipping = Double(self.mShippingCharge.text ?? "") ?? 0
        mAmount = mLabour + mShipping
        
        if mTaxType.lowercased() == "inclusive" {
            mTotalDiscountTx.text = mDiscountAmounts.text
            mTotalTx.text = "\((mAmount + (Double(mTotalAm) ?? 0) ))"
            let totalTx = Double(mTotalTx.text ?? "0.0") ?? 0.0
            let discountAmounts = Double(mDiscountAmounts.text ?? "0.0") ?? 0.0
            let taxPercent = Double(mTaxP) ?? 0.0
            let taxAmount = calculateInclusiveTax(value: totalTx - discountAmounts, percent: taxPercent)
            mTaxAmountTx.text = String(format: "%.02f", locale: Locale.current, taxAmount)
            let taxAmountTx = Double(mTaxAmountTx.text?.replacingOccurrences(of: ",", with: "") ?? "0.0") ?? 0.0
            let subTotal = totalTx - discountAmounts - taxAmountTx
            mSubTotalTx.text = String(format: "%.02f", locale: Locale.current, subTotal)
            mFinalTaxAmount.text = mTaxAmountTx.text
            mTOTALAMOUNT.text = "\((mAmount + (Double(mTotalAm) ?? 0) - mDiscountA))"
            recheckBalanceDue()
        }else{
            mTotalDiscountTx.text = mDiscountAmounts.text
            mTotalTx.text = "\((mAmount + (Double(mTotalAm) ?? 0 )) )"
            let totalTx = Double(mTotalTx.text ?? "0.0") ?? 0.0
            let discountAmounts = Double(mDiscountAmounts.text ?? "0.0") ?? 0.0
            let taxPercent = Double(mTaxP) ?? 0.0
            mTaxAmountTx.text = String(format: "%.02f", locale: Locale.current, calculateExclusiveTax(value: totalTx - discountAmounts, percent: taxPercent))
            mSubTotalTx.text = String(format:"%.02f",locale:Locale.current,totalTx - discountAmounts)
            mFinalTaxAmount.text = mTaxAmountTx.text
            let subTotal = Double(mSubTotalTx.text?.replacingOccurrences(of: ",", with: "") ?? "0.0") ?? 0.0
            let taxAmount = Double(mTaxAmountTx.text?.replacingOccurrences(of: ",", with: "") ?? "0.0") ?? 0.0
            mTOTALAMOUNT.text = "\(subTotal + taxAmount)"
            recheckBalanceDue()
        }
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) { _ = textField.text }
    
    func mFetchCreditNoteData(value: String){
        _ = UserDefaults.standard.string(forKey: "location")
        let urlPath = mPOSCreditNote
        let params = ["customer_id":mCustomerId]
        if Reachability.isConnectedToNetwork() == true {
            AF.request(urlPath, method:.post, parameters:params, encoding: JSONEncoding.default, headers: sGisHeaders).responseJSON { response in
                if(response.error != nil){
                    CommonClass.showSnackBar(message: "OOP's something went wrong!")
                }else{
                    guard let jsonData = response.data, let json = try? JSONSerialization.jsonObject(with: jsonData, options: []) as? NSDictionary else {
                        CommonClass.showSnackBar(message: "OOP's something went wrong!")
                        return
                    }
                    if json.value(forKey: "code") as? Int == 200 {
                        self.mCreditNoteData = NSMutableArray()
                        self.mSelectedCustomIndex = [IndexPath]()
                        self.mSelectedIndex = [IndexPath]()
                        self.mAmountData = NSMutableArray()
                        self.mItemsSelected.text = "0 " + "Item Selected".localizedString
                        self.mTotalCreditAmount.text = ""
                        if let mData = json.value(forKey: "data") as? NSArray {
                            self.mCreditNoteData = NSMutableArray(array: mData)
                            self.mCreditNoteTable.delegate = self
                            self.mCreditNoteTable.dataSource = self
                            self.mCreditNoteTable.reloadData()
                            var mAmount = [Double]()
                            for item in mData {
                                if let value = item as? NSDictionary {
                                    let mCData = NSMutableDictionary()
                                    mAmount.append(Double("\(value.value(forKey: "amount") ?? "0")") ?? 0.0)
                                    mCData.setValue("\(value.value(forKey: "amount") ?? "0")", forKey: "amount")
                                    self.mTotalCreditAmount.text = String(format:"%.02f",locale:Locale.current,mAmount.reduce(0, {$0 + $1}))
                                    self.mAmountData.add(mCData)
                                }
                            }
                        }
                    } else{
                        if let error = json.value(forKey: "error") as? String {
                            if error == "Authorization has been expired" {
                                CommonClass.sessionExpired(isExpired: true, navigation: self.navigationController)
                            } else {
                                CommonClass.showSnackBar(message: error)
                            }
                        }
                        if let message = json.value(forKey: "message") as? String {
                            CommonClass.showSnackBar(message: message)
                        }
                    }
                }
            }
        }else{
            CommonClass.showSnackBar(message: "No Internet Connection")
        }
    }
    
    func mFinalPay(urlPath : String , params: [String:Any]){
        if Reachability.isConnectedToNetwork() == true {
            AF.request(urlPath, method:.post, parameters:params, encoding :JSONEncoding.default, headers: sGisHeaders).responseJSON { response in
                if(response.error != nil){
                    CommonClass.showSnackBar(message: "OOP's something went wrong!")
                }else{
                    guard let jsonData = response.data, let jsonResult = try? JSONSerialization.jsonObject(with: jsonData, options: []) as? NSDictionary else {
                        CommonClass.showSnackBar(message: "OOP's something went wrong!")
                        return
                    }
                    if jsonResult.value(forKey: "code") as? Int == 200 {
                        UserDefaults.standard.setValue("\(jsonResult.value(forKey: "pdf_url") ?? "")", forKey: "reportAPI")
                        self.mGenerateReport(id:"\(jsonResult.value(forKey: "pdf_url") ?? "")" , jsonResult : jsonResult)
                    }else{
                        if let error = jsonResult.value(forKey: "error"){
                            if "\(error)" == "Authorization has been expired" {
                                CommonClass.sessionExpired(isExpired: true, navigation: self.navigationController)
                            }
                        }
                    }
                }
            }
        }else{
            CommonClass.showSnackBar(message: "No Internet Connection")
        }
    }
    
    func mGenerateReport(id : String, jsonResult : NSDictionary){
        CommonClass.showFullLoader(view: self.view)
        let urlPath = id
        if Reachability.isConnectedToNetwork() == true {
            AF.request(urlPath, method:.post, parameters:nil, headers: sGisHeaders2).responseJSON { response in
                CommonClass.stopLoader()
                if(response.error != nil){
                    CommonClass.showSnackBar(message: "OOP's something went wrong!")
                }else{
                    guard let jsonData = response.data, let jsonVal = try? JSONSerialization.jsonObject(with: jsonData, options: []) as? NSDictionary else {
                        CommonClass.showSnackBar(message: "OOP's something went wrong!")
                        return
                    }
                    
                    print("====================================")
                    print("🔥 GENERATE REPORT ORDER TYPE =", self.mOrderType)
                    print("🔥 ORIGINAL RESULT =", jsonResult)
                    print("🔥 REPORT RESPONSE =", jsonVal)
                    print("====================================")
                    
                    UserDefaults.standard.set("", forKey: "CUSTOMERID")
                    UserDefaults.standard.set("", forKey: "SALESPERSONID")
                    CommonClass.showSnackBar(message: "Payment Successful")
                    if let email = jsonVal.value(forKey: "email") {
                        UserDefaults.standard.setValue("\(email)", forKey: "mailInvoice")
                    }
                    UserDefaults.standard.setValue("\(jsonVal.value(forKey: "pdf_url") ?? "")", forKey: "report")
                    let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                    if let mCompletePayment = storyBoard.instantiateViewController(withIdentifier: "CompletePayment") as? CompletePayment {
                        if self.mOrderType == "Sales Order" { mCompletePayment.mType = "pos_order"}//"pos" }
                        if self.mOrderType == "Custom Order" { mCompletePayment.mType = "custom_order"//"custom"
                        }
                        if self.mOrderType == "Repair Order" { mCompletePayment.mType = "repair_order"//"repair"
                        }
                        mCompletePayment.mDue = "\(jsonResult.value(forKey: "DueAmt") ?? "")"
                        mCompletePayment.mTotal = "\(jsonResult.value(forKey: "totalAmt") ?? "")"
                        mCompletePayment.mShippingInfo = [
                            "billing_address": self.mSelectedBillingAddress,
                            "shipping_address": self.mSelectedShippingAddress
                        ]
                        self.navigationController?.pushViewController(mCompletePayment, animated:true)
                    }
                }
            }
        }
    }
    
    func mSetupTableView(frame: CGRect) {
        if mCustomerSearch.text != "" {
            let nib = UINib(nibName: "CustomerSearchList", bundle: nil)
            _ = nib.instantiate(withOwner: self, options: nil)[0] as? UIView
            mCustomerSearchTableView.frame = CGRect(x: 16, y:frame.origin.y + 200 ,width:self.view.frame.width - 32, height:400)
            mCustomerSearchTableView.cornerRadius = 10
            mCustomerSearchTableView.register(nib, forCellReuseIdentifier: "CustomerSearchItem")
            mCustomerSearchTableView.isHidden = false
            mCustomerSearchTableView.keyboardDismissMode = .onDrag
            self.mCustomerSearchTableView.delegate = self
            self.mCustomerSearchTableView.dataSource = self
            mCustomerSearchTableView.reloadData()
            self.view.addSubview(mCustomerSearchTableView)
            mCustomerSearchTableView.tag = 100
            mCustomerSearchTableView.translatesAutoresizingMaskIntoConstraints = false
        }else{
            mCustomerSearchTableView.removeFromSuperview()
        }
    }
    
    func mGetCurrency(){
        let urlPath = mGetCurrencies
        if Reachability.isConnectedToNetwork() == true {
            AF.request(urlPath, method:.post, parameters:nil, headers: sGisHeaders2).responseJSON { response in
                if(response.error != nil){
                    CommonClass.showSnackBar(message: "OOP's something went wrong!")
                }else{
                    guard let jsonData = response.data, let jsonResult = try? JSONSerialization.jsonObject(with: jsonData, options: []) as? NSDictionary else { return }
                    if let data = jsonResult.value(forKey: "data") as? NSArray, data.count > 0 {
                        for i in data {
                            if let currency = i as? NSDictionary {
                                self.mCurrencyNameData.append("\(currency.value(forKey:"currency") ?? "")")
                                self.mCurrencyImageData.append("\(currency.value(forKey:"url") ?? "")")
                                self.mExchangeRateData.append("\(currency.value(forKey:"rate") ?? "")")
                                if "\(currency.value(forKey:"currency") ?? "")" == self.mStoreCurrency {
                                    self.mCashCurrencyImage.downlaodImageFromUrl(urlString: "\(currency.value(forKey:"url") ?? "")")
                                    self.mCurrencyName.text = self.mStoreCurrency
                                    self.mSelectedStoreCurrency = self.mStoreCurrency
                                    if self.mOrderType == "Sales Order" {
                                        self.mTOTALAMOUNT.text = self.mFTOTAL.formatPrice()
                                        self.mBALANCEDUE.text = self.mFTOTAL.formatPrice()
                                    }else{
                                        self.mTOTALAMOUNT.text = self.mTotalP.formatPrice()
                                        self.mBALANCEDUE.text = self.mTotalP.formatPrice()
                                    }
                                }
                            }
                        }
                        self.mTOTALAMOUNT.text = self.mTotalP.formatPrice()
                        self.mBALANCEDUE.text = self.mTotalP.formatPrice()
                    }
                }
            }
        }else{
            CommonClass.showSnackBar(message: "No Internet Connection")
        }
    }
    
    // MARK: Customer Address List
    private func getCustomerAddressList(){
        guard Reachability.isConnectedToNetwork() == true else { return }
        let params = ["customer_id": mCustomerId] as [String : Any]
        let urlPath = mGetCustomerAddressList
        AF.request(urlPath, method:.post,parameters: params,encoding: JSONEncoding.default, headers: sGisHeaders).responseJSON { response in
            guard let jsonData = response.data else { return }
            do {
                guard let json = try JSONSerialization.jsonObject(with: jsonData, options: []) as? [String: Any],
                      let code = json["code"] as? Int else { return }
                switch code {
                case 200:
                    if let data = json["data"] as? [String: Any] {
                        if let billingAddressList = data["billing_address"] as? [[String : Any]] {
                            for address in billingAddressList {
                                if let bUDID = UserDefaults.standard.string(forKey: "CustomerBillingAddressUDID"){
                                    if let udid = address["UDID"] as? String, udid == bUDID {
                                        self.mSelectedBillingAddress = address
                                    }
                                } else {
                                    if address["is_default"] as? Int == 1 {
                                        self.mSelectedBillingAddress = address
                                    }
                                }
                            }
                        }
                        if let shippingAddressList = data["shipping_address"] as? [[String : Any]] {
                            for address in shippingAddressList {
                                if let sUDID = UserDefaults.standard.string(forKey: "CustomerShippingAddressUDID") {
                                    if let udid = address["UDID"] as? String, udid == sUDID {
                                        self.mSelectedShippingAddress = address
                                    }
                                } else {
                                    if address["is_default"] as? Int == 1 {
                                        self.mSelectedShippingAddress = address
                                    }
                                }
                            }
                        }
                    }
                default: break
                }
            } catch { }
        }
    }
    
    // MARK: Generate QR Code
    func mGenerateQRCode() {
        let urlPath = mGetQRCode
        let mParams: [String: Any] = [
            "payment_id": mChequePaymentId,
            "amount": mEnterQRAmount?.text ?? "0",
            "customerId": mCustomerId
        ]
        if Reachability.isConnectedToNetwork() {
            AF.request(urlPath, method: .post, parameters: mParams, headers: sGisHeaders2).responseJSON { response in
                switch response.result {
                case .success(let value):
                    guard let json = value as? [String: Any] else { return }
                    if let code = json["code"] as? Int, code == 200, let data = json["data"] as? [String: Any] {
                        self.mClientReferenceID = data["client_reference_id"] as? String ?? ""
                        if let qrCodeString = data["qrCode"] as? String,
                           let base64String = qrCodeString.components(separatedBy: ",").last,
                           let qrCodeData = Data(base64Encoded: base64String),
                           let qrCodeImage = UIImage(data: qrCodeData) {
                            DispatchQueue.main.async {
                                self.qrCodeView.removeFromSuperview()
                                self.qrCodeView.delegate = self
                                self.qrCodeView.mQRImage.image = qrCodeImage
                                self.view.addSubview(self.qrCodeView)
                                self.qrCodeView.startTimer()
                                self.mGetPayementStatus()
                            }
                        }
                    } else {
                        let message = json["message"] as? String ?? "Oops, something went wrong!"
                        CommonClass.showSnackBar(message: message)
                    }
                case .failure(let error):
                    CommonClass.showSnackBar(message: error.localizedDescription)
                }
            }
        }
    }
    
    func authenticationPresentingViewController() -> UIViewController { return self }
    
    func StripePayment() {
        StripeManager.shared.configureStripe(publishableKey: mStripPublishKey)
        StripeManager.shared.fetchPaymentIntentDetails(clientSecret: self.mClientSecreat)
        var configuration = PaymentSheet.Configuration()
        let paymentSheet = PaymentSheet(paymentIntentClientSecret: mClientSecreat, configuration: configuration)
        paymentSheet.present(from: self) { paymentResult in
            DispatchQueue.main.async {
                switch paymentResult {
                case .completed:
                    if let paymentSuccessView = PaymentSuccessView.loadFromNib() {
                        paymentSuccessView.frame = self.view.bounds
                        paymentSuccessView.setAmount("Amount: \(self.mCreditFillAmount.text ?? "")")
                        if let successImage = UIImage(named: "successAmount") { paymentSuccessView.setImage(successImage) }
                        self.view.addSubview(paymentSuccessView)
                    }
                    self.mStripeCardView.isHidden = true
                    self.mCreditCardBanksView.isHidden = false
                    CommonClass.showSnackBar(message: "Amount added successfully")
                    
                    let mCreditCardData = NSMutableDictionary()
                    mCreditCardData.setValue(self.mCreditCardName, forKey: "name")
                    mCreditCardData.setValue(self.mCardNumber.text ?? "", forKey: "card_number")
                    mCreditCardData.setValue(self.mCardName.text ?? "", forKey: "card_name")
                    mCreditCardData.setValue(self.mCreditCardPaymentId, forKey: "payment_method_id")
                    mCreditCardData.setValue(self.mCreditCardLogo, forKey: "logo")
                    mCreditCardData.setValue(self.mCreditFillAmount.text ?? "", forKey: "amount")
                    mCreditCardData.setValue("Credit_Card", forKey: "Paymentmethod_type")
                    mCreditCardData.setValue(self.mClientReferenceID, forKey: "client_reference_id")
                    self.mCreditCardMethod.add(mCreditCardData)
                    
                    var mAmounts = [Double]()
                    for i in self.mCreditCardMethod {
                        if let mData = i as? NSDictionary {
                            mAmounts.append(Double("\(mData.value(forKey: "amount") ?? "0.0")".replacingOccurrences(of: ",", with: "")) ?? 0.00)
                        }
                    }
                    self.mSubmittedCreditCard.text = "\(mAmounts.reduce(0, {$0 + $1}))"
                    self.recheckBalanceDue()
                    
                    self.mCreditCardLogo = ""
                    self.mCreditCardName = ""
                    self.mCreditCardPaymentId = ""
                    self.mCardNumber.text = ""
                    self.mCardName.text = ""
                    self.mCreditFillAmount.text = ""
                    
                case .failed(_):
                    if let paymentSuccessView = PaymentSuccessView.loadFromNib() {
                        paymentSuccessView.frame = self.view.bounds
                        paymentSuccessView.mSetAmountStatus("Payment Failed")
                        if let successImage = UIImage(named: "AmountFailed") { paymentSuccessView.setImage(successImage) }
                        self.view.addSubview(paymentSuccessView)
                    }
                    StripeManager.shared.fetchPaymentIntentDetails(clientSecret: self.mClientSecreat)
                case .canceled:
                    if let paymentSuccessView = PaymentSuccessView.loadFromNib() {
                        paymentSuccessView.frame = self.view.bounds
                        paymentSuccessView.mSetAmountStatus("Payment Failed")
                        if let successImage = UIImage(named: "AmountFailed") { paymentSuccessView.setImage(successImage) }
                        self.view.addSubview(paymentSuccessView)
                    }
                }
            }
        }
    }
    
//    func didTapCancelQRCode() { mCancelQRCode() }
    
    func mCancelQRCode() {
        let urlPath = mCancelQR
        let mParams: [String: Any] = ["client_reference_id": mClientReferenceID]
        guard Reachability.isConnectedToNetwork() else { return }
        AF.request(urlPath, method: .post, parameters: mParams, headers: sGisHeaders2).responseJSON { response in
            switch response.result {
            case .success:
                guard let jsonData = response.data, let json = try? JSONSerialization.jsonObject(with: jsonData, options: []) as? [String: Any] else { return }
                if let code = json["code"] as? Int, code == 200 {
                    self.isQRCodeDeleted = true
                }
            case .failure(let error):
                print("Error: \(error.localizedDescription)")
            }
        }
    }
    
    func mGetStripeDataBackEnd() {
        print("DEBUG_GET_STRIPE_CALLED")
        print("DEBUG_PAYMENT_SLAG =", mSelectdPaymentMethod)
        guard let creditFillAmountText = self.mCreditFillAmount.text, !creditFillAmountText.isEmpty, let creditFillAmount = Double(creditFillAmountText), creditFillAmount != 0 else {
            CommonClass.showSnackBar(message: "Please fill valid amount")
            return
        }
        let urlPath = mGetStipData
        let mParams: [String: Any] = [
            "amount":self.mCreditFillAmount.text ?? 0,
            "slug": self.mSelectdPaymentMethod,
            "PaymentMethod": mPaymentMethod,
            "customer_id": mCustomerId
        ]
        guard Reachability.isConnectedToNetwork() else { return }
        print("DEBUG_URL =", urlPath)
        print("DEBUG_HEADERS =", sGisHeaders2)
        print("DEBUG_PUBLISH_KEY =", mStripPublishKey)
        print("DEBUG_PARAMS =", mParams)
        AF.request(urlPath, method: .post, parameters: mParams, headers: sGisHeaders2).responseJSON { response in
            switch response.result {
            case .success:
                print("DEBUG_STRIPE_response.data =", response.data)
                guard let jsonData = response.data, let json = try? JSONSerialization.jsonObject(with: jsonData, options: []) as? [String: Any] else { return }
                print("DEBUG_STRIPE_RESPONSE =", json)
                if let code = json["code"] as? Int, code != 200 {

                    let message = json["message"] as? String ?? "Payment failed"

                    CommonClass.showSnackBar(message: message)

                    print("DEBUG_PAYMENT_ERROR =", json)

                    return
                }
                else if let code = json["code"] as? Int, code == 200 {
                    
                    if let data = json["data"] as? [String: Any],
                       let clientSecret = data["clientSecret"] as? String,
                       let clientRefID = data["client_reference_id"] as? String,
                       let paymentIntentId = data["payment_intent_id"] as? String {
                        self.mClientSecreat = clientSecret
                        self.mPaymentIntentID = paymentIntentId
                        self.mClientReferenceID = clientRefID
                        if let balanceDue = self.mBALANCEDUE.text {
                            let formattedBalanceDue = balanceDue.replacingOccurrences(of: ",", with: "")
                            let balanceDueInDouble = Double(formattedBalanceDue) ?? 0.0
                            let inputAmount = Double(self.mCreditFillAmount.text ?? "") ?? 0.0
                            if inputAmount <= balanceDueInDouble {
                                self.StripePayment()
                            } else {
                                CommonClass.showSnackBar(message: "Please fill a valid amount!")
                            }
                        }
                    }
                }
            case .failure(_):
                CommonClass.showSnackBar(message: "OOP's something went wrong!")
            }
        }
    }
    
    func mGetPayementStatus() {
        guard !isQRCodeDeleted else { return }
        let urlPath = mGetPaymentStatus
        let mParams: [String: Any] = ["transactionId": self.mClientReferenceID]
        guard Reachability.isConnectedToNetwork() else { return }
        
        AF.request(urlPath, method: .post, parameters: mParams, headers: sGisHeaders2).responseJSON { response in
            switch response.result {
            case .success:
                guard let jsonData = response.data, let json = try? JSONSerialization.jsonObject(with: jsonData, options: []) as? [String: Any] else { return }
                if let code = json["code"] as? Int, code == 200, let data = json["data"] as? [String: Any] {
                    let paymentStatus = data["payment_status"] as? String ?? "pending"
                    let paymentSuccess = data["payment_success"] as? Int ?? 0
                    let normalizedStatus = paymentStatus.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
                    
                    if normalizedStatus == "pending" || paymentSuccess == 0 {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { self.mGetPayementStatus() }
                    } else if normalizedStatus == "completed" || normalizedStatus == "succeeded" || paymentSuccess == 1 {
                        if let paymentSuccessView = PaymentSuccessView.loadFromNib() {
                            paymentSuccessView.frame = self.view.bounds
                            paymentSuccessView.setAmount("Amount: \(self.mEnterQRAmount?.text ?? "")")
                            if let successImage = UIImage(named: "successAmount") { paymentSuccessView.setImage(successImage) }
                            self.view.addSubview(paymentSuccessView)
                        }
                        self.qrCodeView.isHidden = true
                        
                        self.mChequeData = NSMutableDictionary()
                        self.mChequeData.setValue(self.mCheqDate.text ?? "", forKey: "transaction_date")
                        self.mChequeData.setValue(self.mCheqAccountNumber.text ?? "", forKey: "ac_no")
                        self.mChequeData.setValue(self.mCheqAccountName.text ?? "", forKey: "ac_name")
                        self.mChequeData.setValue(self.mChequePaymentId, forKey: "payment_method_id")
                        self.mChequeData.setValue(self.mCheqRefNumber.text ?? "", forKey: "ref_no")
                        self.mChequeData.setValue(self.mCheqInstNumber.text ?? "", forKey: "inst_no")
                        self.mChequeData.setValue(self.mEnterQRAmount?.text ?? "", forKey: "amount")
                        self.mChequeData.setValue(self.mClientReferenceID, forKey: "client_reference_id")
                        self.mChequeData.setValue("Bank", forKey: "Paymentmethod_type")
                        self.mBankPayment.add(self.mChequeData)
                        
                        var mAmounts = [Double]()
                        for i in self.mBankPayment {
                            let mData = i as? NSDictionary
                            mAmounts.append(Double("\(mData?.value(forKey: "amount") ?? "0.0")".replacingOccurrences(of: ",", with: "")) ?? 0.00)
                        }
                        self.mSubmittedBankAmount.text = "\(mAmounts.reduce(0, {$0 + $1}))"
                        self.recheckBalanceDue()
                        
                        self.mCheqDate.text = ""
                        self.mCheqAccountNumber.text = ""
                        self.mCheqAccountName.text = ""
                        self.mChequePaymentId = ""
                        self.mCheqBankName.text = "Choose Bank"
                        self.mCheqRefNumber.text = ""
                        self.mEnterQRAmount?.text = ""
                        self.mCheqInstNumber.text = ""
                    } else {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.75) { self.mGetPayementStatus() }
                    }
                }
            case .failure(_): break
            }
        }
    }
}
