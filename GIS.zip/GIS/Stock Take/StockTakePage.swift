//
//  StockTakePage.swift
//  GIS
//
//  Created by Apple Hawkscode on 11/12/20.
//

import UIKit
import CoreBluetooth
import AVFoundation
import Alamofire
import Foundation
import SwiftyGif


class DeviceItems: UITableViewCell {
    @IBOutlet weak var mDeviceName: UILabel!
    @IBOutlet weak var mDeviceStatus: UILabel!
    @IBOutlet weak var mDeviceId: UILabel!

    private var activityIndicator: UIActivityIndicatorView?
    private var checkImageView: UIImageView?

    override func awakeFromNib() {
        super.awakeFromNib()

        backgroundColor = .clear
        selectionStyle = .none

        mDeviceName.font = UIFont.systemFont(ofSize: 16, weight: .regular)
        mDeviceName.textColor = UIColor.label

        mDeviceId.font = UIFont.systemFont(ofSize: 12, weight: .regular)
        mDeviceId.textColor = UIColor.secondaryLabel

        // The reference UI only shows name + serial and a state icon.
        mDeviceStatus.isHidden = true
    }

    override func prepareForReuse() {
        super.prepareForReuse()
        activityIndicator?.stopAnimating()
        activityIndicator = nil
        checkImageView = nil
        accessoryView = nil
    }

    func configure(name: String, id: String, connected: Bool, loading: Bool) {
        mDeviceName.text = name
        mDeviceId.text = id
        mDeviceStatus.isHidden = true

        activityIndicator?.stopAnimating()
        activityIndicator = nil
        checkImageView = nil

        if loading {
            let spinner = UIActivityIndicatorView(style: .medium)
            spinner.color = UIColor.systemGray3
            spinner.startAnimating()
            accessoryView = spinner
            activityIndicator = spinner
        } else if connected {
            let imageView = UIImageView(
                image: UIImage(systemName: "checkmark.circle.fill")
            )
            imageView.tintColor = UIColor(red: 0.36, green: 0.78, blue: 0.76, alpha: 1.0)
            imageView.frame = CGRect(x: 0, y: 0, width: 24, height: 24)
            imageView.contentMode = .scaleAspectFit
            accessoryView = imageView
            checkImageView = imageView
        } else {
            accessoryView = nil
        }
    }

    func setData(_ data: CBPeripheral, _ isConnected: Bool = false) {
        configure(
            name: data.name ?? "Unknown Device",
            id: data.identifier.uuidString,
            connected: isConnected,
            loading: false
        )
    }
}

class StockTakePage: UIViewController, UITableViewDelegate , UITableViewDataSource, AVCaptureMetadataOutputObjectsDelegate, UICollectionViewDelegate , UICollectionViewDataSource, UICollectionViewDelegateFlowLayout ,UIViewControllerTransitioningDelegate, CBCentralManagerDelegate, CBPeripheralDelegate, GetInventoryFiltersDelegate {
    
    @IBOutlet weak var mSearchDeviceView: UIView!
    @IBOutlet weak var mBottomView: UIView!
    
    @IBOutlet weak var mScanNowLabel: UILabel!
    
    let shape = CAShapeLayer()
    let layer = CAGradientLayer()
    var captureSession: AVCaptureSession!
    var previewLayer: AVCaptureVideoPreviewLayer!
    var prevPeripheral : CBPeripheral?
    var SiriID = ""
    
    var bluetoothService : BluetoothLeService?
    
    @IBOutlet weak var mScannerCamView: UIView!
    @IBOutlet weak var mScannerImage: UIImageView!
    
    @IBOutlet weak var mDeviceView: UIView!
    let storyBoard: UIStoryboard = UIStoryboard(name: "stockBoard", bundle: nil)
    
    var m_lock: NSLock?
    @IBOutlet weak var mConnectIcon: UIImageView!
    @IBOutlet weak var mConnectLabel: UILabel!
    
    @IBOutlet weak var mRefreshIcon: UIImageView!
    @IBOutlet weak var mRefreshLabel: UILabel!
    
    @IBOutlet weak var mPowerIcon: UIImageView!
    @IBOutlet weak var mPowerLabel: UILabel!
    
    @IBOutlet weak var mMoreIcon: UIImageView!
    @IBOutlet weak var mMoreLabel: UILabel!
    
    @IBOutlet weak var mConnectDeviceLABEL: UILabel!
    @IBOutlet weak var mStartIcon: UIImageView!
    
    var cr_characteristic: CBCharacteristic?
    
    @IBOutlet weak var mDeviceTableView: UITableView!
    var mTimer = Timer()
    var mPeripherals = [CBPeripheral]()
    var mPeripheral : CBPeripheral?
    var mPerph = CBCentralManager()
    var mDeviceData = NSMutableArray()
    var mDataTags = [String]()
    var mSelected = -1
    var heartRatePeripheral: CBPeripheral!
    
    var mDATA = [""]
    @IBOutlet weak var mSearchStock: UITextField!
    @IBOutlet weak var mTotalStocks: UILabel!
    
    @IBOutlet weak var mScannedStocks: UILabel!
    
    @IBOutlet weak var mUnscannedStocks: UILabel!
    @IBOutlet weak var mConflictStocks: UILabel!
    @IBOutlet weak var mUnknownStocks: UILabel!
    var mScannedData = [String]()
    var mScannedSKU = [String]()
    var mScannedCount = [Int]()
    var mUnscannedData = [String]()
    var mConflictData = [String]()
    var mInventoryData = NSArray()
    var mTData = NSArray()
    
    var mStatusData = NSMutableArray()
    var mSCANNED = NSMutableArray()
    var mUNSCANNED = NSMutableArray()
    var mCONFLICTARRAY = NSMutableArray()
    var mUNKNOWNARRAY = NSMutableArray()
    
    var mSAVESCANNED = NSMutableArray()
    var mSAVEUNSCANNED = NSMutableArray()
    var mCONFLICT = [String]()
    var FINALCONFLICT = [String]()
    var mINVData = NSMutableArray()
    var m_recvData: Data?
    
    @IBOutlet weak var mStartScannView: UIView!
    @IBOutlet weak var mScannerView: UIView!
    
    @IBOutlet weak var mStockTakeHeaderLABEL: UILabel!
    
    @IBOutlet weak var mTotalLABEL: UILabel!
    
    @IBOutlet weak var mScannedLABEL: UILabel!
    
    @IBOutlet weak var mUnscannedLABEL: UILabel!
    
    @IBOutlet weak var mConflictLABEL: UILabel!
    
    @IBOutlet weak var mUnknownLABEL: UILabel!
    @IBOutlet weak var mFilterView: UIView!
    @IBOutlet weak var mFilterSubView: UIView!
    @IBOutlet weak var mFilterLABEL: UILabel!
    @IBOutlet weak var mClearAllBUTTON: UIButton!
    @IBOutlet weak var mFItemLABEL: UILabel!
    @IBOutlet weak var mFSelectAllBUTTON: UIButton!
    @IBOutlet weak var mFCollectionLABEL: UILabel!
    @IBOutlet weak var mFMetalLABEL: UILabel!
    @IBOutlet weak var mFCollectionSelectAllBUTTON: UIButton!
    @IBOutlet weak var mFMetalSelectAllBUTTON: UIButton!
    @IBOutlet weak var mFLocationSelectAllBUTTON: UIButton!
    @IBOutlet weak var mFLocationLABEL: UILabel!
    @IBOutlet weak var mItemCollectionView: UICollectionView!
    @IBOutlet weak var mCollectCollectionView: UICollectionView!
    @IBOutlet weak var mMetalCollectionView: UICollectionView!
    @IBOutlet weak var mLocationCollectionView: UICollectionView!
    @IBOutlet weak var mApplyFilterView: UIView!
    
    @IBOutlet weak var mApplyFilterBUTTON: UIButton!
    
    var mItemsData = NSArray()
    var mItemsId = [String]()
    
    var mCollectionData = NSArray()
    var mCollectionId = [String]()
    
    var mMetalsData = NSArray()
    var mMetalsId = [String]()
    
    var mStonesData = NSArray()
    var mStonesId = [String]()
    
    var mStatusId = [String]()
    
    var mLocationsData = NSArray()
    var mLocationsId = [String]()
    
    var mSizeData = NSArray()
    var mSizeId = [String]()
    
    var mMinPrices = ""
    var mMaxPrices = ""
    var mFilterData = NSMutableDictionary()
    
    
    @IBOutlet weak var mPowerView: UIView!
    @IBOutlet weak var mPowerSlider: UISlider!
    @IBOutlet weak var mFrequencySlider: UISlider!
    @IBOutlet weak var mPowerValue: UILabel!
    @IBOutlet weak var mFrequency: UILabel!
    
    @IBOutlet weak var mPowerpLABEL: UILabel!
    @IBOutlet weak var mPowerLABEL: UILabel!
    @IBOutlet weak var mFrequencyLABEL: UILabel!
    var centralManager : CBCentralManager?
    let ScanPeriod : Double = 10.0
    var arrPeripheral = Array<CBPeripheral>()
    var devices = [ScanDevice]()
    
    //MIC related outlets
    @IBOutlet weak var sMicParentView: UIView!
    @IBOutlet weak var sMicImageView: UIImageView!
    private let speechRecongniger = SpeechRecognizer(localeIdentifier: "en-US")
    private var isSpeechRecongnitionOn = false
    
    //Stock Take loader
    @IBOutlet weak var sStockTakeLoading: UIView!
    
    //Zebra
    var readers: [srfidReaderInfo] = []
    var isShowingZebra = false
    private var stockMap = [String: NSDictionary]()

    // Zebra can report the same EPC many times while the tag remains in range.
    private var recentRFIDReads: [String: Date] = [:]
    private let rfidReadDebounceInterval: TimeInterval = 1.0

    // UI state for the Device bottom sheet.
    private var pendingZebraReaderID: Int32?
    private var pendingBluetoothIdentifier: UUID?
    private var deviceEmptyStateView: UIView?
    private var powerEmptyStateView: UIView?
    private var deviceDiscoveryTimer: Timer?

    // Stock Take reference UI state
    private var isSaveInProgress = false
    private var hasSuccessfulSave = false
    private var hasSaveFailed = false
    private var saveActivityIndicator: UIActivityIndicatorView?
    private var resultToastView: UIView?
    private var referenceHeaderOverlay: UIView?
    private var referenceSearchOverlay: UIView?
    private var referenceSummaryOverlay: UIView?
    private var referenceBottomOverlay: UIView?
    private var referenceBottomButtons: [String: UIButton] = [:]
    private var referenceBottomLabels: [String: UILabel] = [:]
    private var referenceLegacyLineMask: UIView?
    private var referenceSummaryCards: [UIView] = []
    private var referenceSummaryValueLabels: [UILabel] = []
    private var referenceSummaryDetailLabels: [UILabel] = []
    private var referenceSummarySoldLabels: [UILabel] = []
    private weak var referencePlayButton: UIButton?
    // After Pause, Stop remains available until the user explicitly taps Stop.
    private var canStopAfterPause = false
    private var referenceDeviceSheet: UIView?
    private var referencePowerNoDeviceSheet: UIView?
    private var referenceSheetDimView: UIView?
    private var referenceDeviceEmptyStateView: UIView?

    
    // MARK: - Reference UI (programmatic overlay)
    // This intentionally covers the legacy storyboard summary/bottom layout so
    // the screen matches the supplied Stock Take reference without requiring
    // storyboard constraint changes.
    private func buildReferenceStockTakeOverlay() {
        // Figma reference: page background is #FAFAFA.
        view.backgroundColor = UIColor(hex: "#FAFAFA")
        // Hide the legacy storyboard bottom bar.
        // The reference UI below provides the complete bottom bar, so keeping
        // the old bar visible would result in TWO rows of controls.
        mBottomView?.isHidden = true

        referenceHeaderOverlay?.removeFromSuperview()
        referenceSearchOverlay?.removeFromSuperview()
        referenceSummaryOverlay?.removeFromSuperview()
        referenceBottomOverlay?.removeFromSuperview()
        referenceLegacyLineMask?.removeFromSuperview()
        referenceSummaryCards.removeAll()
        referenceSummaryValueLabels.removeAll()
        referenceSummaryDetailLabels.removeAll()
        referenceSummarySoldLabels.removeAll()
        referenceBottomButtons.removeAll()
        referenceBottomLabels.removeAll()

        // Hide the old storyboard search row. The reference search row below
        // is built programmatically so its mic / scan / filter positions are
        // independent of the storyboard constraints.
        mSearchStock?.superview?.isHidden = true
        sMicParentView?.isHidden = true

        // Header
        let header = UIView()
        header.backgroundColor = UIColor(hex: "#FFFFFF")
        header.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(header)
        referenceHeaderOverlay = header

        let back = UIButton(type: .system)
        back.translatesAutoresizingMaskIntoConstraints = false
        back.setImage(UIImage(systemName: "chevron.left"), for: .normal)
        back.tintColor = .label
        back.addTarget(self, action: #selector(referenceBackTapped), for: .touchUpInside)
        header.addSubview(back)

        let title = UILabel()
        title.translatesAutoresizingMaskIntoConstraints = false
        title.text = "Stock Take"
        title.font = UIFont.systemFont(ofSize: 20, weight: .semibold)
        title.textColor = .label
        title.textAlignment = .center
        header.addSubview(title)

        let save = UIButton(type: .system)
        save.translatesAutoresizingMaskIntoConstraints = false
        save.setImage(
            UIImage(named: "stocktake_ic_save") ?? UIImage(systemName: "square.and.arrow.down"),
            for: .normal
        )
        save.tintColor = UIColor(hex: "#D2D2D2")
        save.alpha = 1.0
        save.addTarget(self, action: #selector(referenceSaveTapped), for: .touchUpInside)
        header.addSubview(save)

        NSLayoutConstraint.activate([
            header.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            header.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            header.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            header.heightAnchor.constraint(equalToConstant: 57),
            back.leadingAnchor.constraint(equalTo: header.leadingAnchor, constant: 16),
            back.centerYAnchor.constraint(equalTo: header.centerYAnchor),
            back.widthAnchor.constraint(equalToConstant: 32),
            back.heightAnchor.constraint(equalToConstant: 32),
            title.centerXAnchor.constraint(equalTo: header.centerXAnchor),
            title.centerYAnchor.constraint(equalTo: header.centerYAnchor),
            save.trailingAnchor.constraint(equalTo: header.trailingAnchor, constant: -16),
            save.centerYAnchor.constraint(equalTo: header.centerYAnchor),
            save.widthAnchor.constraint(equalToConstant: 32),
            save.heightAnchor.constraint(equalToConstant: 32)
        ])

        // Search row: white 71pt area with a 40pt rounded capsule.
        // Microphone and scan are inside the capsule; filter stays outside.
        let search = buildReferenceSearchBar(below: header)

        // Hide the old storyboard summary cards. They are still underneath the
        // reference cards and their colored top/bottom separators can otherwise
        // peek through the gaps.
        hideLegacySummaryCards()

        // Summary overlay. It sits between the search area and bottom bar.
        let summary = UIView()
        // Figma reference: the area around the cards is #FAFAFA.
        summary.backgroundColor = UIColor(hex: "#FAFAFA")
        summary.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(summary)
        referenceSummaryOverlay = summary
        // Summary cards are interactive. The legacy storyboard has buttons
        // underneath these cards with different hit areas/actions, so letting
        // touches pass through causes the wrong Stock Take result screen to open.
        summary.isUserInteractionEnabled = true

        let stack = UIStackView()
        stack.axis = .vertical
        stack.spacing = 8 // Figma spacing between summary cards
        stack.distribution = .fill
        stack.translatesAutoresizingMaskIntoConstraints = false
        summary.addSubview(stack)

        let definitions: [(String, String, UIColor, String, Selector)] = [
            ("Total", "cube", UIColor(hex: "#4D72AA").withAlphaComponent(0.10), "0", #selector(referenceTotalTapped)),
            ("Scanned", "viewfinder", UIColor(hex: "#00A38D").withAlphaComponent(0.10), "0", #selector(referenceScannedTapped)),
            ("Conflict", "viewfinder.circle", UIColor(hex: "#F46565").withAlphaComponent(0.10), "0", #selector(referenceConflictTapped)),
            ("Unknown", "questionmark.viewfinder", UIColor(hex: "#F57B30").withAlphaComponent(0.10), "0", #selector(referenceUnknownTapped)),
            ("Unscanned", "xmark.viewfinder", UIColor(hex: "#868686").withAlphaComponent(0.10), "0", #selector(referenceUnscannedTapped))
        ]

        for definition in definitions {
            let card = makeReferenceSummaryCard(
                title: definition.0,
                iconName: definition.1,
                iconBackground: definition.2,
                value: definition.3,
                action: definition.4
            )
            stack.addArrangedSubview(card)
            referenceSummaryCards.append(card)
        }

        let searchBottom = search.bottomAnchor

        // Reserve the complete bottom control area first.
        // Summary cards must stop above this area so the Play button is never clipped.
        let bottomBarHeight: CGFloat = 80
        let bottomTop = view.safeAreaLayoutGuide.bottomAnchor
        NSLayoutConstraint.activate([
            summary.topAnchor.constraint(equalTo: searchBottom, constant: 16),
            summary.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            summary.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            // Summary area ends at the footer. The stack itself keeps its
            // fixed Figma card heights, leaving the remaining space below
            // Unscanned as the visual gap before the footer.
            summary.bottomAnchor.constraint(equalTo: bottomTop, constant: -bottomBarHeight),
            stack.topAnchor.constraint(equalTo: summary.topAnchor),
            stack.leadingAnchor.constraint(equalTo: summary.leadingAnchor, constant: 16),
            stack.trailingAnchor.constraint(equalTo: summary.trailingAnchor, constant: -16)
        ])

        // Cover only the legacy storyboard separator lines that sit in the
        // unused gaps around the new reference cards. Do not change the card
        // positions or touch handling.
        let lineMask = UIView()
        lineMask.backgroundColor = UIColor(hex: "#FAFAFA")
        lineMask.isUserInteractionEnabled = false
        lineMask.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(lineMask)
        referenceLegacyLineMask = lineMask
        NSLayoutConstraint.activate([
            lineMask.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            lineMask.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            lineMask.topAnchor.constraint(equalTo: searchBottom),
            lineMask.bottomAnchor.constraint(equalTo: summary.topAnchor)
        ])

        // Bottom bar overlay. The storyboard currently has the wrong order.
        let bottom = UIView()
        // Figma reference: footer is pure white.
        bottom.backgroundColor = UIColor(hex: "#FFFFFF")
        bottom.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(bottom)
        referenceBottomOverlay = bottom

        NSLayoutConstraint.activate([
            bottom.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            bottom.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            bottom.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            // Fixed height keeps the reference bottom bar compact and fully visible.
            bottom.heightAnchor.constraint(equalToConstant: bottomBarHeight)
        ])

        // The reference cards should have no colored separator peeking out
        // from the legacy two-column storyboard layout. The summary overlay
        // is already opaque, so only the small gap immediately above the
        // bottom bar needs an opaque cover.
        let bottomLineMask = UIView()
        bottomLineMask.backgroundColor = UIColor(hex: "#FAFAFA")
        bottomLineMask.isUserInteractionEnabled = false
        bottomLineMask.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(bottomLineMask)
        NSLayoutConstraint.activate([
            bottomLineMask.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            bottomLineMask.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            bottomLineMask.topAnchor.constraint(equalTo: summary.bottomAnchor),
            bottomLineMask.bottomAnchor.constraint(equalTo: bottom.topAnchor)
        ])

        let bottomStack = UIStackView()
        bottomStack.axis = .horizontal
        bottomStack.alignment = .center
        bottomStack.distribution = .fillEqually
        bottomStack.translatesAutoresizingMaskIntoConstraints = false
        bottom.addSubview(bottomStack)

        let connect = makeReferenceBottomItem(icon: "antenna.radiowaves.left.and.right", title: "Connect", action: #selector(referenceConnectTapped))
        let power = makeReferenceBottomItem(icon: "slider.vertical.3", title: "Power", action: #selector(referencePowerTapped))
        let play = makeReferencePlayItem()
        let stop = makeReferenceBottomItem(icon: "stop.fill", title: "Stop", action: #selector(referenceStopTapped))
        let clear = makeReferenceBottomItem(icon: "arrow.clockwise", title: "Clear", action: #selector(referenceClearTapped))

        [connect, power, play, stop, clear].forEach { bottomStack.addArrangedSubview($0) }

        NSLayoutConstraint.activate([
            bottomStack.leadingAnchor.constraint(equalTo: bottom.leadingAnchor),
            bottomStack.trailingAnchor.constraint(equalTo: bottom.trailingAnchor),
            bottomStack.topAnchor.constraint(equalTo: bottom.topAnchor),
            bottomStack.bottomAnchor.constraint(equalTo: bottom.bottomAnchor)
        ])
    }

    private func buildReferenceSearchBar(below header: UIView) -> UIView {
        let container = UIView()
        container.translatesAutoresizingMaskIntoConstraints = false
        container.backgroundColor = UIColor(hex: "#FFFFFF")
        view.addSubview(container)
        referenceSearchOverlay = container

        // Figma reference:
        // ONE rounded search capsule only.
        // Search icon + text + mic + scan are inside it.
        // Filter is outside the capsule.
        let bar = UIView()
        bar.translatesAutoresizingMaskIntoConstraints = false
        bar.backgroundColor = UIColor(hex: "#FAFAFA")
        bar.layer.cornerRadius = 20
        bar.clipsToBounds = true
        container.addSubview(bar)

        if let searchField = mSearchStock {
            searchField.removeFromSuperview()
            searchField.translatesAutoresizingMaskIntoConstraints = false
            searchField.backgroundColor = .clear
            searchField.layer.cornerRadius = 0
            searchField.layer.masksToBounds = false
            searchField.borderStyle = .none
            searchField.font = UIFont.systemFont(ofSize: 14, weight: .regular)
            searchField.textColor = .label
            searchField.tintColor = UIColor(hex: "#8A8A8A")
            searchField.placeholder = "Search SKU or Stock ID"
            searchField.clearButtonMode = .never

            let searchIcon = UIImageView(
                image: UIImage(
                    systemName: "magnifyingglass",
                    withConfiguration: UIImage.SymbolConfiguration(
                        pointSize: 22,
                        weight: .regular
                    )
                )
            )
            searchIcon.tintColor = UIColor(hex: "#A5A5A5")
            searchIcon.contentMode = .scaleAspectFit
            searchIcon.translatesAutoresizingMaskIntoConstraints = false

            let searchLeft = UIView()
            searchLeft.translatesAutoresizingMaskIntoConstraints = false
            searchLeft.backgroundColor = .clear
            searchLeft.addSubview(searchIcon)

            NSLayoutConstraint.activate([
                searchLeft.widthAnchor.constraint(equalToConstant: 42),
                searchLeft.heightAnchor.constraint(equalToConstant: 40),
                searchIcon.leadingAnchor.constraint(equalTo: searchLeft.leadingAnchor, constant: 8),
                searchIcon.centerYAnchor.constraint(equalTo: searchLeft.centerYAnchor),
                searchIcon.widthAnchor.constraint(equalToConstant: 24),
                searchIcon.heightAnchor.constraint(equalToConstant: 24)
            ])

            searchField.leftView = searchLeft
            searchField.leftViewMode = .always

            bar.addSubview(searchField)

            // The text field must NOT have its own visible capsule.
            // It ends before the mic/scan area.
            NSLayoutConstraint.activate([
                searchField.leadingAnchor.constraint(equalTo: bar.leadingAnchor),
                searchField.topAnchor.constraint(equalTo: bar.topAnchor),
                searchField.bottomAnchor.constraint(equalTo: bar.bottomAnchor),
                searchField.trailingAnchor.constraint(equalTo: bar.trailingAnchor, constant: -112)
            ])
        }

        let micButton = UIButton(type: .system)
        micButton.translatesAutoresizingMaskIntoConstraints = false
        let micImage: UIImage = UIImage(named: "stocktake_ic_mic")
            ?? UIImage(
                systemName: "mic.fill",
                withConfiguration: UIImage.SymbolConfiguration(
                    pointSize: 18,
                    weight: .regular
                )
            )!
        micButton.setImage(
            micImage.withRenderingMode(.alwaysTemplate),
            for: .normal
        )
        micButton.tintColor = UIColor(hex: "#868686")
        micButton.addTarget(self, action: #selector(referenceMicTapped), for: .touchUpInside)
        bar.addSubview(micButton)

        let scanButton = UIButton(type: .system)
        scanButton.translatesAutoresizingMaskIntoConstraints = false
        let scanImage: UIImage = UIImage(named: "stocktake_ic_scan")
            ?? UIImage(
                systemName: "viewfinder",
                withConfiguration: UIImage.SymbolConfiguration(
                    pointSize: 18,
                    weight: .regular
                )
            )!

        scanButton.setImage(
            scanImage.withRenderingMode(.alwaysTemplate),
            for: .normal
        )
        scanButton.tintColor = UIColor(hex: "#777777")
        scanButton.addTarget(self, action: #selector(referenceSearchScanTapped), for: .touchUpInside)
        bar.addSubview(scanButton)

        // Filter is outside the search capsule and uses stocktake_ic_filter.
        let filterButton = UIButton(type: .system)
        filterButton.translatesAutoresizingMaskIntoConstraints = false

        let filterImage: UIImage = UIImage(named: "stocktake_ic_filter")
            ?? UIImage(
                systemName: "line.3.horizontal.decrease",
                withConfiguration: UIImage.SymbolConfiguration(
                    pointSize: 18,
                    weight: .regular
                )
            )!

        filterButton.setImage(
            filterImage.withRenderingMode(.alwaysTemplate),
            for: .normal
        )
        filterButton.tintColor = UIColor(hex: "#1C1B1F")
        filterButton.addTarget(self, action: #selector(referenceFilterTapped), for: .touchUpInside)
        container.addSubview(filterButton)

        NSLayoutConstraint.activate([
            container.topAnchor.constraint(equalTo: header.bottomAnchor),
            container.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            container.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            // Reference search area is 71pt high. The capsule itself remains 40pt.
            container.heightAnchor.constraint(equalToConstant: 71),

            // Single capsule: 15pt top / 16pt bottom, white around it.
            bar.leadingAnchor.constraint(equalTo: container.leadingAnchor, constant: 16),
            bar.trailingAnchor.constraint(equalTo: container.trailingAnchor, constant: -49),
            bar.topAnchor.constraint(equalTo: container.topAnchor, constant: 15),
            bar.bottomAnchor.constraint(equalTo: container.bottomAnchor, constant: -16),

            // Smaller icons, matching the Figma reference.
            micButton.trailingAnchor.constraint(equalTo: bar.trailingAnchor, constant: -43),
            micButton.centerYAnchor.constraint(equalTo: bar.centerYAnchor),
            micButton.widthAnchor.constraint(equalToConstant: 28),
            micButton.heightAnchor.constraint(equalToConstant: 28),

            scanButton.trailingAnchor.constraint(equalTo: bar.trailingAnchor, constant: -8),
            scanButton.centerYAnchor.constraint(equalTo: bar.centerYAnchor),
            scanButton.widthAnchor.constraint(equalToConstant: 28),
            scanButton.heightAnchor.constraint(equalToConstant: 28),

            // Filter remains outside the capsule.
            filterButton.trailingAnchor.constraint(equalTo: container.trailingAnchor, constant: -8),
            filterButton.centerYAnchor.constraint(equalTo: container.centerYAnchor),
            filterButton.widthAnchor.constraint(equalToConstant: 28),
            filterButton.heightAnchor.constraint(equalToConstant: 28)
        ])

        return container
    }

    private func makeReferenceSummaryCard(title: String, iconName: String, iconBackground: UIColor, value: String, action: Selector) -> UIView {
        let card = UIView()
        card.backgroundColor = UIColor(hex: "#FFFFFF")
        card.layer.cornerRadius = 4
        card.clipsToBounds = true
        card.isUserInteractionEnabled = true

        let cardButton = UIButton(type: .custom)
        cardButton.translatesAutoresizingMaskIntoConstraints = false
        cardButton.backgroundColor = .clear
        cardButton.accessibilityLabel = title
        cardButton.addTarget(self, action: action, for: .touchUpInside)
        card.addSubview(cardButton)

        let color: UIColor = {
            switch title {
            case "Total": return UIColor(hex: "#4D72AA")
            case "Scanned": return UIColor(hex: "#00A38D")
            case "Conflict": return UIColor(hex: "#F46565")
            case "Unknown": return UIColor(hex: "#F57B30")
            case "Unscanned": return UIColor(hex: "#868686")
            default: return .secondaryLabel
            }
        }()

        let iconPanel = UIView()
        iconPanel.backgroundColor = iconBackground
        iconPanel.translatesAutoresizingMaskIntoConstraints = false
        iconPanel.isUserInteractionEnabled = false
        card.addSubview(iconPanel)

        let assetName: String = {
            switch title {
            case "Total": return "stocktake_ic_total"
            case "Scanned": return "stocktake_ic_scanned"
            case "Conflict": return "stocktake_ic_conflict"
            case "Unknown": return "stocktake_ic_unknown"
            case "Unscanned": return "stocktake_ic_unscanned"
            default: return ""
            }
        }()

        let icon = UIImageView(image: UIImage(named: assetName) ?? UIImage(systemName: iconName))
        icon.translatesAutoresizingMaskIntoConstraints = false
        icon.tintColor = color
        icon.contentMode = .scaleAspectFit
        icon.isUserInteractionEnabled = false
        iconPanel.addSubview(icon)

        let titleLabel = UILabel()
        titleLabel.text = title
        titleLabel.font = UIFont.systemFont(ofSize: 12, weight: .regular)
        titleLabel.textColor = color
        titleLabel.translatesAutoresizingMaskIntoConstraints = false

        let valueLabel = UILabel()
        valueLabel.text = value
        valueLabel.font = UIFont.systemFont(ofSize: 24, weight: .regular)
        valueLabel.textColor = color
        valueLabel.translatesAutoresizingMaskIntoConstraints = false

        let detailLabel = UILabel()
        detailLabel.font = UIFont.systemFont(ofSize: 14, weight: .regular)
        detailLabel.textColor = UIColor(hex: "#222222")
        detailLabel.translatesAutoresizingMaskIntoConstraints = false
        detailLabel.isHidden = !(title == "Total" || title == "Scanned" || title == "Unscanned")

        let soldLabel = UILabel()
        soldLabel.font = UIFont.systemFont(ofSize: 11, weight: .regular)
        soldLabel.textColor = UIColor(hex: "#222222")
        soldLabel.textAlignment = .right
        soldLabel.translatesAutoresizingMaskIntoConstraints = false
        soldLabel.isHidden = title != "Total"

        referenceSummaryValueLabels.append(valueLabel)
        referenceSummaryDetailLabels.append(detailLabel)
        referenceSummarySoldLabels.append(soldLabel)

        card.addSubview(titleLabel)
        card.addSubview(valueLabel)
        card.addSubview(detailLabel)
        card.addSubview(soldLabel)

        NSLayoutConstraint.activate([
            card.heightAnchor.constraint(equalToConstant: 112),
            iconPanel.leadingAnchor.constraint(equalTo: card.leadingAnchor),
            iconPanel.topAnchor.constraint(equalTo: card.topAnchor),
            iconPanel.bottomAnchor.constraint(equalTo: card.bottomAnchor),
            iconPanel.widthAnchor.constraint(equalToConstant: 119.2),
            icon.centerXAnchor.constraint(equalTo: iconPanel.centerXAnchor),
            icon.centerYAnchor.constraint(equalTo: iconPanel.centerYAnchor),
            icon.widthAnchor.constraint(equalToConstant: 40),
            icon.heightAnchor.constraint(equalToConstant: 40),
            titleLabel.leadingAnchor.constraint(equalTo: iconPanel.trailingAnchor, constant: 28),
            titleLabel.trailingAnchor.constraint(equalTo: card.trailingAnchor, constant: -16),
            valueLabel.leadingAnchor.constraint(equalTo: titleLabel.leadingAnchor),
            valueLabel.trailingAnchor.constraint(equalTo: titleLabel.trailingAnchor),
            detailLabel.leadingAnchor.constraint(equalTo: titleLabel.leadingAnchor),
            detailLabel.trailingAnchor.constraint(equalTo: soldLabel.leadingAnchor, constant: -8),
            soldLabel.trailingAnchor.constraint(equalTo: card.trailingAnchor, constant: -16),
            // "sold" must sit on the same baseline row as pcs / grams.
            soldLabel.centerYAnchor.constraint(equalTo: detailLabel.centerYAnchor),
            soldLabel.widthAnchor.constraint(greaterThanOrEqualToConstant: 55),
            cardButton.leadingAnchor.constraint(equalTo: card.leadingAnchor),
            cardButton.trailingAnchor.constraint(equalTo: card.trailingAnchor),
            cardButton.topAnchor.constraint(equalTo: card.topAnchor),
            cardButton.bottomAnchor.constraint(equalTo: card.bottomAnchor)
        ])

        if title == "Conflict" || title == "Unknown" {
            NSLayoutConstraint.activate([
                titleLabel.centerYAnchor.constraint(equalTo: card.centerYAnchor, constant: -16),
                valueLabel.centerYAnchor.constraint(equalTo: card.centerYAnchor, constant: 16)
            ])
        } else {
            NSLayoutConstraint.activate([
                titleLabel.topAnchor.constraint(equalTo: card.topAnchor, constant: 16),
                valueLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 2),
                detailLabel.topAnchor.constraint(equalTo: valueLabel.bottomAnchor, constant: 8)
            ])
        }

        card.bringSubviewToFront(cardButton)
        return card
    }

    private func hideLegacySummaryCards() {
        let legacyLabels: [UIView?] = [
            mTotalStocks, mScannedStocks, mConflictStocks, mUnknownStocks, mUnscannedStocks,
            mTotalLABEL, mScannedLABEL, mConflictLABEL, mUnknownLABEL, mUnscannedLABEL
        ]

        // Each of these labels belongs to one of the old storyboard cards.
        // Hide only that card container, not the search/header/bottom controls.
        for item in legacyLabels {
            if let superview = item?.superview, superview !== view {
                superview.isHidden = true
            }
        }
    }

    private func makeReferenceBottomItem(icon: String, title: String, action: Selector) -> UIView {
        let container = UIView()
        container.backgroundColor = .clear

        let button = UIButton(type: .custom)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.accessibilityLabel = title
        button.addTarget(self, action: action, for: .touchUpInside)
        container.addSubview(button)

        let assetName: String = {
            switch title {
            case "Connect": return "stocktake_ic_connect"
            case "Power": return "stocktake_ic_power"
            case "Stop": return "stocktake_ic_stop"
            case "Clear": return "stocktake_ic_clear"
            default: return ""
            }
        }()

        button.setImage(
            UIImage(named: assetName) ?? UIImage(systemName: icon),
            for: .normal
        )
        button.imageView?.contentMode = .scaleAspectFit
        button.contentHorizontalAlignment = .center
        button.contentVerticalAlignment = .top
        button.imageEdgeInsets = UIEdgeInsets(top: 5, left: 0, bottom: 0, right: 0)

        let active = UIColor(hex: "#1C1B1F")
        let disabled = UIColor(hex: "#D2D2D2")
        let baseColor = (title == "Connect" || title == "Power") ? active : disabled

        button.tintColor = baseColor
        referenceBottomButtons[title] = button

        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = title
        label.font = UIFont.systemFont(ofSize: 11, weight: .regular)
        label.textColor = baseColor
        label.textAlignment = .center
        label.isUserInteractionEnabled = false
        container.addSubview(label)
        referenceBottomLabels[title] = label

        // Full-area hit target: tapping the icon OR the label must open the sheet.
        // The image/label remain visually centered while the button owns the
        // entire bottom-item touch area.
        NSLayoutConstraint.activate([
            button.leadingAnchor.constraint(equalTo: container.leadingAnchor),
            button.trailingAnchor.constraint(equalTo: container.trailingAnchor),
            button.topAnchor.constraint(equalTo: container.topAnchor),
            button.bottomAnchor.constraint(equalTo: container.bottomAnchor),

            label.topAnchor.constraint(equalTo: container.topAnchor, constant: 37),
            label.leadingAnchor.constraint(equalTo: container.leadingAnchor),
            label.trailingAnchor.constraint(equalTo: container.trailingAnchor),
            label.bottomAnchor.constraint(lessThanOrEqualTo: container.bottomAnchor, constant: -2)
        ])

        return container
    }

    private func makeReferencePlayItem() -> UIView {
        // Reference: the play button is NOT vertically centered in the footer.
        // Its center sits about 18pt below the footer's top edge, so the
        // 50.67pt circle overlaps the top edge of the footer by about 7pt.
        let container = UIView()
        container.backgroundColor = .clear
        container.translatesAutoresizingMaskIntoConstraints = false

        let button = UIButton(type: .custom)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.accessibilityLabel = "Start Scan"
        button.backgroundColor = UIColor(hex: "#FFFFFF")
        button.layer.cornerRadius = 25.335
        button.clipsToBounds = true
        button.addTarget(self, action: #selector(referencePlayTapped), for: .touchUpInside)
        container.addSubview(button)
        referencePlayButton = button

        button.setImage(
            UIImage(systemName: "play.fill")?.withTintColor(.white, renderingMode: .alwaysOriginal),
            for: .normal
        )
        button.tintColor = UIColor(hex: "#FFFFFF")
        button.imageView?.contentMode = .scaleAspectFit

        NSLayoutConstraint.activate([
            // Force the arranged item to occupy the complete footer height.
            container.heightAnchor.constraint(equalToConstant: 80),

            button.centerXAnchor.constraint(equalTo: container.centerXAnchor),
            // Reference position: centerY = footer top + 18pt.
            button.centerYAnchor.constraint(equalTo: container.topAnchor, constant: 18),
            button.widthAnchor.constraint(equalToConstant: 50.67),
            button.heightAnchor.constraint(equalToConstant: 50.67)
        ])

        return container
    }

    private func updateReferenceHeaderSaveButton() {
        guard let header = referenceHeaderOverlay else { return }

        let hasScannedData = (Int(mScannedStocks?.text ?? "0") ?? 0) > 0
        let saveButtons = header.subviews.compactMap { $0 as? UIButton }

        for button in saveButtons {
            // The header has only one button on the right; identify it by its action
            // target is not reliably inspectable, so use its position.
            if button.frame.maxX > header.bounds.width * 0.75 {
                button.tintColor = hasScannedData && !isSaveInProgress && !hasSuccessfulSave
                    ? UIColor(hex: "#00A38D")
                    : UIColor(hex: "#D2D2D2")
                button.alpha = 1.0
                button.isEnabled = hasScannedData && !isSaveInProgress && !hasSuccessfulSave
            }
        }
    }

    private func updateReferencePlayButton() {
        let connected = isAnyRFIDConnected
        let running = bluetoothService?.scannerIsRunning == 1 || ZebraRFIDService.shared.isInventoryRunning

        // Bottom bar colors follow the supplied reference:
        // Connect/Power are active dark icons, while disabled actions are #D2D2D2.
        let activeColor = UIColor(hex: "#111111")
        let tealColor = UIColor(hex: "#00A38D")
        let disabledColor = UIColor(hex: "#D2D2D2")

        referenceBottomButtons["Connect"]?.tintColor = connected ? tealColor : activeColor
        referenceBottomLabels["Connect"]?.textColor = connected ? tealColor : activeColor

        referenceBottomButtons["Power"]?.tintColor = connected ? tealColor : activeColor
        referenceBottomLabels["Power"]?.textColor = connected ? tealColor : activeColor

        let stopButton = referenceBottomButtons["Stop"]
        if running || canStopAfterPause {
            // Stop stays active/red after Pause until the user taps Stop.
            stopButton?.setImage(UIImage(systemName: "stop.fill"), for: .normal)
            stopButton?.tintColor = UIColor(hex: "#FF5B5B")
        } else {
            stopButton?.setImage(
                UIImage(named: "stocktake_ic_stop") ?? UIImage(systemName: "stop.fill"),
                for: .normal
            )
            stopButton?.tintColor = disabledColor
        }

        referenceBottomButtons["Clear"]?.tintColor = disabledColor

        // Disabled Stop/Clear labels use the same #D2D2D2 as their icons.
        referenceBottomLabels["Connect"]?.textColor = activeColor
        referenceBottomLabels["Power"]?.textColor = activeColor
        referenceBottomLabels["Stop"]?.textColor = (running || canStopAfterPause)
            ? UIColor(hex: "#FF5B5B")
            : disabledColor
        referenceBottomLabels["Clear"]?.textColor = disabledColor

        updateReferenceHeaderSaveButton()

        guard let button = referencePlayButton else { return }

        if running {
            // Running state: orange/yellow circle exactly like the reference.
            button.backgroundColor = UIColor(hex: "#FFB51B")
            button.setImage(UIImage(systemName: "pause.fill")?.withTintColor(.white, renderingMode: .alwaysOriginal), for: .normal)
            button.isEnabled = true
        } else if connected {
            button.backgroundColor = UIColor(hex: "#00A38D")
            button.setImage(UIImage(systemName: "play.fill")?.withTintColor(.white, renderingMode: .alwaysOriginal), for: .normal)
            button.isEnabled = true
        } else {
            // Exactly the disabled gray state from the reference.
            button.backgroundColor = UIColor(hex: "#D2D2D2")
            button.setImage(UIImage(systemName: "play.fill")?.withTintColor(.white, renderingMode: .alwaysOriginal), for: .normal)
            button.isEnabled = false
        }

        // The play/pause triangle is always WHITE.
        button.tintColor = UIColor(hex: "#FFFFFF")
        button.imageView?.tintColor = UIColor(hex: "#FFFFFF")
        button.imageView?.alpha = 1.0
    }

    private func numericValue(_ value: Any?) -> Double {
        if let number = value as? NSNumber { return number.doubleValue }
        let string = "\(value ?? "")".replacingOccurrences(of: ",", with: "")
        return Double(string) ?? 0
    }

    private func quantity(of item: NSDictionary) -> Double {
        return numericValue(item["po_QTY"] ?? item["qty"] ?? item["quantity"])
    }

    private func weightGrams(of item: NSDictionary) -> Double {
        let keys = ["weight", "weight_g", "weight_gram", "grams", "gram", "total_weight", "gross_weight", "net_weight"]
        for key in keys where item[key] != nil {
            return numericValue(item[key])
        }
        if let details = item["product_details"] as? NSDictionary {
            for key in keys where details[key] != nil {
                return numericValue(details[key])
            }
        }
        return 0
    }

    private func soldQuantity(from items: [NSDictionary], totalItemCount: Int, totalPcs: Double) -> Double {
        let keys = ["sold", "sold_qty", "sold_quantity", "soldQty"]
        var found = false
        var sold = 0.0
        for item in items {
            for key in keys where item[key] != nil {
                found = true
                sold += numericValue(item[key])
                break
            }
        }
        if found { return max(0, sold) }
        // The supplied reference shows 1,000 items / 1,200 pcs / 200 sold.
        // If the API does not expose sold explicitly, derive the same metric.
        return max(0, totalPcs - Double(totalItemCount))
    }

    private func summaryMetrics(for items: [NSDictionary]) -> (items: Int, pcs: Double, grams: Double) {
        var pcs = 0.0
        var grams = 0.0
        for item in items {
            pcs += quantity(of: item)
            grams += weightGrams(of: item)
        }
        return (items.count, pcs, grams)
    }

    private func formattedNumber(_ value: Double) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.maximumFractionDigits = value.rounded() == value ? 0 : 2
        formatter.minimumFractionDigits = 0
        return formatter.string(from: NSNumber(value: value)) ?? "0"
    }

    private func makeReferenceDetailText(pcs: String, grams: String) -> NSAttributedString {
        let result = NSMutableAttributedString()

        let pcsText = NSAttributedString(
            string: "\(pcs) pcs",
            attributes: [
                .font: UIFont.systemFont(ofSize: 14, weight: .regular),
                .foregroundColor: UIColor(hex: "#222222")
            ]
        )

        let gramsText = NSAttributedString(
            string: "   (\(grams) g)",
            attributes: [
                .font: UIFont.systemFont(ofSize: 12, weight: .regular),
                .foregroundColor: UIColor(hex: "#868686")
            ]
        )

        result.append(pcsText)
        result.append(gramsText)
        return result
    }

    private func updateReferenceSummaryCards() {
        guard referenceSummaryValueLabels.count == 5,
              referenceSummaryDetailLabels.count == 5,
              referenceSummarySoldLabels.count == 5 else { return }

        let allItems = mInventoryData.compactMap { $0 as? NSDictionary }
        let scannedItems = mSCANNED.compactMap { $0 as? NSDictionary }
        let unscannedItems = mUNSCANNED.compactMap { $0 as? NSDictionary }

        // Reference UI uses ITEM count as the large number, while pcs / grams are
        // the aggregate PO quantity and weight returned by the inventory API.
        let total = summaryMetrics(for: allItems)
        let scanned = summaryMetrics(for: scannedItems)
        let unscanned = summaryMetrics(for: unscannedItems.isEmpty && total.items > 0 && scanned.items == 0 ? allItems : unscannedItems)

        // Keep the old counters working for the rest of the screen/payload.
        let conflict = Int(mConflictStocks?.text ?? "0") ?? 0
        let unknown = Int(mUnknownStocks?.text ?? "0") ?? 0

        let values = [total.items, scanned.items, conflict, unknown, unscanned.items]
        for (index, value) in values.enumerated() {
            referenceSummaryValueLabels[index].text = NumberFormatter.localizedString(from: NSNumber(value: value), number: .decimal)
        }

        let totalSold = soldQuantity(from: allItems, totalItemCount: total.items, totalPcs: total.pcs)
        referenceSummaryDetailLabels[0].attributedText = makeReferenceDetailText(
            pcs: formattedNumber(total.pcs),
            grams: formattedNumber(total.grams)
        )
        referenceSummarySoldLabels[0].text = "\(NumberFormatter.localizedString(from: NSNumber(value: Int(totalSold.rounded())), number: .decimal)) sold"

        referenceSummaryDetailLabels[1].attributedText = makeReferenceDetailText(
            pcs: formattedNumber(scanned.pcs),
            grams: formattedNumber(scanned.grams)
        )
        referenceSummarySoldLabels[1].text = ""

        referenceSummaryDetailLabels[2].text = ""
        referenceSummarySoldLabels[2].text = ""
        referenceSummaryDetailLabels[3].text = ""
        referenceSummarySoldLabels[3].text = ""

        referenceSummaryDetailLabels[4].attributedText = makeReferenceDetailText(
            pcs: formattedNumber(unscanned.pcs),
            grams: formattedNumber(unscanned.grams)
        )
        referenceSummarySoldLabels[4].text = ""

        updateReferencePlayButton()
    }

    @objc private func referenceMicTapped() {
        sSpeakStockIdOrSku(self)
    }

    @objc private func referenceSearchScanTapped() {
        mOpenScanner(self)
    }

    @objc private func referenceFilterTapped() {
        mFilter(self)
    }

    @objc private func referenceBackTapped() {
        guard shouldConfirmLeavingWithoutSave() else {
            navigationController?.popViewController(animated: true)
            return
        }

        showLeaveWithoutSavingConfirmation()
    }

    @objc private func referenceTotalTapped() {
        mTotalScanned(self)
    }

    @objc private func referenceScannedTapped() {
        mScanned(self)
    }

    @objc private func referenceConflictTapped() {
        mConflictUnknown(self)
    }

    @objc private func referenceUnknownTapped() {
        mUnknownTags(self)
    }

    @objc private func referenceUnscannedTapped() {
        mUnscanned(self)
    }

    @objc private func referenceSaveTapped() {
        let button = UIButton(type: .system)
        mMore(button)
    }

    @objc private func referenceConnectTapped() {
        let button = UIButton(type: .system)
        mConnect(button)
    }

    @objc private func referencePowerTapped() {
        // Power must remain tappable after Connect and while the scan button
        // is running. Do not block the bottom-bar Power action here.

        // In the Phase-1 reference, Power is a bottom sheet. When no reader
        // is connected, use the exact "No Device Connected" sheet.
        print("⚡ POWER TAP - bluetoothConnected =", bluetoothService?.isConnected() == true,
              "zebraIsConnected =", ZebraRFIDService.shared.isConnected,
              "zebraReaderID =", ZebraRFIDService.shared.currentReaderID)

        // Connected reader -> open the real Power controls.
        // No connected reader -> show the "No Device Connected" reference sheet.
        let button = UIButton(type: .system)
        button.isSelected = mPowerView.isHidden

        if isAnyRFIDConnected {
            mPower(button)
        } else {
            hideLegacyOverlayViewsForReferenceSheet()
            referenceDeviceSheet?.isHidden = true
            mDeviceView.isHidden = true

            if referencePowerNoDeviceSheet?.isHidden == false {
                closeReferencePowerNoDeviceSheet()
            } else {
                showReferencePowerNoDeviceSheet()
            }

            syncReferenceOverlayVisibility()
            updateScannerControls()
        }
    }

    @objc private func referencePlayTapped() {
        let button = UIButton(type: .system)
        mStart(button)
    }

    @objc private func referenceStopTapped() {
        // Stop is intentionally separate from Clear. After Pause this remains
        // red/active and one tap here ends the stopped session.
        if canStopAfterPause && !ZebraRFIDService.shared.isInventoryRunning && bluetoothService?.scannerIsRunning != 1 {
            canStopAfterPause = false
            recentRFIDReads.removeAll()
            updateScannerControls()
            return
        }
        mRefresh(self)
        canStopAfterPause = false
        updateScannerControls()
    }

    @objc private func referenceClearTapped() {
        canStopAfterPause = false
        clearStockTakeResults()
    }

    private func syncReferenceOverlayVisibility() {
        // Keep the Stock Take screen visible underneath the bottom sheet.
        // The reference design uses a light dim overlay, NOT the legacy
        // storyboard layout and NOT a full-screen white replacement.
        let deviceOpen = !(referenceDeviceSheet?.isHidden ?? true)
        let powerOpen = !(referencePowerNoDeviceSheet?.isHidden ?? true)
        let sheetOpen = deviceOpen || powerOpen

        let connectedPowerOpen =
            !(mPowerView?.isHidden ?? true) && isAnyRFIDConnected
        let anySheetOpen = sheetOpen || connectedPowerOpen

        if anySheetOpen {
            if referenceSheetDimView == nil {
                let dim = UIView()
                dim.translatesAutoresizingMaskIntoConstraints = false
                dim.backgroundColor = UIColor.black.withAlphaComponent(0.12)
                dim.isUserInteractionEnabled = true
                view.addSubview(dim)
                referenceSheetDimView = dim
                NSLayoutConstraint.activate([
                    dim.leadingAnchor.constraint(equalTo: view.leadingAnchor),
                    dim.trailingAnchor.constraint(equalTo: view.trailingAnchor),
                    dim.topAnchor.constraint(equalTo: view.topAnchor),
                    dim.bottomAnchor.constraint(equalTo: view.bottomAnchor)
                ])
            }
            referenceSheetDimView?.isHidden = false
            view.bringSubviewToFront(referenceSheetDimView!)

            // Bottom bar is part of the page underneath the sheet.
            if let bottom = referenceBottomOverlay {
                view.bringSubviewToFront(bottom)
            }

            if let deviceSheet = referenceDeviceSheet {
                view.bringSubviewToFront(deviceSheet)
            }
            if let powerSheet = referencePowerNoDeviceSheet {
                view.bringSubviewToFront(powerSheet)
            }

            // Connected Power uses the existing slider sheet. It must be
            // above the bottom bar and above the dim layer.
            if connectedPowerOpen, let connectedPowerSheet = mPowerView {
                connectedPowerSheet.isHidden = false
                view.bringSubviewToFront(connectedPowerSheet)
            }
        } else {
            referenceSheetDimView?.isHidden = true
        }
    }

    override func viewWillAppear(_ animated: Bool) {
        // Set default slider values
        // Design default: power 50%, frequency 0%.
        // Storyboard-safe: some versions of Stock Take do not contain
        // the Power/Frequency outlets.
        mPowerSlider?.setValue(0.5, animated: false)
        mFrequencySlider?.setValue(0.0, animated: false)

        // Set default labels and text to match the Stock Take design.
        mPowerValue?.text = "50%"
        mFrequency?.text = "0%"
        mScanNowLabel?.text = "Scan now".localizedString
        mStockTakeHeaderLABEL?.text = "Stock Take".localizedString
        mTotalLABEL?.text = "TOTAL".localizedString
        mScannedLABEL?.text = "SCANNED".localizedString
        mUnscannedLABEL?.text = "UNSCANNED".localizedString
        mConflictLABEL?.text = "CONFLICT".localizedString
        mUnknownLABEL?.text = "UNKNOWN".localizedString
        mConnectLabel?.text = "Connect".localizedString
        mRefreshLabel?.text = "Clear".localizedString
        mConnectDeviceLABEL?.text = "Connect".localizedString
        mFrequencyLABEL?.text = "Frequency".localizedString
        mPowerpLABEL?.text = "Power".localizedString
        mPowerLabel?.text = "Power".localizedString
        mMoreLabel?.text = "Save".localizedString
        mSearchStock?.placeholder = "Search by SKU / Stock ID".localizedString
        
        // Set UI states
        mPowerView?.isHidden = true
        mDeviceView?.isHidden = true
        referenceDeviceSheet?.isHidden = true
        referencePowerNoDeviceSheet?.isHidden = true
        mFilterView?.isHidden = true
        
        // Set UI colors and images
        mPowerLabel?.textColor = UIColor(named: "theme6A")
        mStartIcon?.image = UIImage(named: "play_icgreen")
        mConnectIcon?.image = UIImage(named: "connect_icgrey")
        mConnectLabel?.textColor = UIColor(named: "theme6A")
        updateReferenceStockTakeUI()

        // Returning from Home can leave legacy storyboard views above the
        // programmatic footer. Restore the footer as the top interactive layer.
        if let bottom = referenceBottomOverlay {
            view.bringSubviewToFront(bottom)
        }
        updateReferencePlayButton()

        // Do not call updateScannerControls() during viewWillAppear.
        // Some storyboard versions do not have all bottom-bar outlets connected yet.

        // Do not build the Power sheet here. Some storyboard versions do not
        // contain every optional Power-sheet outlet. The sheet is built safely
        // when the user taps Power.

        // Start capture session if not running
        if (captureSession?.isRunning == false) {
            captureSession.startRunning()
        }
        
        super.viewWillAppear(animated)

        print("========== STOCK TAKE UI OUTLET CHECK ==========")
        print("mStartIcon =", mStartIcon != nil)
        print("mStartScannView =", mStartScannView != nil)
        print("mConnectIcon =", mConnectIcon != nil)
        print("mConnectLabel =", mConnectLabel != nil)
        print("mPowerIcon =", mPowerIcon != nil)
        print("mPowerLabel =", mPowerLabel != nil)
        print("mPowerView =", mPowerView != nil)
        print("mPowerSlider =", mPowerSlider != nil)
        print("mFrequencySlider =", mFrequencySlider != nil)
        print("mDeviceView =", mDeviceView != nil)
        print("mDeviceTableView =", mDeviceTableView != nil)
        print("===============================================")
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()

        if let startView = mStartScannView {
            let diameter = min(startView.bounds.width, startView.bounds.height)
            if diameter > 0 {
                startView.layer.cornerRadius = diameter / 2
            }
        }
        updateBottomBarAppearance()
        updateReferenceSummaryCards()
        updateReferencePlayButton()

        // Keep the new interactive controls above every legacy storyboard view.
        if let header = referenceHeaderOverlay {
            view.bringSubviewToFront(header)
        }
        if let search = referenceSearchOverlay {
            view.bringSubviewToFront(search)
        }
        if let summary = referenceSummaryOverlay {
            view.bringSubviewToFront(summary)
        }
        if let mask = referenceLegacyLineMask {
            view.bringSubviewToFront(mask)
        }
        if let bottom = referenceBottomOverlay {
            view.bringSubviewToFront(bottom)
        }

        // IMPORTANT: do this LAST. When a sheet is open it must be above the
        // dim view AND above the bottom bar, otherwise the bar intercepts taps.
        syncReferenceOverlayVisibility()
    }

    override func viewWillDisappear(_ animated: Bool) {

        deviceDiscoveryTimer?.invalidate()
        deviceDiscoveryTimer = nil

        if (captureSession?.isRunning == true) {
            captureSession.stopRunning()
        }
        super.viewWillDisappear(animated)
    }
  
    
    private var isAnyRFIDConnected: Bool {
        // Bluetooth reader connection
        if bluetoothService?.isConnected() == true {
            return true
        }

        // Zebra: currentReaderID is assigned immediately when the
        // communication session succeeds, while isConnected is updated
        // by the SDK callback shortly afterwards.
        if ZebraRFIDService.shared.isConnected ||
            ZebraRFIDService.shared.currentReaderID != -1 {
            return true
        }

        return false
    }

    private var isZebraRFIDConnected: Bool {
        return ZebraRFIDService.shared.isConnected
    }

    private func updateScannerControls() {
        updateReferencePlayButton()
        let connected = isAnyRFIDConnected
        let running = bluetoothService?.scannerIsRunning == 1 || ZebraRFIDService.shared.isInventoryRunning
        let hasScannedData = (Int(mScannedStocks?.text ?? "0") ?? 0) > 0
        updateReferenceSummaryCards()

        // IMPORTANT:
        // Do not force-unwrap storyboard outlets here.
        // Different Stock Take storyboard versions have different optional
        // outlets. Each control is updated only when that outlet exists.

        // CONNECT
        if let icon = mConnectIcon {
            icon.image = UIImage(named: connected ? "connect_icgreen" : "connect_icgrey")
            icon.contentMode = .scaleAspectFit
        }
        if let label = mConnectLabel {
            label.text = "Connect".localizedString
            label.textColor = UIColor(named: connected ? "themeColor" : "theme6A")
            label.font = UIFont.systemFont(ofSize: 11, weight: .regular)
        }

        // CENTER SCAN BUTTON
        if let icon = mStartIcon {
            if running {
                if #available(iOS 13.0, *) {
                    icon.image = UIImage(systemName: "pause.fill")
                    icon.tintColor = .white
                }
            } else {
                icon.image = UIImage(named: "play_icgreen")
                icon.tintColor = nil
            }
            icon.alpha = connected ? 1.0 : 0.45
            icon.contentMode = .scaleAspectFit
        }

        if let scanView = mStartScannView {
            if running {
                scanView.backgroundColor = UIColor(red: 1.0, green: 0.67, blue: 0.05, alpha: 1.0)
            } else {
                scanView.backgroundColor = UIColor(named: "themeColor")
            }

            let width = scanView.bounds.width
            let height = scanView.bounds.height
            if width > 0 && height > 0 {
                scanView.layer.cornerRadius = min(width, height) / 2
            }
            scanView.clipsToBounds = true
        }

        // STOP while scanning / CLEAR while idle
        if let icon = mRefreshIcon {
            if running {
                if #available(iOS 13.0, *) {
                    icon.image = UIImage(systemName: "stop.fill")
                    icon.tintColor = UIColor.systemRed
                }
            } else {
                icon.image = UIImage(named: "refresh_icgreen")
                icon.tintColor = UIColor(named: "themeColor")
            }
            icon.contentMode = .scaleAspectFit
        }

        if let label = mRefreshLabel {
            label.text = running ? "Stop".localizedString : "Clear".localizedString
            label.textColor = UIColor(named: "theme6A") ?? .secondaryLabel
            label.font = UIFont.systemFont(ofSize: 11, weight: .regular)
        }

        // POWER
        if let icon = mPowerIcon {
            icon.image = UIImage(named: connected ? "power_icgreen" : "power_icgrey")
            icon.contentMode = .scaleAspectFit
        }
        if let label = mPowerLabel {
            label.textColor = UIColor(named: connected ? "themeColor" : "theme6A")
            label.font = UIFont.systemFont(ofSize: 11, weight: .regular)
        }

        // SAVE
        if let icon = mMoreIcon {
            if isSaveInProgress {
                icon.image = UIImage(named: "save_ic")
                icon.alpha = 0.45
            } else if hasScannedData {
                icon.image = UIImage(named: "save_ic")
                icon.alpha = 1.0
            } else {
                icon.image = UIImage(named: "save_icg")
                icon.alpha = 0.45
            }
            icon.contentMode = .scaleAspectFit
            icon.isUserInteractionEnabled = false
        }

        if let label = mMoreLabel {
            label.text = "Save".localizedString
            label.textColor = hasScannedData && !isSaveInProgress
                ? (UIColor(named: "themeColor") ?? .label)
                : (UIColor(named: "theme6A") ?? .secondaryLabel)
            label.font = UIFont.systemFont(ofSize: 11, weight: .regular)
        }
    }

    private func updateReferenceStockTakeUI() {
        view.backgroundColor = UIColor(hex: "#FAFAFA")

        if let bottom = mBottomView {
            bottom.backgroundColor = UIColor(hex: "#FFFFFF")
            bottom.layer.cornerRadius = 0
            bottom.layer.maskedCorners = []
            bottom.layer.shadowColor = UIColor.clear.cgColor
            bottom.layer.shadowOpacity = 0
            bottom.layer.shadowRadius = 0
            bottom.layer.shadowOffset = .zero
        }

        // Search field
        if let search = mSearchStock {
            // The UITextField lives inside the single reference search capsule.
            // Do not give the field its own background/corner radius.
            search.backgroundColor = .clear
            search.layer.cornerRadius = 0
            search.clipsToBounds = false
            search.borderStyle = .none
            search.font = UIFont.systemFont(ofSize: 14, weight: .regular)
            search.textColor = .label
        }

        // Bottom sheet appearance
        [mDeviceView, mPowerView].forEach {
            $0?.backgroundColor = .systemBackground
            $0?.layer.cornerRadius = 16
            $0?.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
            $0?.clipsToBounds = true
        }

        if let table = mDeviceTableView {
            table.backgroundColor = .clear
            table.separatorStyle = .none
        }

        // Default values from the reference.
        if let slider = mPowerSlider {
            slider.minimumValue = 0
            slider.maximumValue = 1
            slider.setValue(0.5, animated: false)
        }
        if let slider = mFrequencySlider {
            slider.minimumValue = 0
            slider.maximumValue = 1
            slider.setValue(0.0, animated: false)
        }
        mPowerValue?.text = "50%"
        mFrequency?.text = "0%"

        updatePowerSheetState()
    }

    private func updateBottomBarAppearance() {
        // Storyboard-safe UI refresh.
        mConnectLabel?.font = UIFont.systemFont(ofSize: 11, weight: .regular)
        mRefreshLabel?.font = UIFont.systemFont(ofSize: 11, weight: .regular)
        mPowerLabel?.font = UIFont.systemFont(ofSize: 11, weight: .regular)
        mMoreLabel?.font = UIFont.systemFont(ofSize: 11, weight: .regular)

        mConnectIcon?.contentMode = .scaleAspectFit
        mRefreshIcon?.contentMode = .scaleAspectFit
        mPowerIcon?.contentMode = .scaleAspectFit
        mMoreIcon?.contentMode = .scaleAspectFit
        mStartIcon?.contentMode = .scaleAspectFit
    }

    private func updateDeviceEmptyState() {
        guard let table = mDeviceTableView else { return }

        // When the reference Device sheet is being used, show the empty state
        // directly inside the sheet. UITableView.backgroundView is unreliable
        // here because the table is moved into a bottom-sheet container.
        if referenceDeviceSheet != nil {
            let empty = referenceDeviceEmptyStateView
            empty?.isHidden = !devices.isEmpty
            table.isHidden = devices.isEmpty
            table.backgroundView = nil
            return
        }

        table.isHidden = false

        if devices.isEmpty {
            if deviceEmptyStateView == nil {
                let container = UIView()
                container.backgroundColor = .clear
                container.translatesAutoresizingMaskIntoConstraints = false

                let imageView = UIImageView(
                    image: UIImage(systemName: "antenna.radiowaves.left.and.right.slash")
                )
                imageView.tintColor = UIColor(hex: "#868686")
                imageView.contentMode = .scaleAspectFit
                imageView.translatesAutoresizingMaskIntoConstraints = false

                let title = UILabel()
                title.text = "Device not found"
                title.font = UIFont.systemFont(ofSize: 15, weight: .semibold)
                title.textColor = UIColor(hex: "#222222")
                title.textAlignment = .center
                title.translatesAutoresizingMaskIntoConstraints = false

                let subtitle = UILabel()
                subtitle.text = "Please check your connection and try again."
                subtitle.font = UIFont.systemFont(ofSize: 13, weight: .regular)
                subtitle.textColor = UIColor(hex: "#868686")
                subtitle.textAlignment = .center
                subtitle.numberOfLines = 2
                subtitle.translatesAutoresizingMaskIntoConstraints = false

                let stack = UIStackView(arrangedSubviews: [imageView, title, subtitle])
                stack.axis = .vertical
                stack.alignment = .center
                stack.spacing = 10
                stack.translatesAutoresizingMaskIntoConstraints = false
                container.addSubview(stack)

                NSLayoutConstraint.activate([
                    imageView.widthAnchor.constraint(equalToConstant: 36),
                    imageView.heightAnchor.constraint(equalToConstant: 36),
                    stack.centerXAnchor.constraint(equalTo: container.centerXAnchor),
                    stack.centerYAnchor.constraint(equalTo: container.centerYAnchor),
                    stack.leadingAnchor.constraint(greaterThanOrEqualTo: container.leadingAnchor, constant: 20),
                    stack.trailingAnchor.constraint(lessThanOrEqualTo: container.trailingAnchor, constant: -20)
                ])

                deviceEmptyStateView = container
            }
            table.backgroundView = deviceEmptyStateView
        } else {
            table.backgroundView = nil
        }
    }

    @objc private func zebraReaderChanged(_ notification: Notification) {
        // IMPORTANT: Zebra raises the reader-available notification immediately
        // after it adds the device internally. At that exact moment
        // ZebraRFIDService.shared.availableReaders can still be empty.
        // The notification object is therefore the first source of truth.
        // Falling back to availableReaders keeps compatibility with the old
        // notification behaviour.
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }

            var discoveredReaders: [srfidReaderInfo] = []

            if let reader = notification.object as? srfidReaderInfo {
                discoveredReaders = [reader]
            } else if let readers = notification.object as? [srfidReaderInfo] {
                discoveredReaders = readers
            } else {
                discoveredReaders = ZebraRFIDService.shared.availableReaders
            }

            // If the notification arrived without a usable object, try the
            // service list once more. This also handles a notification that
            // is posted before the service has finished updating its array.
            if discoveredReaders.isEmpty {
                discoveredReaders = ZebraRFIDService.shared.availableReaders
            }

            print("🦓 Zebra Reader Changed")
            print("🦓 Notification object =", notification.object as Any)
            print("🦓 Readers received =", discoveredReaders.count)

            for reader in discoveredReaders {
                let readerID = reader.getReaderID()
                let serial = reader.getReaderSerialNumber() ?? ""
                print("🦓 Reader = ID:\(readerID), Serial:\(serial)")

                // Keep the local list in sync as well.
                let readerExists = self.readers.contains {
                    $0.getReaderID() == readerID
                }
                if !readerExists {
                    self.readers.append(reader)
                }

                // The Device sheet uses `devices`, not `readers`, as its data
                // source. This is the important part that makes the reader
                // actually appear in the UITableView.
                let deviceExists = self.devices.contains {
                    $0.type == .zebra && $0.zebraReader?.getReaderID() == readerID
                }
                if !deviceExists {
                    self.devices.append(ScanDevice(reader: reader))
                }
            }

            self.updateDeviceEmptyState()
            self.mDeviceTableView.reloadData()
            self.syncReferenceOverlayVisibility()
        }
    }

    @objc private func zebraConnectionChanged(_ notification: Notification) {
        DispatchQueue.main.async {
            if ZebraRFIDService.shared.isConnected {
                self.pendingZebraReaderID = nil
                self.mDeviceView.isHidden = true
            }
            self.updateScannerControls()
            self.updatePowerSheetState()
            self.updateDeviceEmptyState()
            self.mDeviceTableView.reloadData()
        }
    }

    @objc private func zebraInventoryChanged(_ notification: Notification) {
        DispatchQueue.main.async {
            self.updateScannerControls()
        }
    }

    @objc
    func tagRead(_ notification: Notification) {

        guard let value = notification.object as? String else { return }

        let tag = value
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .uppercased()

        guard !tag.isEmpty else { return }

        let now = Date()
        if let lastRead = recentRFIDReads[tag],
           now.timeIntervalSince(lastRead) < rfidReadDebounceInterval {
            print("↩️ Ignore duplicate Zebra RFID =", tag)
            return
        }
        recentRFIDReads[tag] = now

        if recentRFIDReads.count > 500 {
            let cutoff = now.addingTimeInterval(-rfidReadDebounceInterval)
            recentRFIDReads = recentRFIDReads.filter { $0.value >= cutoff }
        }

        print("📡 ZEBRA RFID READ =", tag)

        DispatchQueue.main.async {
            self.mSearchStock.text = tag

            // A tag that has already been counted in this Stock Take must not
            // become a Conflict simply because Zebra keeps seeing it.
            if let item = self.stockMap[tag] {
                let stockID = "\(item["stock_id"] ?? "")"
                if !stockID.isEmpty && self.mScannedData.contains(stockID) {
                    print("↩️ Ignore already scanned Zebra stock =", stockID)
                    return
                }
            }

            self.getRFIDData(data: tag)
        }
    }
    
//    @objc
//    func tagRead(_ notification: Notification) {
//
//        guard let epc = notification.object as? String else {
//            return
//        }
//
//
//        let searchKey: String
//
//        if let decoded = ZebraRFIDService.shared.decodeFromHex(epc),
//           decoded.range(of: #"^\d{1,12}$"#, options: .regularExpression) != nil {
//            print("New RFID Format")
//            searchKey = decoded
//        } else {
//            print("Old RFID Format")
//            searchKey = epc
//        }
////        if let decoded = ZebraRFIDService.shared.decodeFromHex(epc) {
////
////            print("New RFID Format")
////            searchKey = decoded
////
////        } else {
////
////            print("Old RFID Format")
////            searchKey = epc
////        }
//
//        print("RAW =RAW =", epc)
//        print("SEARCH =", searchKey)
//
//        DispatchQueue.main.async {
//
//            self.mSearchStock.text = searchKey
//            self.getRFIDData(data: searchKey)
//
//        }
////        mSearchStock?.text = searchKey
////
////        getRFIDData(data: searchKey)
//    }
    
    @objc
    func barcodeRead(_ notification: Notification) {

        guard let code = notification.object as? String else {
            return
        }

        print("Received Barcode =", code)

        mSearchStock?.text = code

        getRFIDData(data: code)
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
//    @objc func scannerRead(_ noti: Notification) {
//
//        guard let result = noti.object as? ScanResult else {
//            return
//        }
//
//        switch result.type {
//
//        case .rfid:
//            print("RFID =", result.value)
//
//        case .barcode:
//            print("Barcode =", result.value)
//        }
//
//        callAPI(result.value)
//    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        _ = ZebraRFIDService.shared
        
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(tagRead(_:)),
            name: .zebraTagRead,
            object: nil
        )
        
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(barcodeRead(_:)),
            name: .zebraBarcodeRead,
            object: nil
        )

        NotificationCenter.default.addObserver(
            self,
            selector: #selector(zebraConnectionChanged(_:)),
            name: .zebraConnectionChanged,
            object: nil
        )

        NotificationCenter.default.addObserver(
            self,
            selector: #selector(zebraInventoryChanged(_:)),
            name: .zebraInventoryChanged,
            object: nil
        )

        NotificationCenter.default.addObserver(
            self,
            selector: #selector(zebraReaderChanged(_:)),
            name: .zebraReaderChanged,
            object: nil
        )
        
        
        // Retrieve user login token from UserDefaults
        mUserLoginToken = UserDefaults.standard.string(forKey: "token")
        mUserLoginTokenPos = UserDefaults.standard.string(forKey: "token_pos")

        // Configure filter subview
        mFilterSubView.layer.cornerRadius = 20
        mFilterSubView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]

        // Initialize Bluetooth service
        bluetoothService = BluetoothLeService(main: self)

        // Set delegates and data sources for collection views
        mItemCollectionView.delegate = self
        mItemCollectionView.dataSource = self
        mCollectCollectionView.delegate = self
        mCollectCollectionView.dataSource = self
        mMetalCollectionView.delegate = self
        mMetalCollectionView.dataSource = self
        mLocationCollectionView.delegate = self
        mLocationCollectionView.dataSource = self

        // Set initial stock counts
        mScannedStocks.text = "0"
        mUnscannedStocks.text = "0"
        mConflictStocks.text = "0"
        mTotalStocks.text = "0"
        mUnknownStocks.text = "0"
       if let gif = try? UIImage(gifName: "scanner.gif") {
            mScannerImage.setGifImage(gif)
        } else {
            print("⚠️ ไม่พบไฟล์ scanner.gif")
        }


        //mScannerImage.image = UIImage.gif(asset: "scanner")

        // Add tap gesture to dismiss keyboard
        let tap = UITapGestureRecognizer(target: self.view, action: #selector(UIView.endEditing))
        view.addGestureRecognizer(tap)
        tap.cancelsTouchesInView = false

        // Configure bottom view
        mBottomView.layer.cornerRadius = 0
        mBottomView.layer.maskedCorners = []
        mBottomView.dropShadow()

        // Apply the reference Stock Take appearance only after storyboard
        // outlets are guaranteed to exist.
        updateReferenceStockTakeUI()

        // Configure search device view
        mSearchDeviceView.layer.cornerRadius = 10
        mSearchDeviceView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]

        // Configure power view
        mPowerView.layer.cornerRadius = 10
        mPowerView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]

        // Configure apply filter view
        mApplyFilterView.layer.cornerRadius = 10
        mApplyFilterView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        mApplyFilterView.dropShadow()

        // Set delegates and data sources for device table view
        self.mDeviceTableView.delegate = self
        self.mDeviceTableView.dataSource = self
        self.mDeviceTableView.separatorStyle = .none
        self.mDeviceTableView.backgroundColor = .clear
        self.updateDeviceEmptyState()

        // Fetch inventory data
        self.mGetInventoryDataStock(key: "")

        // Add done button to keyboard
        addDoneButtonOnKeyboard()
        print("Siri ID: \(SiriID)")
        self.mSearchStock.text = SiriID

        // Hide the legacy storyboard bottom bar before building the reference UI.
        // This prevents the old Connect/Clear/Play/Power/Save row from appearing underneath.
        mBottomView?.isHidden = true

        // Build the reference Stock Take UI over the legacy storyboard cards.
        buildReferenceStockTakeOverlay()
        updateReferenceSummaryCards()
    }
    
    
    func mGetInventoryFilterData(itemsId: [String], metalId: [String], collectionId: [String], stoneId: [String], sizeId: [String], locationId: [String], statusId: [String], minPrice: String, maxPrice: String) {
        
        mItemsId = itemsId
        mMetalsId = metalId
        mCollectionId = collectionId
        mStonesId = stoneId
        mSizeId = sizeId
        mStatusId = statusId
        mLocationsId = locationId
        mMinPrices = minPrice
        mMaxPrices = maxPrice
        
        mGetInventoryDataStock(key: "")
    }
    
    //Mic Button
    @IBAction func sSpeakStockIdOrSku(_ sender: Any) {
        
        if !isSpeechRecongnitionOn {
            self.isSpeechRecongnitionOn = true
            self.sMicImageView.image = UIImage(systemName: "mic.slash.fill")
            speechRecongniger.startRecognition { value in
                
                DispatchQueue.main.async {
                    self.isSpeechRecongnitionOn = false
                    self.sMicImageView.image = UIImage(systemName: "mic.fill")
                    if let text = value , !text.isEmpty{
                        self.mSearchStock.text = text
                        self.mSearchStock.becomeFirstResponder()
                    }
                }
            }
            
        } else {
            self.sMicImageView.image = UIImage(systemName: "mic.fill")
            self.isSpeechRecongnitionOn = false
            speechRecongniger.stopRecognition()
        }

    }

    @IBAction func mFrequencySliding(_ sender: UISlider) {
        let percent = Int((sender.value * 100).rounded())
        sender.setValue(Float(percent) / 100.0, animated: false)
        mFrequency.text = "\(percent)%"

        // Frequency here is the legacy reader duty-cycle control.
        // Zebra RFID uses its own RF/link-profile configuration and does not
        // expose the same on/off duty-cycle API, so keep this control UI-only
        // for Zebra until the product confirms the required Zebra mapping.
        guard !isZebraRFIDConnected else { return }

        let on = Int(Double(percent) * 2.0)
        let off = 200 - on
        bluetoothService?.sendSettingTxCycle(on: on, off: off)
    }

    @IBAction func mPowerSliding(_ sender: UISlider) {
        let percent = Int((sender.value * 100).rounded())
        sender.setValue(Float(percent) / 100.0, animated: false)
        mPowerValue.text = "\(percent)%"

        if isZebraRFIDConnected {
            ZebraRFIDService.shared.setPowerPercent(percent)
            return
        }

        // Legacy reader power is represented as attenuation from max power.
        let attenuation = min(9, max(0, Int((100 - percent) / 10)))
        let power = attenuation == 0 ? 0 : -attenuation
        bluetoothService?.sendSettingTxPower(power: power)
    }

    
    @IBAction func mFilter(_ sender: Any) {
        
        view.endEditing(true)
        let storyBoard: UIStoryboard = UIStoryboard(name: "common", bundle: nil)
        guard let mFilters = storyBoard.instantiateViewController(withIdentifier: "CommonFilters") as? CommonFilters else { return }
        mFilters.delegate = self
        mFilters.mType = "inventory"
        mFilters.hideLocation = true
        mFilters.mItemsId = mItemsId
        mFilters.mMetalsId = mMetalsId
        mFilters.mCollectionId = mCollectionId
        mFilters.mStonesId = mStonesId
        mFilters.mSizeId = mSizeId
        mFilters.mLocationsId = mStatusId
        mFilters.mStatusId = mLocationsId
        mFilters.mMinPrices = mMinPrices
        mFilters.mMaxPrices = mMaxPrices
        mFilters.modalPresentationStyle = .automatic
        mFilters.transitioningDelegate = self
        self.present(mFilters,animated: true)
    }
    
    
    
    @IBAction func mMinimizeFilter(_ sender: Any) {
        mFilterView.slideTop()
        mFilterView.isHidden = true
    }
    
    @IBAction func mApplyFilter(_ sender: Any) {
        let defaultZero = "0"
        self.mScannedStocks.text = defaultZero
        self.mUnscannedStocks.text = defaultZero
        self.mConflictStocks.text = defaultZero
        self.mUnknownStocks.text = defaultZero
        
        self.mScannedData = []
        self.mScannedSKU = []
        self.mScannedCount = []
        self.mUnscannedData = []
        self.mConflictData = []
        self.mInventoryData = NSArray()
        self.mStatusData = NSMutableArray()
        self.mSCANNED = NSMutableArray()
        self.mUNSCANNED = NSMutableArray()
        self.mSAVESCANNED = NSMutableArray()
        self.mSAVEUNSCANNED = NSMutableArray()
        self.mCONFLICT = []
        self.FINALCONFLICT = []
        
        mGetInventoryDataStock(key: "")
        mFilterView.slideTop()
        mFilterView.isHidden = true
    }
    
    func connect(_ peripheral: CBPeripheral) {
     
        if bluetoothService?.isConnected() == true {
            if bluetoothService?.peripheral == peripheral {
                bluetoothService?.byeBluetoothDevice()
                self.mConnectIcon.image = UIImage(named: "connect_icgrey")
                self.mConnectLabel.textColor = UIColor(named: "theme6A")
                
                CommonClass.showFullLoader(view: self.view)
                DispatchQueue.main.asyncAfter(deadline: .now() + 3, execute: {
                    CommonClass.stopLoader()
                    if let cbPeripheral = self.bluetoothService?.peripheral {
                        self.centralManager?.cancelPeripheralConnection(cbPeripheral)
                        self.mDeviceTableView.reloadData()
                    }
                })
                
                return
            } else {
                
                self.mConnectIcon.image = UIImage(named: "connect_icgrey")
                self.mConnectLabel.textColor = UIColor(named: "theme6A")
                bluetoothService?.byeBluetoothDevice()
                CommonClass.showFullLoader(view: self.view)
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 2, execute: {
                    
                    CommonClass.stopLoader()
                    
                    if let cbPeripheral = self.bluetoothService?.peripheral {
                        self.centralManager?.cancelPeripheralConnection(cbPeripheral)
                    }
                })
                DispatchQueue.main.asyncAfter(deadline: .now() + 3, execute: {
                    self.bluetoothService?.peripheral = peripheral
                    peripheral.delegate = self
                    self.centralManager?.connect(peripheral)
                    CommonClass.showFullLoader(view: self.view)
                    DispatchQueue.main.asyncAfter(deadline: .now() + 6, execute: {
                        CommonClass.stopLoader()
                        self.mConnectIcon.image = UIImage(named: "connect_icgreen")
                        self.mConnectLabel.textColor =  UIColor(named: "themeColor")
                        self.mDeviceView.isHidden = true
                        
                    })
                })
                self.mDeviceTableView.reloadData()
                
            }
            
            self.mDeviceTableView.reloadData()
            
        } else {
            bluetoothService?.peripheral = peripheral
            peripheral.delegate = self
            centralManager?.connect(peripheral)
            CommonClass.showFullLoader(view: self.view)
            DispatchQueue.main.asyncAfter(deadline: .now() + 3, execute: {
                self.mDeviceView.isHidden = true
                self.mConnectIcon.image = UIImage(named: "connect_icgreen")
                self.mConnectLabel.textColor =  UIColor(named: "themeColor")
                CommonClass.stopLoader()
                
            })
        }
        self.mDeviceTableView.reloadData()
    }
    
    func search() {
        arrPeripheral.removeAll()

        // Keep an already connected Bluetooth reader in the list.
        if let peripheral = bluetoothService?.peripheral {
            if !arrPeripheral.contains(peripheral) {
                arrPeripheral.append(peripheral)
            }

            let exists = devices.contains { device in
                device.type == .bluetooth && device.peripheral == peripheral
            }

            if !exists {
                devices.append(ScanDevice(peripheral: peripheral))
            }
        }

        if centralManager == nil {
            centralManager = CBCentralManager(delegate: self, queue: nil)
        }

        // IMPORTANT:
        // CBCentralManager(delegate:) does not guarantee that
        // centralManagerDidUpdateState() will be called again when the
        // manager is already powered on. If it is already poweredOn, start
        // scanning here immediately. This was the reason Connect could open
        // the sheet but never show discovered Bluetooth devices.
        if centralManager?.state == .poweredOn {
            startBluetoothDiscovery()
        }

        updateDeviceEmptyState()
        mDeviceTableView.reloadData()
    }

    private func startBluetoothDiscovery() {
        guard let central = centralManager, central.state == .poweredOn else {
            return
        }

        if central.isScanning {
            central.stopScan()
        }

        let services = [
            bluetoothService?.R5000_SERVICE,
            bluetoothService?.R800_3000_SERVICE
        ].compactMap { $0 }

        // First recover readers that are already connected to iOS.
        if !services.isEmpty {
            let connected = central.retrieveConnectedPeripherals(withServices: services)
            for peripheral in connected {
                addPeripheral(peripheral: peripheral)
            }
        }

        // Then scan for new readers. Do not restrict the service UUID here;
        // addPeripheral() performs the existing supported-reader name filter.
        central.scanForPeripherals(
            withServices: nil,
            options: [CBCentralManagerScanOptionAllowDuplicatesKey: false]
        )

        mScanNowLabel?.text = "Scanning".localizedString

        DispatchQueue.main.asyncAfter(deadline: .now() + ScanPeriod) { [weak self] in
            guard let self = self else { return }
            self.mScanNowLabel?.text = "Scan now".localizedString
            self.centralManager?.stopScan()
            self.mDeviceTableView?.reloadData()
        }
    }
    
    
    func stopScan() {
        if centralManager?.isScanning ?? false {
            centralManager?.stopScan()
        }
        mDeviceTableView.reloadData()
    }
    
    func startScanner() {
        if bluetoothService?.isConnected() ?? false {
            bluetoothService?.sendCmdScannerScanStart()
            bluetoothService?.scannerIsRunning = 2

        }
    }
    func stopScanner() {
        if bluetoothService?.isConnected() ?? false {
            bluetoothService?.sendCmdScannerScanStop()
            bluetoothService?.scannerIsRunning = 0

        }
    }
    
    func startRFID() {
        if bluetoothService?.isConnected() ?? false {
            bluetoothService?.sendCmdInventory(f_s: 0, f_m: 0, to: 0)
            bluetoothService?.scannerIsRunning = 1

        }
    }
    func stopRFID() {
        
        if bluetoothService?.isConnected() ?? false {
            bluetoothService?.sendCmdStop()
            bluetoothService?.scannerIsRunning = 0

        }
    }
    
    var arrMSG : [String] = []
    func completeConnect() {
        arrMSG.removeAll()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5, execute: {
            self.bluetoothService?.packetClear()
            self.arrMSG.removeAll()
            self.arrMSG.append("MSG_OPEN_INTERFACE1")
            self.arrMSG.append("MSG_GET_FW_VERSION")
            self.arrMSG.append("MSG_GET_SCANNER_TYPE")
            self.arrMSG.append("MSG_SET_DEFAULT")
            self.arrMSG.append("MSG_SET_TAGFOCUS")
            self.bluetoothService?.sendCmdOpenInterface1()
        })
        
       
    }
    
    
    func receiveData() {
        var msg = bluetoothService?.popPacket()
        
        var sentMsg = ""
        while msg != nil {
            sentMsg = ""
            if arrMSG.count > 0 {
                sentMsg = arrMSG[0]

                if msg?.contains(find: "$>") == true {
                    arrMSG.removeFirst()
                    
                    sendNextMsg()
                }
            }
            switch sentMsg {
            case "MSG_GET_SCANNER_TYPE":
                if let msg = msg, msg.starts(with: "ok,"),
                   let scannerType = Int(msg.substring(from: 3)) {
                    bluetoothService?.scannerType = scannerType
                }
                break
            case "MSG_GET_FW_VERSION":
                if let msg = msg, msg.starts(with: "ok,") {
                    bluetoothService?.firmwareVer = msg.substring(from: 3)
                }
                break
            case "MSG":
                break
            default:
                break
            }
            if let msg = msg {
                if msg.starts(with: "^") ||
                    msg.starts(with: "$") ||
                    msg.starts(with: "ok") ||
                    msg.starts(with: "err") ||
                    msg.starts(with: "end") ||
                    msg.starts(with: ",") ||
                    msg.contains(find: ",e="){
                    if msg.starts(with: "err_scan=") { //no scanner
                        bluetoothService?.scannerType = 0
                    }
                    else if msg.starts(with: "ok,ver=") { // firmwareVersion
                        bluetoothService?.firmwareVer = msg.split(usingRegex: "=")[1]
                    }
                    else if msg.starts(with: "err_tag=") || msg.starts(with: "err_op=") { // read/write acc error
              
                    }
                    else if msg.starts(with: "ok,e=") { // write success

                    }
                    else if msg.contains(",e=") { // read success

                    }
                    else if msg.starts(with: "end=0,w") {

                    }
                    else if msg.starts(with: "ok,") {
                        
                    }
                    else if msg.starts(with: "$trigger=") {
                        if msg.starts(with: "$trigger=0") {
                            
                            bluetoothService?.scannerIsRunning = 0
                            stopRFID()
                            
                        } else if msg.starts(with: "$trigger=1") {
                            
                            bluetoothService?.scannerIsRunning = 1
                            startRFID()
                            
                        } else if msg.starts(with: "$trigger=2") {
                            bluetoothService?.scannerIsRunning = 0
                            stopScanner()
                        } else if msg.starts(with: "$trigger=3") {
                            bluetoothService?.scannerIsRunning = 2
                            startScanner()
                        }
                    }
                    else if msg.starts(with: "$online=0") || msg.starts(with: "$pwr=0") {
                        
                    }
                    else if msg.starts(with: "end") {
                        if msg.contains(find: "sc.start") {
                        } else if msg.contains(find: ",i") {
                      
                        }
                    }
                    else if msg.starts(with: "err") {
                        
                    }
                    else if msg.starts(with: "^") {
                        
                    }
                } else if bluetoothService?.scannerIsRunning != 0 { // rfid, barcode data
                    if  bluetoothService?.scannerIsRunning == 1 {

                        addData(msg)
                        
                    } else if bluetoothService?.scannerIsRunning == 2 {
                        
                        addDataScanner(msg)
                        
                    }
                }
            }
            msg = bluetoothService?.popPacket()
        }
    }
    
    func addData(_ data: String) {
        var time = "", rssi = "", bctype = ""
        var data = data
        if data.contains(find: ",t=") {
            time = data.split(usingRegex: ",")[1]
            if time.contains(find: ",s=") {
                time = time.split(usingRegex: ",")[0]
            }
            time = time.replace(target: "t=", withString: "")
            if data.contains(find: ",s=") {
                rssi = data.split(usingRegex: ",")[2].replace(target: "s=", withString: "")
            }
            data = data.split(usingRegex: ",")[0]
        } else if data.contains(find: ",s=") {
            rssi = data.split(usingRegex: ",")[1].replace(target: "s=", withString: "")
            data = data.split(usingRegex: ",")[0]
        } else if data.contains(find: ",z=") { // barcode
            return
        }
        
        if data.isEmpty {
            return
        }
        getRFIDData(data: data.hexToString())
        
    }
   
    func addDataScanner(_ data: String) {
        var time = "", rssi = "", bctype = ""
        var data = data
        if data.contains(find: ",t=") {
            time = data.split(usingRegex: ",")[1]
            if time.contains(find: ",s=") {
                time = time.split(usingRegex: ",")[0]
            }
            time = time.replace(target: "t=", withString: "")
            if data.contains(find: ",s=") {
                rssi = data.split(usingRegex: ",")[2].replace(target: "s=", withString: "")
            }
            data = data.split(usingRegex: ",")[0]
        } else if data.contains(find: ",s=") {
            rssi = data.split(usingRegex: ",")[1].replace(target: "s=", withString: "")
            data = data.split(usingRegex: ",")[0]
        } else if data.contains(find: ",z=") {
            bctype = data.split(usingRegex: ",")[1].replace(target: "z=", withString: "")
            data = data.split(usingRegex: ",")[0]
            if data.isEmpty {
                return
            }
        }
     
        getRFIDData(data: data)
        
    }
    func sendNextMsg() {
        let msg = arrMSG.count > 0 ? arrMSG[0] : ""
        switch msg {
        case "MSG_GET_FW_VERSION":
            bluetoothService?.sendGetVersion()
            break
        case "MSG_GET_SCANNER_TYPE":
            bluetoothService?.sendGetScannerType()
            break
        case "MSG_SET_DEFAULT":
            bluetoothService?.sendSetDefaultParameter()
            break
        case "MSG_SET_POWER":
            bluetoothService?.sendSettingTxPower(power: 0)
            break
        case "MSG_SET_TX_CYCLE":
            bluetoothService?.sendSettingTxCycle(on: 40, off: 140)
            break
        case "MSG_SET_INVENTORY_PARAM":
            bluetoothService?.sendInventoryParam(session: 1, q: 5, m_ab: 0)
            break
        case "MSG_SET_TAGFOCUS":
            bluetoothService?.sendCmdRfidTagFocus(enable: 0)
            break
        default:
            break
        }
    }
    
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        switch central.state {
        case .unsupported:
            self.centralManager = nil
            self.bluetoothService?.peripheral = nil
            break
        case .unauthorized:
            self.centralManager = nil
            self.bluetoothService?.peripheral = nil
            break
        case .poweredOff:
            self.centralManager = nil
            self.bluetoothService?.peripheral = nil
            break
        case .poweredOn:
            // Start discovery as soon as CoreBluetooth reports poweredOn.
            // This also covers the first Connect tap, when CBCentralManager
            // was created moments earlier.
            startBluetoothDiscovery()
            break
        default:
            self.centralManager = nil
            self.bluetoothService?.peripheral = nil
            break
        }
    }
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {
        addPeripheral(peripheral: peripheral)
    }
    func addPeripheral(peripheral: CBPeripheral) {
        var isContain = false
        arrPeripheral.map { it in
            if it == peripheral {
                isContain = true
            }
        }
        
        if let name = peripheral.name, !isContain, let service = bluetoothService {
            if name.starts(with: service.HQ_UHF_READER) ||
                name.starts(with: service.TSS900_UHF_READER) ||
                name.starts(with: service.DOTR900_UHF_READER) ||
                name.starts(with: service.DOTR800_UHF_READER) ||
                name.starts(with: service.G2W_UHF_READER) ||
                name.starts(with: service.TSS2000_UHF_READER) ||
                name.starts(with: service.DOT2000_UHF_READER) ||
                name.starts(with: service.DOTR3000_UHF_READER) ||
                name.starts(with: service.TSS3000_UHF_READER) ||
                name.starts(with: service.RF800_UHF_READER) ||
                name.starts(with: service.DOTR5000_UHF_READER) {
                arrPeripheral.append(peripheral)
                devices.append(ScanDevice(peripheral: peripheral))
                updateDeviceEmptyState()
                mDeviceTableView.reloadData()
            }
        }
    }

    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        central.stopScan()
     
        if peripheral == self.bluetoothService?.peripheral {
            prevPeripheral = peripheral
            self.bluetoothService?.reset()
            peripheral.discoverServices([self.bluetoothService?.R5000_SERVICE, self.bluetoothService?.R800_3000_SERVICE, self.bluetoothService?.R800_3000_TSERVICE].compactMap { $0 })
        }
    }

    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        if peripheral == self.bluetoothService?.peripheral {
            self.bluetoothService?.peripheral = nil
        }
    }
    
    
    // Handles discovery event
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        if let services = peripheral.services,
           let bluetoothService = self.bluetoothService,
           peripheral == self.bluetoothService?.peripheral {
            
            if let r5000Service = services.first(where: { $0.uuid == bluetoothService.R5000_SERVICE }) {

                peripheral.discoverCharacteristics([bluetoothService.R5000_RX, bluetoothService.R5000_TX], for: r5000Service)
                
            } else {
                for service in services {

                    if service.uuid == bluetoothService.R5000_SERVICE ||
                        service.uuid == bluetoothService.R800_3000_SERVICE ||
                        service.uuid == bluetoothService.R800_3000_TSERVICE {

                        //Now kick off discovery of characteristics
                        peripheral.discoverCharacteristics(nil, for: service)
                        
                    }
                }
            }
        }
    }

    // Handling discovery of characteristics
    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        
        if let characteristics = service.characteristics, peripheral == self.bluetoothService?.peripheral {
            for characteristic in characteristics {
               
                completeConnect()
                
                if characteristic.properties.contains(.notify) {
                  
                    self.bluetoothService?.readCharacteristic = characteristic
                    peripheral.setNotifyValue(true, for: characteristic)
                    if bluetoothService?.writeCharacteristic != nil {
                        completeConnect()
                    }
                } else {
                    self.bluetoothService?.readCharacteristic = nil
                }
                
                if (characteristic.uuid == self.bluetoothService?.R5000_TX && service.uuid == self.bluetoothService?.R5000_SERVICE) || (characteristic.uuid == self.bluetoothService?.R800_3000_TX && service.uuid == self.bluetoothService?.R800_3000_TSERVICE) {
                    if characteristic.properties.contains(.notify) {
                        
                        self.bluetoothService?.readCharacteristic = characteristic
                        peripheral.setNotifyValue(true, for: characteristic)
                        if bluetoothService?.writeCharacteristic != nil {
                            completeConnect()
                        }
                    } else {
                        self.bluetoothService?.readCharacteristic = nil
                    }
                } else if (characteristic.uuid == self.bluetoothService?.R5000_RX && service.uuid == self.bluetoothService?.R5000_SERVICE) || (characteristic.uuid == self.bluetoothService?.R800_3000_RX && service.uuid == self.bluetoothService?.R800_3000_SERVICE) {
                    if characteristic.properties.contains(.write) ||  characteristic.properties.contains(.writeWithoutResponse) {
                       
                        self.bluetoothService?.writeCharacteristic = characteristic
                        if bluetoothService?.readCharacteristic != nil {
                            completeConnect()
                        }
                    } else {
                        self.bluetoothService?.writeCharacteristic = nil
                    }
                    
                }
            }
            
        }
    }
    func peripheral(_ peripheral: CBPeripheral, didWriteValueFor characteristic: CBCharacteristic, error: Error?) {
        print("Error Writing... \(error?.localizedDescription ?? "")")
    }
    func peripheral(_ peripheral: CBPeripheral, didWriteValueFor descriptor: CBDescriptor, error: Error?) {
        print("Error Writing : \(error?.localizedDescription ?? "")")
    }
    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        if let val = characteristic.value, let str = String(data: val, encoding: .utf8) {

        }
        
        switch characteristic.uuid {
        case self.bluetoothService?.R5000_TX:
            if characteristic.service?.uuid == self.bluetoothService?.R5000_SERVICE {
                self.bluetoothService?.pushPacket(data: characteristic.value)
            }
            break
        case self.bluetoothService?.R800_3000_TX2:
            
            if characteristic.service?.uuid == self.bluetoothService?.R800_3000_TSERVICE {
                self.bluetoothService?.pushPacket(data: characteristic.value)
                
            }
            break
        default:
            print("didUpdateValues: " + characteristic.uuid.uuidString + characteristic.description)
        }
        
    }
    func peripheral(_ peripheral: CBPeripheral, didUpdateNotificationStateFor characteristic: CBCharacteristic, error: Error?) {
        if let val = characteristic.value, let str = String(data: val, encoding: .utf8) {

        }
        switch characteristic.uuid {
        case self.bluetoothService?.R5000_TX:
            if characteristic.service?.uuid == self.bluetoothService?.R5000_SERVICE {
                self.bluetoothService?.pushPacket(data: characteristic.value)
            }
            break
        case self.bluetoothService?.R800_3000_TX:
            if characteristic.service?.uuid == self.bluetoothService?.R800_3000_TSERVICE {
                self.bluetoothService?.pushPacket(data: characteristic.value)
            }
            break
        default:
            print("didUpdateNotificationStateFor: " + characteristic.uuid.uuidString + characteristic.description)
        }
    }
    
    
    
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        var count = 0
        if collectionView == self.mItemCollectionView {
            count = mItemsData.count
            
        }else if collectionView == self.mCollectCollectionView {
            count = mCollectionData.count
            
            
        }else if collectionView == self.mMetalCollectionView {
            count = mMetalsData.count
            
        }else if collectionView == self.mLocationCollectionView {
            count = mLocationsData.count
        }
        
        return count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        var cell = UICollectionViewCell()
        if collectionView == self.mItemCollectionView {
            guard let cells = collectionView.dequeueReusableCell(withReuseIdentifier: "ItemCell", for: indexPath) as? ItemCell else {
                return UICollectionViewCell()
            }
            
            if let mData = mItemsData[indexPath.row] as? NSDictionary {
                
                cells.mItemName.text = mData.value(forKey: "name") as? String
                if let mItemsDataId = mData.value(forKey: "_id") as? String {
                    cells.mItemName.backgroundColor = mItemsId.contains(mItemsDataId) ? #colorLiteral(red: 0.3607843137, green: 0.7803921569, blue: 0.7568627451, alpha: 1) : #colorLiteral(red: 0.8078431373, green: 0.9333333333, blue: 0.9254901961, alpha: 1)
                    cells.backgroundColor = mItemsId.contains(mItemsDataId) ? #colorLiteral(red: 0.3607843137, green: 0.7803921569, blue: 0.7568627451, alpha: 1) : #colorLiteral(red: 0.8078431373, green: 0.9333333333, blue: 0.9254901961, alpha: 1)
                }
            }
            cells.layoutSubviews()
            cell = cells
        } else if collectionView == self.mCollectCollectionView {
            
            guard let cells = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionCell", for: indexPath) as? CollectionCell else {
                return UICollectionViewCell()
            }
            
            if let mData = mCollectionData[indexPath.row] as? NSDictionary {
                
                cells.mCollectionName.text = mData.value(forKey: "name") as? String
                if let mCollectionDataId = mData.value(forKey: "_id") as? String {
                    cells.mCollectionName.backgroundColor = mCollectionId.contains(mCollectionDataId) ? #colorLiteral(red: 0.3607843137, green: 0.7803921569, blue: 0.7568627451, alpha: 1) : #colorLiteral(red: 0.8078431373, green: 0.9333333333, blue: 0.9254901961, alpha: 1)
                    cells.backgroundColor = mCollectionId.contains(mCollectionDataId) ? #colorLiteral(red: 0.3607843137, green: 0.7803921569, blue: 0.7568627451, alpha: 1) : #colorLiteral(red: 0.8078431373, green: 0.9333333333, blue: 0.9254901961, alpha: 1)
                }
            
            }
            cells.layoutSubviews()
            cell = cells
            
        } else if collectionView == self.mMetalCollectionView {
            guard let cells = collectionView.dequeueReusableCell(withReuseIdentifier: "MetalCell", for: indexPath) as? MetalCell else {
                return UICollectionViewCell()
            }
            
            if let mData = mMetalsData[indexPath.row] as? NSDictionary {
                cells.mMetalName.text = mData.value(forKey: "name") as? String
                if let mMetalsDataId = mData.value(forKey: "_id") as? String {
                    cells.mMetalName.backgroundColor = mMetalsId.contains(mMetalsDataId) ? #colorLiteral(red: 0.3607843137, green: 0.7803921569, blue: 0.7568627451, alpha: 1) : #colorLiteral(red: 0.8078431373, green: 0.9333333333, blue: 0.9254901961, alpha: 1)
                    cells.backgroundColor = mMetalsId.contains(mMetalsDataId) ? #colorLiteral(red: 0.3607843137, green: 0.7803921569, blue: 0.7568627451, alpha: 1) : #colorLiteral(red: 0.8078431373, green: 0.9333333333, blue: 0.9254901961, alpha: 1)
                }
                
            }
            cells.layoutSubviews()
            cell = cells
            
        } else if collectionView == self.mLocationCollectionView {
            guard let cells = collectionView.dequeueReusableCell(withReuseIdentifier: "LocationCell", for: indexPath) as? LocationCell else {
                return UICollectionViewCell()
            }
            
            if let mData = mLocationsData[indexPath.row] as? NSDictionary {
                cells.mLocationName.text = mData.value(forKey: "name") as? String
                
                if let mLocationDataId = mData.value(forKey: "_id") as? String {
                    cells.mLocationName.backgroundColor = mLocationsId.contains(mLocationDataId) ? #colorLiteral(red: 0.3607843137, green: 0.7803921569, blue: 0.7568627451, alpha: 1) : #colorLiteral(red: 0.8078431373, green: 0.9333333333, blue: 0.9254901961, alpha: 1)
                    cells.backgroundColor = mLocationsId.contains(mLocationDataId) ? #colorLiteral(red: 0.3607843137, green: 0.7803921569, blue: 0.7568627451, alpha: 1) : #colorLiteral(red: 0.8078431373, green: 0.9333333333, blue: 0.9254901961, alpha: 1)
                }
               
            }
            cells.layoutSubviews()
            cell = cells
            
        }
        
        return cell
    }
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if collectionView == self.mLocationCollectionView {
            
            if let mData = mLocationsData[indexPath.row] as? NSDictionary {
                if let mLocationsDataId = mData.value(forKey: "id") as? String {
                    if mLocationsId.contains(mLocationsDataId) {
                        mLocationsId = mLocationsId.filter {$0 != mLocationsDataId }
                    }else{
                        mLocationsId.append(mLocationsDataId)
                    }
                }
                
            }
            self.mLocationCollectionView.reloadData()
            
        }
        
        if collectionView == self.mMetalCollectionView {
            
            if let mData = mMetalsData[indexPath.row] as? NSDictionary {
                if let mMetalsDataId = mData.value(forKey: "id") as? String {
                    if mMetalsId.contains(mMetalsDataId) {
                        mMetalsId = mMetalsId.filter {$0 != mMetalsDataId }
                    }else{
                        mMetalsId.append(mMetalsDataId)
                    }
                }
            }
            self.mMetalCollectionView.reloadData()
            
        }
        
        if collectionView == self.mItemCollectionView {
            
            if let mData = mItemsData[indexPath.row] as? NSDictionary {
                if let mItemsDataId = mData.value(forKey: "id") as? String {
                    if mItemsId.contains(mItemsDataId) {
                        mItemsId = mItemsId.filter {$0 != mItemsDataId }
                    }else{
                        mItemsId.append(mItemsDataId)
                    }
                }
            }
            self.mItemCollectionView.reloadData()
            
        }
        if collectionView == self.mCollectCollectionView {
            
            if let mData = mCollectionData[indexPath.row] as? NSDictionary {
                if let mCollectionDataId = mData.value(forKey: "id") as? String {
                    if mCollectionId.contains(mCollectionDataId) {
                        mCollectionId = mCollectionId.filter {$0 != mCollectionDataId }
                    }else{
                        mCollectionId.append(mCollectionDataId)
                    }
                }
            }
            self.mCollectCollectionView.reloadData()
        }
   
    }

    
    @IBAction func mClearAllFilters(_ sender: Any) {
        
        self.mItemsId.removeAll()
        self.mCollectionId.removeAll()
        self.mMetalsId.removeAll()
        self.mStonesId.removeAll()
        self.mLocationsId.removeAll()
        self.mSizeId.removeAll()
        self.mItemCollectionView.reloadData()
        self.mCollectCollectionView.reloadData()
        self.mMetalCollectionView.reloadData()

        self.mLocationCollectionView.reloadData()

        
        self.mScannedStocks.text = "0"
        self.mUnscannedStocks.text = "0"
        self.mConflictStocks.text = "0"
        self.mSCANNED = NSMutableArray()
        self.mUNSCANNED = NSMutableArray()
        self.mCONFLICT = [String]()
        self.mUnknownStocks.text = "0"
        
        self.mScannedData = [String]()
        self.mScannedSKU = [String]()
        self.mScannedCount = [Int]()
        self.mUnscannedData = [String]()
        self.mConflictData = [String]()
        self.mInventoryData = NSArray()
        self.mStatusData = NSMutableArray()
        self.mSCANNED = NSMutableArray()
        self.mUNSCANNED = NSMutableArray()
        
        self.mSAVESCANNED = NSMutableArray()
        self.mSAVEUNSCANNED = NSMutableArray()
        self.mCONFLICT = [String]()
        self.FINALCONFLICT = [String]()
        
        mGetInventoryDataStock(key:  "")
        
    }
    
    @IBAction func mSelectAllItems(_ sender: UIButton) {
        
        if sender.isSelected {
            sender.isSelected = false
            
            sender.setTitle("Select All".localizedString, for: .normal)
            mItemsId.removeAll()
            
            mItemCollectionView.reloadData()
            
        }else{
            
            sender.isSelected = true
            mItemsId.removeAll()
            
            for (index, _) in self.mItemsData.enumerated(){
                if let mData = mItemsData[index] as? NSDictionary, let id = mData.value(forKey: "_id") as? String {
                    mItemsId.append(id)
                }
            }
            sender.setTitle("Deselect".localizedString, for: .normal)
            mItemCollectionView.reloadData()
            
        }
    }

    @IBAction func mSelectAllCollection(_ sender: UIButton) {
        
        
        if sender.isSelected {
            sender.isSelected = false
            
            sender.setTitle("Select All".localizedString, for: .normal)
            mCollectionId.removeAll()
            
            mCollectCollectionView.reloadData()
            
        }else{
            sender.setTitle("Deselect".localizedString, for: .normal)
            sender.isSelected = true
            mCollectionId.removeAll()
            
            
            for (index, _) in self.mCollectionData.enumerated(){
                if let mData = mCollectionData[index] as? NSDictionary, let id = mData.value(forKey: "id") as? String {
                    mCollectionId.append(id)
                }
            }
            mCollectCollectionView.reloadData()
            
        }
    }
  
    
    @IBAction func mSelectAllMetals(_ sender: UIButton) {
        
        
        if sender.isSelected {
            sender.isSelected = false
            
            sender.setTitle("Select All".localizedString, for: .normal)
            mMetalsId.removeAll()
            
            mMetalCollectionView.reloadData()
            
        }else{
            sender.setTitle("Deselect".localizedString, for: .normal)
            sender.isSelected = true
            mMetalsId.removeAll()
            
            
            for (index, _) in self.mMetalsData.enumerated(){
                
                if let mData = mMetalsData[index] as? NSDictionary, let id = mData.value(forKey: "id") as? String {
                    mMetalsId.append(id)
                }
            }
            mMetalCollectionView.reloadData()
            
        }
    }
    
    @IBAction func mSelectAllLocation(_ sender: UIButton) {
        
        
        if sender.isSelected {
            sender.isSelected = false
            
            sender.setTitle("Select All".localizedString, for: .normal)
            mLocationsId.removeAll()
            
            mLocationCollectionView.reloadData()
            
        }else{
            
            sender.isSelected = true
            sender.setTitle("Deselect".localizedString, for: .normal)
            mLocationsId.removeAll()
            
            
            for (index, _) in self.mLocationsData.enumerated(){
                if let mData = mLocationsData[index] as? NSDictionary, let id = mData.value(forKey: "id") as? String {
                    mLocationsId.append(id)
                }
            }
            mLocationCollectionView.reloadData()
            
        }
    }

    @IBAction func mSaveData(_ sender: Any) {
        
    }
    
    @IBAction func mSearchStock(_ sender: UITextField) {
        
    }
    
    func mGetScanResults() {
        print("mGetScanResults")
        var isUnknown = true
        for i in mStatusData {
            if let mValue = i as? NSMutableDictionary,
               let sku = mValue.value(forKey: "SKU") as? String,
               let stockID = mValue.value(forKey: "stock_id") as? String,
               let poQtyString = mValue.value(forKey: "po_QTY") as? String,
               let poQty = Int(poQtyString) {
                
                let searchKey = mSearchStock.text
                print("mGetScanResults searchKey: \(searchKey ?? "") == sku: \(sku) || searchKey: \(searchKey ?? "") == stockID: \(stockID)")
                if searchKey == sku || searchKey == stockID {
                    if !mScannedData.contains(stockID) {
                        mScannedData.append(stockID)
                        mScannedCount.append(poQty)
                        let items = uniqueElementsFrom(array: mScannedData)
                        mScannedData = items
                        mScannedStocks.text = "\(mScannedCount.reduce(0, {$0 + $1}))"
                        let mUnsCount = (Int(mTotalStocks.text ?? "0") ?? 0) - (Int(mScannedStocks.text ?? "0") ?? 0)
                        mUnscannedStocks.text = "\(mUnsCount)"
                        mSCANNED.add(mValue)
                        
                        let mData = NSMutableDictionary()
                        mData.setValue(stockID, forKey: "stock_id")
                        mData.setValue(poQty, forKey: "po_QTY")
//                        if let productDetails = mData["product_details"] as? NSDictionary {
//
//                            mData.setValue(
//                                "\(productDetails["po_QTY"] ?? "0")",
//                                forKey: "po_QTY"
//                            )
//
//                        } else {
//
//                            mData.setValue(
//                                "\(mData["po_QTY"] ?? "0")",
//                                forKey: "po_QTY"
//                            )
//                        }
                        mData.setValue(sku, forKey: "SKU")
                        mData.setValue("\(mValue.value(forKey: "_id") ?? "")", forKey: "_id")
                        mData.setValue("\(mValue.value(forKey: "location_id") ?? "")", forKey: "location_id")
                        
                        mSAVESCANNED.add(mData)
                    }
                    isUnknown = false
                }
            }
        }
        
        if isUnknown {
            
            let mUnknowdNewData = NSMutableDictionary()
            mUnknowdNewData.setValue(mSearchStock.text ?? "", forKey: "SKU")
            mUnknowdNewData.setValue(mSearchStock.text ?? "", forKey: "stock_id")
            mUnknowdNewData.setValue("", forKey: "po_QTY")
            mUnknowdNewData.setValue("", forKey: "_id")
            mUnknowdNewData.setValue("", forKey: "location_id")
            self.mUNKNOWNARRAY.add(mUnknowdNewData)
            
            
            mCONFLICT.append(mSearchStock.text ?? "" + "UKN")
            let items = uniqueElementsFrom(array: mCONFLICT)
            mCONFLICT = items
    
        }
        
        mStatus()
        
    }
    
    func getRFIDData(data: String) {

        let lookupKey = normalizedStockLookupKey(data)

        print("getRFIDData:", lookupKey)

        guard !lookupKey.isEmpty else { return }

        var mUnknown = false

        // O(1) lookup. The map contains stock_id/SKU plus any RFID/EPC aliases.
        guard let item = stockMap[lookupKey] else {

            print("UNKNOWN RFID =", lookupKey)
            mUnknown = true

            let mUnknowdNewData = NSMutableDictionary()
            mUnknowdNewData["SKU"] = lookupKey
            mUnknowdNewData["stock_id"] = lookupKey
            mUnknowdNewData["po_QTY"] = ""
            mUnknowdNewData["_id"] = ""
            mUnknowdNewData["location_id"] = ""

            if !mCONFLICT.contains(lookupKey + "UKN") {
                mUNKNOWNARRAY.add(mUnknowdNewData)
                mCONFLICT.append(lookupKey + "UKN")
            }

            mStatus()
            return
        }

        let stockID = "\(item["stock_id"] ?? "")"
        let sku = "\(item["SKU"] ?? "")"
        let poQty = Int("\(item["po_QTY"] ?? "0")") ?? 0

        print("========== RFID MATCH ==========")
        print("Searching =", data)
        print("SKU =", sku)
        print("stockID =", stockID)
        print("===============================")
        // Scan ซ้ำ = Conflict
        if mScannedData.contains(stockID) {

            print("⚠️ CONFLICT =", stockID)

            if !mCONFLICT.contains(stockID) {
                mCONFLICT.append(stockID)

                let conflictItem = NSMutableDictionary()

                conflictItem["SKU"] = sku
                conflictItem["stock_id"] = stockID
                conflictItem["po_QTY"] = "\(poQty)"
                conflictItem["_id"] = "\(item["_id"] ?? "")"
                conflictItem["location_id"] = "\(item["location_id"] ?? "")"

                mCONFLICTARRAY.add(conflictItem)
            }

            mStatus()
            return
        }
        if !mScannedData.contains(stockID) {

            print("Append Stock =", stockID)

            mScannedData.append(stockID)
            mScannedCount.append(poQty)

            mScannedData = uniqueElementsFrom(array: mScannedData)

            mScannedStocks.text = "\(mScannedCount.reduce(0, +))"

            let total = Int(mTotalStocks.text ?? "0") ?? 0
            let scanned = Int(mScannedStocks.text ?? "0") ?? 0

            mUnscannedStocks.text = "\(max(0, total - scanned))"

            let scannedItem = NSMutableDictionary()

            scannedItem["SKU"] = sku
            scannedItem["stock_id"] = stockID
            scannedItem["po_QTY"] = "\(poQty)"
            scannedItem["_id"] = "\(item["_id"] ?? "")"
            scannedItem["location_id"] = "\(item["location_id"] ?? "")"

            mSCANNED.add(scannedItem)
            mSAVESCANNED.add(scannedItem)

            print("Scanned =", mScannedData.count)
        }

        if mUnknown {

            let mUnknowdNewData = NSMutableDictionary()

            mUnknowdNewData["SKU"] = lookupKey
            mUnknowdNewData["stock_id"] = lookupKey
            mUnknowdNewData["po_QTY"] = ""
            mUnknowdNewData["_id"] = ""
            mUnknowdNewData["location_id"] = ""

            if !mCONFLICT.contains(lookupKey + "UKN") {

                mUNKNOWNARRAY.add(mUnknowdNewData)
                mCONFLICT.append(lookupKey + "UKN")
            }
        }

        mPowerView.isHidden = true
        mPowerIcon.image = UIImage(named: "power_icgrey")
        mPowerLabel?.textColor = UIColor(named: "theme6A")

        mStatus()
    }
    
//    func getRFIDData(data: String){
//        if !Thread.isMainThread {
//
//                DispatchQueue.main.async {
//                    self.getRFIDData(data: data)
//                }
//
//                return
//            }
//        print("getRFIDData: \(data)")
//        print("Searching =", data)
//
//        let result = mInventoryData.filter {
//            ($0 as? NSDictionary)?["stock_id"] as? String == data
//        }
//
//        print("Found =", result.count)
//        var mUnknown = true
//        for i in mStatusData {
//
//            if let mValue = i as? NSMutableDictionary {
//
//                let sku = "\(mValue.value(forKey: "SKU") ?? "")"
//                let stockID = "\(mValue.value(forKey: "stock_id") ?? "")"
//                let poQty = Int("\(mValue.value(forKey: "po_QTY") ?? "0")") ?? 0
//
//                if !data.isEmpty {
//
//                    let searchKey = data
//
//                    print("========== RFID MATCH ==========")
//                    print("Searching =", searchKey)
//                    print("Reader =", searchKey)
//                    print("SKU =", sku)
//                    print("stockID =", stockID)
//                    print("MATCH SKU =", searchKey == sku)
//                    print("MATCH STOCK =", searchKey == stockID)
//                    print("===============================")
//                    if searchKey == sku || searchKey == stockID {
//                        if !mScannedData.contains(stockID){
//                            print("Append Stock =", stockID)
//                            mScannedData.append(stockID)
//                            print("mScannedData =", mScannedData)
//                            mScannedCount.append(poQty)
//                            let items = uniqueElementsFrom(array: mScannedData)
//                            mScannedData = items
//                            mScannedStocks.text = "\(mScannedCount.reduce(0, {$0 + $1}))"
//                            let mUnsCount = (Int(mTotalStocks.text ?? "0") ?? 0) - (Int(mScannedStocks.text ?? "0") ?? 0)
//                            mUnscannedStocks.text = "\(mUnsCount)"
//                            mSCANNED.add(mValue)
//
//                            print("mScannedStocks.text = \(String(describing: mScannedStocks.text))")
//                            print("mUnscannedStocks.text = \(String(describing: mUnscannedStocks.text))")
//                            print("mScannedData = \(mScannedData)")
//                            print("mUnsCount = \(mUnsCount)")
//                            print("mValue = \(mValue)")
//                            let mData = NSMutableDictionary()
//                            mData.setValue(stockID, forKey: "stock_id")
//                            mData.setValue(poQty, forKey: "po_QTY")
//                            mData.setValue(sku, forKey: "SKU")
//                            mData.setValue("\(mValue.value(forKey: "_id") ?? "")", forKey: "_id")
//                            mData.setValue("\(mValue.value(forKey: "location_id") ?? "")", forKey: "location_id")
//
//                            mSAVESCANNED.add(mData)
//                        }
//                        mUnknown = false
//                    }else{
//
//                    }
//
//                }
//            }
//        }
//
//        if mUnknown {
//            let mUnknowdNewData = NSMutableDictionary()
//            mUnknowdNewData.setValue(mSearchStock.text ?? "", forKey: "SKU")
//            mUnknowdNewData.setValue(mSearchStock.text ?? "", forKey: "stock_id")
//            mUnknowdNewData.setValue("", forKey: "po_QTY")
//            mUnknowdNewData.setValue("", forKey: "_id")
//            mUnknowdNewData.setValue("", forKey: "location_id")
//            self.mUNKNOWNARRAY.add(mUnknowdNewData)
//
//
//            mCONFLICT.append(mSearchStock.text ?? "" + "UKN")
//            let items = uniqueElementsFrom(array: mCONFLICT)
//            mCONFLICT = items
//        }
//
//
//        mPowerView.isHidden = true
//        mPowerIcon.image = UIImage(named: "power_icgrey")
//        mPowerLabel.textColor =  UIColor(named: "theme6A")
//        mStatus()
//    }
    
    func mStatus() {
        print("mStatus Main =", Thread.isMainThread)
        mUNSCANNED = NSMutableArray()
        mSAVEUNSCANNED = NSMutableArray()

        var mCONF = [String]()
        var mUNK = [String]()

        FINALCONFLICT.removeAll()

        if mCONFLICT.count > 0 {

            for i in 0..<mCONFLICT.count {

                FINALCONFLICT.append(
                    mCONFLICT[i].trimmingCharacters(
                        in: CharacterSet(charactersIn: "0123456789").inverted
                    )
                )

                FINALCONFLICT = uniqueElementsFrom(array: FINALCONFLICT)

                if mCONFLICT[i].contains("UKN") {
                    mUNK.append(mCONFLICT[i])
                } else {
                    mCONF.append(mCONFLICT[i])
                }
            }
        }

        mConflictStocks.text = "\(mCONF.count)"
        mUnknownStocks.text = "\(mUNK.count)"

        //----------------------------------------------------
        // Build UNSCANNED LIST ONLY
        //----------------------------------------------------

        for i in mStatusData {

            guard let mValue = i as? NSDictionary else {
                continue
            }

            let stockID = "\(mValue.value(forKey: "stock_id") ?? "")"

            if !mScannedData.contains(stockID) {

                let mData = NSMutableDictionary()

                mData.setValue(stockID, forKey: "stock_id")
                mData.setValue(mValue.value(forKey: "po_QTY"), forKey: "po_QTY")
                mData.setValue(mValue.value(forKey: "SKU") ?? "", forKey: "SKU")
                mData.setValue(mValue.value(forKey: "_id") ?? "", forKey: "_id")
                mData.setValue(mValue.value(forKey: "location_id") ?? "", forKey: "location_id")

                mUNSCANNED.add(mValue)
                mSAVEUNSCANNED.add(mData)
            }
        }

        //----------------------------------------------------
        // Update Summary
        //----------------------------------------------------

        mScannedStocks.text = "\(mScannedCount.reduce(0,+))"

        let total = Int(mTotalStocks.text ?? "0") ?? 0
        let scanned = Int(mScannedStocks.text ?? "0") ?? 0

        mUnscannedStocks.text = "\(max(total - scanned, 0))"

        print("========== STATUS ==========")
        print("Total =", total)
        print("Scanned =", scanned)
        print("Unscanned =", max(total - scanned, 0))
        print("ScannedData =", mScannedData)
        print("============================")
        updateReferenceSummaryCards()
    }
//    func mStatus(){
//        mUNSCANNED = NSMutableArray()
//        mSAVEUNSCANNED = NSMutableArray()
//
//        var mCONF = [String]()
//        var mUNK = [String]()
//
//
//        if mCONFLICT.count > 0 {
//            for i in 0...mCONFLICT.count - 1 {
//
//                FINALCONFLICT.append(mCONFLICT[i].trimmingCharacters(in: CharacterSet(charactersIn: "0123456789").inverted))
//                let items = uniqueElementsFrom(array: FINALCONFLICT)
//                FINALCONFLICT = items
//                if mCONFLICT[i].contains("UKN") {
//                    mUNK.append(mCONFLICT[i])
//                }else{
//                    mCONF.append(mCONFLICT[i])
//                }
//            }
//            mConflictStocks.text = "\(mCONF.count)"
//            mUnknownStocks.text = "\(mUNK.count)"
//
//        }
//
//        for i in mStatusData {
//            if let mValue = i as? NSDictionary,
//               let stockID = mValue.value(forKey: "stock_id") as? String,
//               let poQtyString = mValue.value(forKey: "po_QTY") as? String,
//               let poQty = Int(poQtyString),
//               !mScannedData.contains(stockID) {
//
//                let mData = NSMutableDictionary()
//                mData.setValue(stockID, forKey: "stock_id")
////                mData.setValue(poQty, forKey: "po_QTY")
//                mData.setValue(mValue.value(forKey: "po_QTY"), forKey: "po_QTY")
//                mData.setValue(mValue.value(forKey: "SKU") as? String ?? "", forKey: "SKU")
//                mData.setValue(mValue.value(forKey: "_id") as? String ?? "", forKey: "po_product_id")
//                mData.setValue(mValue.value(forKey: "location_id") as? String ?? "", forKey: "location_id")
////                print("mSAVEUNSCANNED mData = \(mData)")
//                print("mSAVEUNSCANNED SKU = \(mValue.value(forKey: "SKU"))")
//                print("mSAVEUNSCANNED stockID = \(stockID)")
//
//
//                if !mScannedData.contains(stockID) {
//
//                    mScannedData.append(stockID)
//
//                    mScannedCount.append(poQty)
//
//                    mScannedStocks.text = "\(mScannedCount.reduce(0,+))"
//                    print("Scanned Label =", mScannedStocks.text ?? "")
//                    let unscanned =
//                        (Int(mTotalStocks.text ?? "0") ?? 0)
//                        - (Int(mScannedStocks.text ?? "0") ?? 0)
//
//                    mUnscannedStocks.text = "\(unscanned)"
//
//                    mSCANNED.add(mValue)
//
//                    mSAVESCANNED.add(mData)
////                    mSAVEUNSCANNED.add(mData)
////                    mUNSCANNED.add(mValue)
//                }
//            }
//        }
//    }
    
    func addDoneButtonOnKeyboard(){
        let doneToolbar: UIToolbar = UIToolbar(frame: CGRect.init(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 50))
        doneToolbar.barStyle = .default
        
        let flexSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let done: UIBarButtonItem = UIBarButtonItem(title: "Search", style: .done, target: self, action: #selector(self.doneButtonAction))
        
        let items = [flexSpace, done]
        doneToolbar.items = items
        doneToolbar.sizeToFit()
        
        mSearchStock.inputAccessoryView = doneToolbar
    }
    
    @objc func doneButtonAction(){
        mSearchStock.resignFirstResponder()
        mGetScanResults()
    }
    
    @IBAction func mHideDeviceView(_ sender: Any) {
        mDeviceView.isHidden = true
        pendingZebraReaderID = nil
        pendingBluetoothIdentifier = nil
        mDeviceTableView.reloadData()
        syncReferenceOverlayVisibility()
    }
    @IBAction func mHideScanner(_ sender: Any) {
        mScannerView.isHidden = true
        
        shape.removeFromSuperlayer()
        self.mScannerCamView.layer.sublayers?.remove(at: 0)
        layer.sublayers?.remove(at: 1)
        if (captureSession?.isRunning == true) {
            captureSession.stopRunning()
        }
        captureSession = nil
        
        
    }
    
    @IBAction func mOpenScanner(_ sender: Any) {
        mStartQRcode()
    }
    
    
    @IBAction func mStart(_ sender: UIButton) {
        guard isAnyRFIDConnected else {
            sender.isSelected = false
            updateScannerControls()
            return
        }

        view.endEditing(true)
        mPowerView.isHidden = true

        if isZebraRFIDConnected {
            recentRFIDReads.removeAll()

            if ZebraRFIDService.shared.isInventoryRunning {
                print("🛑 ZEBRA RFID STOP")
                ZebraRFIDService.shared.stopInventory()
                canStopAfterPause = true

                // Immediately refresh the footer so Stop becomes disabled/grey
                // as soon as Pause is pressed.
                self.updateScannerControls()
            } else {
                canStopAfterPause = false
                print("▶️ ZEBRA RFID START")
                // Start directly. startScan() currently adds a 0.5s delay,
                // which can cause Pause to be followed by an unwanted restart.
                ZebraRFIDService.shared.startInventory()

                DispatchQueue.main.async {
                    self.updateScannerControls()
                }
            }
            return
        }

        if bluetoothService?.scannerIsRunning == 1 {
            stopRFID()
            canStopAfterPause = true
        } else {
            canStopAfterPause = false
            startRFID()
        }

        DispatchQueue.main.async {
            self.updateScannerControls()
        }
    }

    @IBAction func mScanNow(_ sender: UIButton) {
        
        if centralManager?.isScanning ?? false {
            self.mScanNowLabel.text = "Scan now".localizedString
            stopScan()
        } else {
            self.mScanNowLabel.text = "Scanning".localizedString
            search()
        }
        
    }
    
    // MARK: - Reference bottom sheets

    private func makeSheetCloseButton() -> UIButton {
        let button = UIButton(type: .system)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setImage(UIImage(systemName: "xmark"), for: .normal)
        button.tintColor = UIColor(hex: "#222222")
        button.widthAnchor.constraint(equalToConstant: 28).isActive = true
        button.heightAnchor.constraint(equalToConstant: 28).isActive = true
        return button
    }

    private func hideLegacyOverlayViewsForReferenceSheet() {
        // These are storyboard-era full-screen/container views. They must stay
        // hidden while the programmatic Stock Take reference UI is displayed.
        // In particular, mDeviceView can contain the old 2x2 colored device
        // screen, which must NEVER appear behind the Device bottom sheet.
        mDeviceView?.isHidden = true
        mPowerView?.isHidden = true
        mSearchDeviceView?.isHidden = true
        mScannerView?.isHidden = true
        mScannerCamView?.isHidden = true
        mStartScannView?.isHidden = true
        mFilterView?.isHidden = true
    }

    private func showReferenceDeviceSheet() {
        if referenceDeviceSheet == nil {
            let sheet = UIView()
            sheet.translatesAutoresizingMaskIntoConstraints = false
            sheet.backgroundColor = .systemBackground
            sheet.layer.cornerRadius = 8
            sheet.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
            sheet.clipsToBounds = true
            view.addSubview(sheet)
            referenceDeviceSheet = sheet

            let handle = UIView()
            handle.translatesAutoresizingMaskIntoConstraints = false
            handle.backgroundColor = UIColor(hex: "#D2D2D2")
            handle.layer.cornerRadius = 2
            sheet.addSubview(handle)

            let title = UILabel()
            title.translatesAutoresizingMaskIntoConstraints = false
            title.text = "Device"
            title.font = UIFont.systemFont(ofSize: 20, weight: .semibold)
            title.textColor = UIColor(hex: "#333333")
            sheet.addSubview(title)

            let close = makeSheetCloseButton()
            close.addTarget(self, action: #selector(closeReferenceDeviceSheet), for: .touchUpInside)
            sheet.addSubview(close)

            if let table = mDeviceTableView {
                table.removeFromSuperview()
                table.translatesAutoresizingMaskIntoConstraints = false
                table.backgroundColor = .clear
                table.separatorStyle = .none
                sheet.addSubview(table)
                NSLayoutConstraint.activate([
                    table.leadingAnchor.constraint(equalTo: sheet.leadingAnchor),
                    table.trailingAnchor.constraint(equalTo: sheet.trailingAnchor),
                    table.topAnchor.constraint(equalTo: title.bottomAnchor, constant: 12),
                    table.bottomAnchor.constraint(equalTo: sheet.bottomAnchor)
                ])
            }

            // Empty state is part of the sheet itself so the icon/text stay
            // centered exactly like the reference image.
            let empty = UIView()
            empty.translatesAutoresizingMaskIntoConstraints = false
            empty.backgroundColor = .clear
            sheet.addSubview(empty)
            referenceDeviceEmptyStateView = empty

            let icon = UIImageView(
                image: UIImage(systemName: "antenna.radiowaves.left.and.right.slash")
            )
            icon.translatesAutoresizingMaskIntoConstraints = false
            icon.tintColor = UIColor(hex: "#868686")
            icon.contentMode = .scaleAspectFit
            empty.addSubview(icon)

            let message = UILabel()
            message.translatesAutoresizingMaskIntoConstraints = false
            message.text = "Device not found"
            message.font = UIFont.systemFont(ofSize: 15, weight: .semibold)
            message.textColor = UIColor(hex: "#222222")
            message.textAlignment = .center
            empty.addSubview(message)

            let subtitle = UILabel()
            subtitle.translatesAutoresizingMaskIntoConstraints = false
            subtitle.text = "Please check your connection and try again."
            subtitle.font = UIFont.systemFont(ofSize: 13, weight: .regular)
            subtitle.textColor = UIColor(hex: "#868686")
            subtitle.textAlignment = .center
            empty.addSubview(subtitle)

            NSLayoutConstraint.activate([
                sheet.leadingAnchor.constraint(equalTo: view.leadingAnchor),
                sheet.trailingAnchor.constraint(equalTo: view.trailingAnchor),
                sheet.bottomAnchor.constraint(equalTo: view.bottomAnchor),
                sheet.heightAnchor.constraint(equalToConstant: 319),

                handle.topAnchor.constraint(equalTo: sheet.topAnchor, constant: 12),
                handle.centerXAnchor.constraint(equalTo: sheet.centerXAnchor),
                handle.widthAnchor.constraint(equalToConstant: 40),
                handle.heightAnchor.constraint(equalToConstant: 4),

                title.leadingAnchor.constraint(equalTo: sheet.leadingAnchor, constant: 16),
                title.topAnchor.constraint(equalTo: sheet.topAnchor, constant: 34),

                close.trailingAnchor.constraint(equalTo: sheet.trailingAnchor, constant: -16),
                close.centerYAnchor.constraint(equalTo: title.centerYAnchor),

                empty.leadingAnchor.constraint(equalTo: sheet.leadingAnchor),
                empty.trailingAnchor.constraint(equalTo: sheet.trailingAnchor),
                empty.topAnchor.constraint(equalTo: title.bottomAnchor),
                empty.bottomAnchor.constraint(equalTo: sheet.bottomAnchor),

                icon.centerXAnchor.constraint(equalTo: empty.centerXAnchor),
                icon.topAnchor.constraint(equalTo: empty.topAnchor, constant: 48),
                icon.widthAnchor.constraint(equalToConstant: 36),
                icon.heightAnchor.constraint(equalToConstant: 36),

                message.centerXAnchor.constraint(equalTo: empty.centerXAnchor),
                message.topAnchor.constraint(equalTo: icon.bottomAnchor, constant: 10),
                message.leadingAnchor.constraint(greaterThanOrEqualTo: empty.leadingAnchor, constant: 20),
                message.trailingAnchor.constraint(lessThanOrEqualTo: empty.trailingAnchor, constant: -20),

                subtitle.centerXAnchor.constraint(equalTo: empty.centerXAnchor),
                subtitle.topAnchor.constraint(equalTo: message.bottomAnchor, constant: 4),
                subtitle.leadingAnchor.constraint(greaterThanOrEqualTo: empty.leadingAnchor, constant: 20),
                subtitle.trailingAnchor.constraint(lessThanOrEqualTo: empty.trailingAnchor, constant: -20)
            ])
        }

        referenceDeviceSheet?.isHidden = false
        view.bringSubviewToFront(referenceDeviceSheet!)
        updateDeviceEmptyState()
        mDeviceTableView?.reloadData()
        syncReferenceOverlayVisibility()
    }

    @objc private func closeReferenceDeviceSheet() {
        referenceDeviceSheet?.isHidden = true
        deviceDiscoveryTimer?.invalidate()
        deviceDiscoveryTimer = nil
        syncReferenceOverlayVisibility()
        updateScannerControls()
    }

    private func showReferencePowerNoDeviceSheet() {
        if referencePowerNoDeviceSheet == nil {
            let sheet = UIView()
            sheet.translatesAutoresizingMaskIntoConstraints = false
            sheet.backgroundColor = .systemBackground
            sheet.layer.cornerRadius = 10
            sheet.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
            sheet.clipsToBounds = true
            view.addSubview(sheet)
            referencePowerNoDeviceSheet = sheet

            let handle = UIView()
            handle.translatesAutoresizingMaskIntoConstraints = false
            handle.backgroundColor = UIColor(hex: "#D2D2D2")
            handle.layer.cornerRadius = 2
            sheet.addSubview(handle)

            let title = UILabel()
            title.translatesAutoresizingMaskIntoConstraints = false
            title.text = "Power"
            title.font = UIFont.systemFont(ofSize: 20, weight: .semibold)
            title.textColor = UIColor(hex: "#333333")
            sheet.addSubview(title)

            let close = makeSheetCloseButton()
            close.addTarget(self, action: #selector(closeReferencePowerNoDeviceSheet), for: .touchUpInside)
            sheet.addSubview(close)

            let imageView = UIImageView(image: UIImage(systemName: "antenna.radiowaves.left.and.right.slash"))
            imageView.translatesAutoresizingMaskIntoConstraints = false
            imageView.tintColor = UIColor(hex: "#868686")
            imageView.contentMode = .scaleAspectFit
            sheet.addSubview(imageView)

            let message = UILabel()
            message.translatesAutoresizingMaskIntoConstraints = false
            message.text = "No Device Connected"
            message.font = UIFont.systemFont(ofSize: 15, weight: .semibold)
            message.textColor = UIColor(hex: "#222222")
            message.textAlignment = .center
            sheet.addSubview(message)

            let subtitle = UILabel()
            subtitle.translatesAutoresizingMaskIntoConstraints = false
            subtitle.text = "Please check your connection and try again."
            subtitle.font = UIFont.systemFont(ofSize: 13, weight: .regular)
            subtitle.textColor = UIColor(hex: "#868686")
            subtitle.textAlignment = .center
            sheet.addSubview(subtitle)

            NSLayoutConstraint.activate([
                sheet.leadingAnchor.constraint(equalTo: view.leadingAnchor),
                sheet.trailingAnchor.constraint(equalTo: view.trailingAnchor),
                sheet.bottomAnchor.constraint(equalTo: view.bottomAnchor),
                sheet.heightAnchor.constraint(equalToConstant: 300),
                handle.topAnchor.constraint(equalTo: sheet.topAnchor, constant: 12),
                handle.centerXAnchor.constraint(equalTo: sheet.centerXAnchor),
                handle.widthAnchor.constraint(equalToConstant: 40),
                handle.heightAnchor.constraint(equalToConstant: 4),
                title.leadingAnchor.constraint(equalTo: sheet.leadingAnchor, constant: 16),
                title.topAnchor.constraint(equalTo: sheet.topAnchor, constant: 34),
                close.trailingAnchor.constraint(equalTo: sheet.trailingAnchor, constant: -16),
                close.centerYAnchor.constraint(equalTo: title.centerYAnchor),
                imageView.centerXAnchor.constraint(equalTo: sheet.centerXAnchor),
                imageView.topAnchor.constraint(equalTo: title.bottomAnchor, constant: 48),
                imageView.widthAnchor.constraint(equalToConstant: 36),
                imageView.heightAnchor.constraint(equalToConstant: 36),
                message.centerXAnchor.constraint(equalTo: sheet.centerXAnchor),
                message.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 10),
                subtitle.centerXAnchor.constraint(equalTo: sheet.centerXAnchor),
                subtitle.topAnchor.constraint(equalTo: message.bottomAnchor, constant: 4)
            ])
        }

        referencePowerNoDeviceSheet?.isHidden = false
        view.bringSubviewToFront(referencePowerNoDeviceSheet!)
        syncReferenceOverlayVisibility()
    }

    @objc private func closeReferencePowerNoDeviceSheet() {
        referencePowerNoDeviceSheet?.isHidden = true
        if let powerButton = referenceBottomButtons["Power"] {
            powerButton.isSelected = false
        }
        syncReferenceOverlayVisibility()
        updateScannerControls()
    }

    @IBAction func mConnect(_ sender: UIButton) {
        view.endEditing(true)

        // Close/hide every legacy storyboard overlay first. The reference UI is
        // already on screen; Connect must ONLY add the bottom sheet on top of it.
        hideLegacyOverlayViewsForReferenceSheet()
        referencePowerNoDeviceSheet?.isHidden = true
        mDeviceView.isHidden = true

        pendingZebraReaderID = nil
        pendingBluetoothIdentifier = nil
        deviceDiscoveryTimer?.invalidate()
        deviceDiscoveryTimer = nil

        // Always show the reference Device bottom sheet. The old storyboard
        // Device/Connect view is intentionally kept hidden because its layout
        // is full-screen and does not match the supplied reference.
        showReferenceDeviceSheet()

        let alreadyConnected = isAnyRFIDConnected

        if !alreadyConnected {
            // Do NOT clear the cached Zebra reader/device list here.
            // When returning from Home, the iOS/Zebra SDK may already know
            // the paired reader while the async discovery callback has not
            // fired again yet. Clearing `devices` at this point made the
            // Connect sheet appear empty.
            var cachedReaders = readers

            let availableReaders = ZebraRFIDService.shared.availableReaders
            for reader in availableReaders {
                if !cachedReaders.contains(where: {
                    $0.getReaderID() == reader.getReaderID()
                }) {
                    cachedReaders.append(reader)
                }
            }

            let sdkReaders = ZebraRFIDService.shared.getActualDeviceList()
            for reader in sdkReaders {
                if !cachedReaders.contains(where: {
                    $0.getReaderID() == reader.getReaderID()
                }) {
                    cachedReaders.append(reader)
                }
            }

            readers = cachedReaders

            // Keep cached Zebra devices and merge fresh Bluetooth devices.
            for reader in readers {
                let exists = devices.contains {
                    $0.type == .zebra &&
                    $0.zebraReader?.getReaderID() == reader.getReaderID()
                }
                if !exists {
                    devices.append(ScanDevice(reader: reader))
                }
            }

            arrPeripheral.removeAll()
            mDeviceTableView.reloadData()
            updateDeviceEmptyState()

            // Start both supported discovery paths.
            search()
            ZebraRFIDService.shared.dumpAccessories()
            ZebraRFIDService.shared.startDiscovery()

            // Zebra's discovery is asynchronous. The SDK log shows that the
            // MFi accessory is added after startDiscovery(), so do not treat
            // an initial availableReaders == 0 as "no device". Give the SDK
            // a short window to raise zebraReaderChanged.
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) { [weak self] in
                guard let self = self else { return }

                let discovered = ZebraRFIDService.shared.availableReaders
                print("🦓 Delayed reader check =", discovered.count)

                for reader in discovered {
                    let exists = self.devices.contains {
                        $0.type == .zebra &&
                        $0.zebraReader?.getReaderID() == reader.getReaderID()
                    }
                    if !exists {
                        self.readers.append(reader)
                        self.devices.append(ScanDevice(reader: reader))
                    }
                }

                self.updateDeviceEmptyState()
                self.mDeviceTableView.reloadData()
            }

            // Some Zebra SDK versions populate availableReaders first and
            // update the actual-device list shortly afterwards. Refresh both
            // sources immediately so the Device sheet does not stay empty
            // while waiting for a notification.
            let availableZebraReaders = ZebraRFIDService.shared.availableReaders
            for reader in availableZebraReaders {
                let exists = self.devices.contains {
                    $0.type == .zebra &&
                    $0.zebraReader?.getReaderID() == reader.getReaderID()
                }
                if !exists {
                    self.devices.append(ScanDevice(reader: reader))
                }
            }
            self.updateDeviceEmptyState()
            self.mDeviceTableView.reloadData()

            deviceDiscoveryTimer = Timer.scheduledTimer(
                withTimeInterval: ScanPeriod + 0.5,
                repeats: false
            ) { [weak self] _ in
                guard let self = self else { return }
                self.deviceDiscoveryTimer = nil

                let discovered = ZebraRFIDService.shared.getActualDeviceList()
                if !discovered.isEmpty {
                    self.readers = discovered
                    ZebraRFIDService.shared.availableReaders = discovered

                    for reader in discovered {
                        let exists = self.devices.contains {
                            $0.type == .zebra &&
                            $0.zebraReader?.getReaderID() == reader.getReaderID()
                        }

                        if !exists {
                            self.devices.append(ScanDevice(reader: reader))
                        }
                    }
                }

                self.updateDeviceEmptyState()
                self.mDeviceTableView.reloadData()
                self.syncReferenceOverlayVisibility()
            }
        } else {
            // Keep the connected reader visible with the green checkmark.
            if ZebraRFIDService.shared.isConnected {
                let zebraReaders = ZebraRFIDService.shared.getActualDeviceList()
                if !zebraReaders.isEmpty {
                    readers = zebraReaders
                    ZebraRFIDService.shared.availableReaders = zebraReaders
                }

                for reader in readers {
                    let exists = devices.contains {
                        $0.type == .zebra &&
                        $0.zebraReader?.getReaderID() == reader.getReaderID()
                    }
                    if !exists {
                        devices.append(ScanDevice(reader: reader))
                    }
                }
            }

            updateDeviceEmptyState()
            mDeviceTableView.reloadData()
        }

        sender.isSelected = true
        syncReferenceOverlayVisibility()
        updateScannerControls()
    }


    @IBAction func mHome(_ sender: Any) {
        
        self.navigationController?.popViewController(animated:true)
    }
    
    
    @IBAction func mTotalScanned(_ sender: Any) {
        if mTotalStocks.text != "0" {
            if let mTotalStock = storyBoard.instantiateViewController(withIdentifier: "TotalStock") as? TotalStock {
                mTotalStock.mType = "Total"
                print("StockTakePage mTotalScanned \(mStatusData)")
                mTotalStock.mTotalStockData = mStatusData
                
                mTotalStock.mCount = mTotalStocks.text ?? "0"
                self.navigationController?.pushViewController(mTotalStock, animated:true)
            }
        }
        
    }
    @IBAction func mScanned(_ sender: Any) {
        
        if mScannedStocks.text != "0" {
            
            if let mTotalStock = storyBoard.instantiateViewController(withIdentifier: "TotalStock") as? TotalStock {
                mTotalStock.mType = "Scanned"
                mTotalStock.mTotalStockData = mSCANNED
                mTotalStock.mCount = mScannedStocks.text ?? "0"
                self.navigationController?.pushViewController(mTotalStock, animated:true)
            }
        }
    }
    @IBAction func mUnscanned(_ sender: Any) {
        
        if mUnscannedStocks.text != "0" {
            if let mTotalStock = storyBoard.instantiateViewController(withIdentifier: "TotalStock") as? TotalStock {
                mTotalStock.mType = "Unscanned"
                mTotalStock.mTotalStockData = mUNSCANNED
                mTotalStock.mCount = mUnscannedStocks.text ?? "0"
                self.navigationController?.pushViewController(mTotalStock, animated:true)
            }
        }
    }
    
    @IBAction func mConflictUnknown(_ sender: Any) {
        
        if mConflictStocks.text != "0" || mUnknownStocks.text != "0"{
            if let mConflictUnknownStock = storyBoard.instantiateViewController(withIdentifier: "ConflictUnknownStock") as? ConflictUnknownStock {
                mConflictUnknownStock.mConflictData = mCONFLICT
                mConflictUnknownStock.mCount = mConflictStocks.text ?? "0"
                self.navigationController?.pushViewController(mConflictUnknownStock, animated:true)
            }
        }
    }
    
    @IBAction func mUnknownTags(_ sender: Any) {
        
        if mConflictStocks.text != "0" || mUnknownStocks.text != "0"{
            if let mConflictUnknownStock = storyBoard.instantiateViewController(withIdentifier: "ConflictUnknownStock") as? ConflictUnknownStock {
                mConflictUnknownStock.mConflictData = mCONFLICT
                mConflictUnknownStock.mCount = "\((Int(mConflictStocks.text ?? "0") ?? 0) + (Int(mUnknownStocks.text ?? "0") ?? 0))"
                self.navigationController?.pushViewController(mConflictUnknownStock, animated:true)
            }
        }
    }
    
    
    
    @IBAction func mRefresh(_ sender: Any) {
        let running = bluetoothService?.scannerIsRunning == 1 || ZebraRFIDService.shared.isInventoryRunning

        if running {
            // Reference flow: the Clear button becomes Stop while scanning.
            print("🛑 STOCK TAKE STOP")

            if ZebraRFIDService.shared.isInventoryRunning {
                ZebraRFIDService.shared.stopInventory()
            }

            if bluetoothService?.scannerIsRunning == 1 {
                stopRFID()
            }

            recentRFIDReads.removeAll()
            updateScannerControls()
            return
        }

        // After a successful save, Clear starts a new session immediately.
        // If there is unsaved/failed-save data, confirm before clearing it.
        if shouldConfirmClearingWithoutSave() {
            showClearWithoutSavingConfirmation()
        } else {
            clearStockTakeResults()
        }
    }

    private func clearStockTakeResults() {
        guard !isSaveInProgress else { return }
        canStopAfterPause = false
        hasSuccessfulSave = false
        hasSaveFailed = false

        mScannedStocks.text = "0"
        mUnscannedStocks.text = mTotalStocks.text ?? "0"
        mConflictStocks.text = "0"
        mUnknownStocks.text = "0"

        mScannedData.removeAll()
        mScannedSKU.removeAll()
        mScannedCount.removeAll()
        mUnscannedData.removeAll()
        mConflictData.removeAll()

        mSCANNED.removeAllObjects()
        mUNSCANNED.removeAllObjects()
        mSAVESCANNED.removeAllObjects()
        mSAVEUNSCANNED.removeAllObjects()
        mCONFLICTARRAY.removeAllObjects()
        mUNKNOWNARRAY.removeAllObjects()
        mCONFLICT.removeAll()
        FINALCONFLICT.removeAll()

        recentRFIDReads.removeAll()
        updateScannerControls()
        mStatus()
    }

    private func updatePowerSheetState() {
        let connected = isAnyRFIDConnected
        let teal = UIColor(hex: "#00A38D")
        let trackGray = UIColor(hex: "#D2D2D2")
        let textGray = UIColor(hex: "#868686")

        // Reference slider styling.
        mPowerSlider?.minimumTrackTintColor = teal
        mPowerSlider?.maximumTrackTintColor = trackGray
        mFrequencySlider?.minimumTrackTintColor = teal
        mFrequencySlider?.maximumTrackTintColor = trackGray

        if connected {
            powerEmptyStateView?.removeFromSuperview()
            powerEmptyStateView = nil

            mPowerSlider?.isHidden = false
            mFrequencySlider?.isHidden = false
            mPowerValue?.isHidden = false
            mFrequency?.isHidden = false
            mPowerpLABEL?.isHidden = false
            mPowerLABEL?.isHidden = false
            mFrequencyLABEL?.isHidden = false

            // Reference defaults.
            mPowerSlider?.setValue(0.5, animated: false)
            mFrequencySlider?.setValue(0.0, animated: false)
            mPowerValue?.text = "50%"
            mFrequency?.text = "0%"

            mPowerValue?.textColor = .label
            mFrequency?.textColor = .label
            mPowerLABEL?.textColor = .label
            mPowerpLABEL?.textColor = .label
            mFrequencyLABEL?.textColor = .label
            return
        }

        // No reader connected: show only the empty state.
        mPowerSlider?.isHidden = true
        mFrequencySlider?.isHidden = true
        mPowerValue?.isHidden = true
        mFrequency?.isHidden = true
        mPowerpLABEL?.isHidden = true
        mPowerLABEL?.isHidden = true
        mFrequencyLABEL?.isHidden = true

        if powerEmptyStateView == nil {
            let container = UIView()
            container.backgroundColor = .clear
            container.translatesAutoresizingMaskIntoConstraints = false

            let imageView = UIImageView(
                image: UIImage(systemName: "antenna.radiowaves.left.and.right.slash")
            )
            imageView.tintColor = UIColor(hex: "#868686")
            imageView.contentMode = .scaleAspectFit
            imageView.translatesAutoresizingMaskIntoConstraints = false

            let title = UILabel()
            title.text = "No Device Connected"
            title.font = UIFont.systemFont(ofSize: 15, weight: .semibold)
            title.textColor = UIColor(hex: "#222222")
            title.textAlignment = .center
            title.translatesAutoresizingMaskIntoConstraints = false

            let subtitle = UILabel()
            subtitle.text = "Please check your connection and try again."
            subtitle.font = UIFont.systemFont(ofSize: 13, weight: .regular)
            subtitle.textColor = textGray
            subtitle.textAlignment = .center
            subtitle.numberOfLines = 2
            subtitle.translatesAutoresizingMaskIntoConstraints = false

            let stack = UIStackView(arrangedSubviews: [imageView, title, subtitle])
            stack.axis = .vertical
            stack.alignment = .center
            stack.spacing = 10
            stack.translatesAutoresizingMaskIntoConstraints = false

            container.addSubview(stack)

            NSLayoutConstraint.activate([
                imageView.widthAnchor.constraint(equalToConstant: 36),
                imageView.heightAnchor.constraint(equalToConstant: 36),
                stack.centerXAnchor.constraint(equalTo: container.centerXAnchor),
                stack.centerYAnchor.constraint(equalTo: container.centerYAnchor, constant: 5),
                stack.leadingAnchor.constraint(greaterThanOrEqualTo: container.leadingAnchor, constant: 20),
                stack.trailingAnchor.constraint(lessThanOrEqualTo: container.trailingAnchor, constant: -20)
            ])

            mPowerView.addSubview(container)
            NSLayoutConstraint.activate([
                container.topAnchor.constraint(equalTo: mPowerView.topAnchor, constant: 45),
                container.leadingAnchor.constraint(equalTo: mPowerView.leadingAnchor),
                container.trailingAnchor.constraint(equalTo: mPowerView.trailingAnchor),
                container.bottomAnchor.constraint(equalTo: mPowerView.bottomAnchor)
            ])

            powerEmptyStateView = container
        }
    }

    @IBAction func mPower(_ sender: UIButton) {
        // Power sheet is allowed to open even while scanning.
        // The existing slider handler controls the actual power setting.

        // Power and Device sheets are mutually exclusive.
        hideLegacyOverlayViewsForReferenceSheet()
        mDeviceView.isHidden = true
        referenceDeviceSheet?.isHidden = true

        sender.isSelected.toggle()

        if sender.isSelected {
            if isAnyRFIDConnected {
                referencePowerNoDeviceSheet?.isHidden = true
                mPowerView.isHidden = false
                mPowerView.backgroundColor = .systemBackground
                mPowerView.layer.cornerRadius = 16
                mPowerView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
                mPowerView.clipsToBounds = true

                // The reference bottom bar is a programmatic overlay and is
                // normally above storyboard views. Connected Power must be
                // explicitly promoted above it, otherwise the sheet opens
                // behind the footer and looks like the button did nothing.
                view.bringSubviewToFront(mPowerView)
                updatePowerSheetState()
                view.bringSubviewToFront(mPowerView)
            } else {
                // Phase/reference state: when no reader is connected, Power
                // shows the compact bottom sheet from the supplied design.
                mPowerView.isHidden = true
                showReferencePowerNoDeviceSheet()
            }
        } else {
            mPowerView.isHidden = true
            referencePowerNoDeviceSheet?.isHidden = true
        }

        syncReferenceOverlayVisibility()
        updateScannerControls()
    }


    @IBAction func mMore(_ sender: UIButton) {
        guard !isSaveInProgress && !hasSuccessfulSave else { return }

        let scannedQty = Int(mScannedStocks.text ?? "0") ?? 0
        guard scannedQty > 0 else {
            mMoreIcon.image = UIImage(named: "save_icg")
            mMoreLabel.textColor = UIColor(named: "theme6A")
            CommonClass.showSnackBar(message: "No Data Scanned!")
            updateScannerControls()
            return
        }

        isSaveInProgress = true
        hasSaveFailed = false
        mMoreIcon.image = nil
        mMoreLabel.textColor = UIColor(named: "themeColor")
        startSaveIndicator()
        updateScannerControls()

        // Save always stops the reader first so the payload cannot change
        // while the request is in flight.
        if ZebraRFIDService.shared.isInventoryRunning {
            ZebraRFIDService.shared.stopInventory()
        }
        if bluetoothService?.scannerIsRunning == 1 {
            stopRFID()
        }

        getVoucherID()
    }

    private func startSaveIndicator() {
        saveActivityIndicator?.removeFromSuperview()

        let indicator = UIActivityIndicatorView(style: .medium)
        indicator.color = UIColor(named: "themeColor") ?? .systemTeal
        indicator.translatesAutoresizingMaskIntoConstraints = false
        indicator.startAnimating()

        mMoreIcon.superview?.addSubview(indicator)
        NSLayoutConstraint.activate([
            indicator.centerXAnchor.constraint(equalTo: mMoreIcon.centerXAnchor),
            indicator.centerYAnchor.constraint(equalTo: mMoreIcon.centerYAnchor),
            indicator.widthAnchor.constraint(equalToConstant: 24),
            indicator.heightAnchor.constraint(equalToConstant: 24)
        ])

        saveActivityIndicator = indicator
    }

    private func stopSaveIndicator(success: Bool) {
        saveActivityIndicator?.stopAnimating()
        saveActivityIndicator?.removeFromSuperview()
        saveActivityIndicator = nil

        isSaveInProgress = false
        mMoreIcon.image = UIImage(named: success ? "save_icg" : "save_ic")
        mMoreLabel.textColor = UIColor(named: success ? "theme6A" : "themeColor")
        updateScannerControls()
    }

    @objc
    func mTimerForButton(){
        
        mItemsId = [String]()
        mMetalsId = [String]()
        mCollectionId = [String]()
        mStonesId = [String]()
        mSizeId = [String]()
        mStatusId = [String]()
        mLocationsId = [String]()
        mMinPrices = ""
        mMaxPrices = ""
        self.mScannedStocks.text = "0"
        self.mUnscannedStocks.text = "0"
        self.mConflictStocks.text = "0"
        self.mSCANNED = NSMutableArray()
        self.mUNSCANNED = NSMutableArray()
        self.mCONFLICTARRAY = NSMutableArray()
        self.mUNKNOWNARRAY = NSMutableArray()
        self.mCONFLICT = [String]()
        self.mUnknownStocks.text = "0"
        
        self.mScannedData = [String]()
        self.mScannedSKU = [String]()
        self.mScannedCount = [Int]()
        self.mUnscannedData = [String]()
        self.mConflictData = [String]()
        self.mInventoryData = NSArray()
        self.mStatusData = NSMutableArray()
        self.mSCANNED = NSMutableArray()
        self.mUNSCANNED = NSMutableArray()
        
        self.mSAVESCANNED = NSMutableArray()
        self.mSAVEUNSCANNED = NSMutableArray()
        self.mCONFLICTARRAY = NSMutableArray()
        self.mUNKNOWNARRAY = NSMutableArray()
        self.mCONFLICT = [String]()
        self.FINALCONFLICT = [String]()

        mScannedData = [String]()
        mScannedSKU = [String]()
        mScannedCount = [Int]()
        mUnscannedData = [String]()
        mConflictData = [String]()
        mInventoryData = NSArray()
        mStatusData = NSMutableArray()
        mSCANNED = NSMutableArray()
        mUNSCANNED = NSMutableArray()
        mRefreshIcon.image = UIImage(named: "refresh_icgrey")
        mRefreshLabel.textColor =  UIColor(named: "theme6A")
        mScannedStocks.text = "0"
        mUnscannedStocks.text = "0"
        mConflictStocks.text = "0"
        
        mUnknownStocks.text = "0"
        self.mGetInventoryDataStock(key: "")
        
        self.mTimer.invalidate()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
//        return arrPeripheral.count
        return devices.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        tableView.showsVerticalScrollIndicator = false
        tableView.showsHorizontalScrollIndicator = false

        guard let cell = tableView.dequeueReusableCell(withIdentifier: "DeviceItems") as? DeviceItems else {
            return UITableViewCell()
        }

        let device = devices[indexPath.row]

        switch device.type {
        case .bluetooth:
            let id = device.peripheral?.identifier.uuidString ?? ""
            let connected = device.peripheral == bluetoothService?.peripheral &&
                bluetoothService?.isConnected() == true
            let loading = pendingBluetoothIdentifier == device.peripheral?.identifier && !connected

            cell.configure(
                name: device.name,
                id: id,
                connected: connected,
                loading: loading
            )

        case .zebra:
            let readerID = device.zebraReader?.getReaderID()
            let id = device.zebraReader?.getReaderSerialNumber() ?? ""
            let connected = ZebraRFIDService.shared.isConnected &&
                ZebraRFIDService.shared.currentReaderID == readerID
            let loading = pendingZebraReaderID == readerID && !connected

            cell.configure(
                name: device.name,
                id: id,
                connected: connected,
                loading: loading
            )
        }

        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
//        connect(arrPeripheral[indexPath.row])
        let device = devices[indexPath.row]

        switch device.type {
            
        case .bluetooth:
            
            if let peripheral = device.peripheral {
                pendingBluetoothIdentifier = peripheral.identifier
                mDeviceTableView.reloadData()
                connect(peripheral)
            }
            
        case .zebra:

            guard let reader = device.zebraReader else {
                return
            }

            pendingZebraReaderID = reader.getReaderID()
            mDeviceTableView.reloadData()

            if ZebraRFIDService.shared.isConnected {

                if ZebraRFIDService.shared.currentReaderID == reader.getReaderID() {

                    print("Disconnect Reader")

                    ZebraRFIDService.shared.disconnect()

                } else {

                    print("Switch Reader")

                    ZebraRFIDService.shared.disconnect()

                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {

                        ZebraRFIDService.shared.connect(
                            readerID: reader.getReaderID()
                        )
                    }
                }

            } else {

                ZebraRFIDService.shared.connect(
                    readerID: reader.getReaderID()
                )
            }
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
            self.updateScannerControls()
            self.mDeviceTableView.reloadData()
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
      
    func mStartQRcode(){
        
        captureSession = AVCaptureSession()
        
        guard let videoCaptureDevice = AVCaptureDevice.default(for: .video) else { return }
        let videoInput: AVCaptureDeviceInput
        
        do {
            videoInput = try AVCaptureDeviceInput(device: videoCaptureDevice)
        } catch {
            return
        }
        
        if (captureSession.canAddInput(videoInput)) {
            captureSession.addInput(videoInput)
        } else {
            failed()
            return
        }
        
        let metadataOutput = AVCaptureMetadataOutput()
        
        if (captureSession.canAddOutput(metadataOutput)) {
            captureSession.addOutput(metadataOutput)
            
            metadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
                        
            metadataOutput.metadataObjectTypes = [.code128,.code39,
                                                  .qr,.ean8, .ean13, .pdf417]
        } else {
            failed()
            return
        }
        
        previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        previewLayer.frame = mScannerCamView.layer.bounds
        previewLayer.videoGravity = .resizeAspectFill
        mScannerCamView.layer.addSublayer(previewLayer)
        mScannerView.isHidden = false
        captureSession.startRunning()
        
    }
    
    func failed() {
        let ac = UIAlertController(title: "Scanning not supported", message: "Your device does not support scanning a code from an item. Please use a device with a camera.", preferredStyle: .alert)
        ac.addAction(UIAlertAction(title: "OK", style: .default))
        present(ac, animated: true)
        captureSession = nil
    }


    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        
        if let metadataObject = metadataObjects.first {
            guard let readableObject = metadataObject as? AVMetadataMachineReadableCodeObject else { return }
            guard let stringValue = readableObject.stringValue else { return }
            AudioServicesPlaySystemSound(kSystemSoundID_Vibrate)
            found(code: stringValue)
        }
        dismiss(animated: true)
    }
    
    func found(code: String) {
        print("found code = \(code)")
        var mUnknown = true
        for i in mStatusData {
            
            if let mValue = i as? NSMutableDictionary,
               let sku = mValue.value(forKey: "SKU") as? String,
               let stockID = mValue.value(forKey: "stock_id") as? String,
               let poQtyString = mValue.value(forKey: "po_QTY") as? String,
               let poQty = Int(poQtyString) {
                
                if !code.isEmpty {
                    let searchKey = code
                    if searchKey == sku || searchKey == stockID {
                        if !mScannedData.contains(stockID){
                            mScannedData.append(stockID)
                            mScannedCount.append(poQty)
                            let items = uniqueElementsFrom(array: mScannedData)
                            mScannedData = items
                            mScannedStocks.text = "\(mScannedCount.reduce(0, {$0 + $1}))"
                            let mUnsCount = (Int(mTotalStocks.text ?? "0") ?? 0) - (Int(mScannedStocks.text ?? "0") ?? 0)
                            mUnscannedStocks.text = "\(mUnsCount)"
                            mSCANNED.add(mValue)
                            
                            let mData = NSMutableDictionary()
                            mData.setValue(stockID, forKey: "stock_id")
                            mData.setValue(poQty, forKey: "po_QTY")
                            mData.setValue(sku, forKey: "SKU")
                            mData.setValue("\(mValue.value(forKey: "_id") ?? "")", forKey: "_id")
                            mData.setValue("\(mValue.value(forKey: "location_id") ?? "")", forKey: "location_id")
                            
                            mSAVESCANNED.add(mData)
                        }
                        mUnknown = false
                    }else{
                        
                    }
                }
            }
        }
        
        if mUnknown {
            let mUnknowdNewData = NSMutableDictionary()
            mUnknowdNewData.setValue(mSearchStock.text ?? "", forKey: "SKU")
            mUnknowdNewData.setValue(mSearchStock.text ?? "", forKey: "stock_id")
            mUnknowdNewData.setValue("", forKey: "po_QTY")
            mUnknowdNewData.setValue("", forKey: "_id")
            mUnknowdNewData.setValue("", forKey: "location_id")
            self.mUNKNOWNARRAY.add(mUnknowdNewData)
            
            
            mCONFLICT.append(mSearchStock.text ?? "" + "UKN")
            let items = uniqueElementsFrom(array: mCONFLICT)
            mCONFLICT = items
        }
        
        if captureSession != nil {
            captureSession.startRunning()
        }
        mStatus()
        
    }
    
    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .portrait
    }
    
    private func normalizedStockLookupKey(_ value: String) -> String {
        return value
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .uppercased()
            .replacingOccurrences(of: " ", with: "")
    }

    private func addStockLookupKey(_ key: String, item: NSDictionary) {
        let normalized = normalizedStockLookupKey(key)
        guard !normalized.isEmpty else { return }
        stockMap[normalized] = item
    }

    private func rebuildStockMap(_ data: [NSDictionary]) {
        stockMap.removeAll()

        let possibleRFIDKeys = [
            "rfid", "RFID", "rfid_id", "RFID_ID",
            "rfid_tag", "RFID_TAG", "rfid_code", "RFID_CODE",
            "epc", "EPC", "epc_id", "EPC_ID",
            "tag_id", "TAG_ID", "tag", "TAG"
        ]

        for item in data {
            addStockLookupKey("\(item["stock_id"] ?? "")", item: item)
            addStockLookupKey("\(item["SKU"] ?? "")", item: item)

            for key in possibleRFIDKeys {
                if let value = item[key] as? String {
                    addStockLookupKey(value, item: item)
                } else if let value = item[key] {
                    addStockLookupKey("\(value)", item: item)
                }
            }

            // Some API versions put RFID/EPC under product_details.
            if let details = item["product_details"] as? NSDictionary {
                for key in possibleRFIDKeys {
                    if let value = details[key] as? String {
                        addStockLookupKey(value, item: item)
                    } else if let value = details[key] {
                        addStockLookupKey("\(value)", item: item)
                    }
                }
            }
        }

        print("📦 Stock lookup map count =", stockMap.count)
        print("📦 Stock lookup keys =", Array(stockMap.keys.prefix(20)))
    }

    func mGetInventoryDataStock(key: String) {
        let params: [String: Any] = [
            "price": ["min": mMinPrices, "max": mMaxPrices],
            "item": mItemsId,
            "collection": mCollectionId,
            "location": mLocationsId,
            "metal": mMetalsId,
            "stone": mStonesId,
            "size": mSizeId,
        ]
        
        print("mGetInventoryDataStock params: \(params)")
        let urlPath = mGetStockTake
        
        
        guard Reachability.isConnectedToNetwork() else {
            CommonClass.showSnackBar(message: "No Internet Connection")
            return
        }
        
        CommonClass.showLoader(view: sStockTakeLoading)
        
        mGetData(url: urlPath, headers: sGisHeaders, params: params) { response, status in
            CommonClass.stopLoader()
            print("mGetInventoryDataStock response: \(response)")
            
            guard status else {
                self.stopSaveIndicator(success: false)
                CommonClass.showSnackBar(message: "Oops, something went wrong!")
                return
            }
            
            if let mCode = response.value(forKey: "code") as? Int, mCode == 403 {
                CommonClass.sessionExpired(isExpired: true, navigation: self.navigationController)
                return
            }
            
            if let code = response.value(forKey: "code") as? Int, code == 200 {
                if let mData = response.value(forKey: "data") as? [NSDictionary] {
                    print("mGetInventoryDataStock self.mInventoryData: \(mData)")
                    self.mInventoryData = mData as NSArray
                    self.rebuildStockMap(mData)
                    
                    var arr = [NSMutableDictionary]()
                    var totalPoQty = 0
                    var unscannedPoQty = 0
                    var unscannedData = [NSDictionary]()
                    
                    for data in mData {
                        if let SKU = data["SKU"] as? String,
                           let stock_id = data["stock_id"] as? String,
                           let poQty = Int("\(data["po_QTY"] ?? "0")"),
                           let _id = data["_id"] as? String,
                           let location_id = data["location_id"] as? String {
                            
                            let poQtyString = "\(data["po_QTY"] ?? "0")"
                            
                            let mData = NSMutableDictionary()
                            mData.setValue(SKU, forKey: "SKU")
                            mData.setValue(stock_id, forKey: "stock_id")
                            mData.setValue(poQtyString, forKey: "po_QTY")
                            mData.setValue(_id, forKey: "_id")
                            mData.setValue(location_id, forKey: "location_id")
                            
                            arr.append(mData)
                            
                            totalPoQty += poQty
                            if poQty != 0 {
                                unscannedPoQty += poQty
                                unscannedData.append(data)
                            }
                        }
                    }
                    
                   
                    DispatchQueue.main.async {
                        self.mStatusData.removeAllObjects()
                        self.mStatusData.addObjects(from: arr)
//#if DEBUG

//                    let testIDs = [
//                        "2210867",
//                        "2210868",
//                        "2210869",
//                        "2210870",
//                        "2210871"
//                    ]
//
//                    for id in testIDs {
//
//                        let item = NSMutableDictionary()
//
//                        item["stock_id"] = id
//                        item["po_QTY"] = "1"
//                        item["SKU"] = "TEST"
//                        item["_id"] = UUID().uuidString
//                        item["location_id"] = "TEST"
//
//                        self.mStatusData.add(item)
//                    }

//#endif
                        self.mTotalStocks.text = "\(totalPoQty)"
                        self.mUnscannedStocks.text = "\(unscannedPoQty)"
                        self.updateReferenceSummaryCards()
                        self.mUNSCANNED.removeAllObjects()
                        self.mUNSCANNED.addObjects(from: unscannedData)
                        
                        print("Test Count before =", self.mStatusData.count)
//                        let testIDs = [
//                            "2210867",
//                            "2210868",
//                            "2210869",
//                            "2210870",
//                            "2210871"
//                        ]

//                        for id in testIDs {
//
//                            let item = NSMutableDictionary()
//
//                            item["stock_id"] = id
//                            item["po_QTY"] = "1"
//                            item["SKU"] = "TEST"
//                            item["_id"] = UUID().uuidString
//                            item["location_id"] = "TEST"
//
//                            self.mStatusData.add(item)
//
//                        }

                        print("Test Count After =", self.mStatusData.count)
                        
                        print("mStatusData Count =", self.mStatusData.count)
                        print("mInventoryData Count =", self.mInventoryData.count)
                        
                        let exist = self.mStatusData.contains {
                            guard let dict = $0 as? NSDictionary else { return false }
                            return "\(dict["stock_id"] ?? "")" == "2210867"
                        }

                        print("2210867 Exists =", exist)
                        
                        for item in self.mStatusData {

                            if let dict = item as? NSDictionary {

                                if "\(dict["stock_id"] ?? "")" == "2210867" {

                                    print("FOUND IN STATUS DATA")
                                }
                            }
                        }
                        
                    }
                } else {
                    // Handle case where response.value(forKey: "data") is empty
                 
                    DispatchQueue.main.async {
                        self.mStatusData.removeAllObjects()
                        self.mTotalStocks.text = "0"
                        self.mUnscannedStocks.text = "0"
                        self.mUNSCANNED.removeAllObjects()
                        self.updateReferenceSummaryCards()
                    }
                }
            } else {
                if let error = response.value(forKey: "error") as? String, error == "Authorization has been expired" {
                    CommonClass.sessionExpired(isExpired: true, navigation: self.navigationController)
                } else {
                    CommonClass.showSnackBar(message: "Error! \(response.value(forKey: "code") ?? "Unknown Error")")
                }
            }
        }
    }
    
    
    func mUploadStocksSave(voucherId: String){
        
        
        let mPriceData = NSMutableDictionary()
        mPriceData.setValue(mMinPrices, forKey: "min")
        mPriceData.setValue(mMaxPrices, forKey: "max")
        mFilterData.setValue(mPriceData, forKey: "price")
        mFilterData.setValue(mItemsId, forKey: "item")
        mFilterData.setValue(mCollectionId, forKey: "collection")
        mFilterData.setValue(mLocationsId, forKey: "location")
        mFilterData.setValue(mMetalsId, forKey: "metal")
        mFilterData.setValue(mStonesId, forKey: "stone")
        mFilterData.setValue(mSizeId, forKey: "size")
        
        let urlPath =  mUploadStocks
        
        let  mParams:[String:Any] = [
            "unscanned":mSAVEUNSCANNED,
            "scanned":mSAVESCANNED,
            "unknown":mUNKNOWNARRAY,
            "conflict":mCONFLICTARRAY,
            "total_scanned_qty":Int(mScannedStocks.text ?? "") ?? 0,
            "total_unscanned_qty":Int(mUnscannedStocks.text ?? "") ?? 0,
            "conflict_qty":Int(mConflictStocks.text ?? "") ?? 0,
            "unknown_qty": Int(mUnknownStocks.text ?? "") ?? 0,
            "voucher_id":voucherId,
            "filter":mFilterData]
        

        print("StockTakeCreate Payload = \(mParams)")
        if Reachability.isConnectedToNetwork() == true {
            // Save must freeze RFID input so the payload cannot change mid-request.
            if ZebraRFIDService.shared.isInventoryRunning {
                print("🛑 Stop Zebra inventory before Save")
                ZebraRFIDService.shared.stopInventory()
            }
            recentRFIDReads.removeAll()
            updateScannerControls()
            CommonClass.showFullLoader(view: self.view)
            
            AF.request(urlPath, method:.post,parameters:mParams,encoding: JSONEncoding.default, headers: sGisHeaders2).responseJSON
            { response in
                self.mMoreIcon.image = UIImage(named: "save_icg")
                self.mMoreLabel.textColor =  UIColor(named: "theme6A")
                
                
                CommonClass.stopLoader()
                
                guard response.error == nil else {
                    self.hasSuccessfulSave = false
                    self.hasSaveFailed = true
                    self.stopSaveIndicator(success: false)
                    self.showStockTakeResultMessage(success: false, message: "Save Failed. Please try again.")
                    return
                }
                
                guard let jsonData = response.data else {
                    self.hasSuccessfulSave = false
                    self.hasSaveFailed = true
                    self.stopSaveIndicator(success: false)
                    self.showStockTakeResultMessage(success: false, message: "Save Failed. Please try again.")
                    return
                }
                
                let json = try? JSONSerialization.jsonObject(with: jsonData, options: [])
                
                guard let jsonResult = json as? NSDictionary else {
                    self.hasSuccessfulSave = false
                    self.hasSaveFailed = true
                    self.stopSaveIndicator(success: false)
                    self.showStockTakeResultMessage(success: false, message: "Save Failed. Please try again.")
                    return
                }
                
                if jsonResult.value(forKey: "code") as? Int == 200 {
                    // Keep the current result visible exactly like the design
                    // screen. Only stop the reader and reset the transient RFID
                    // de-duplication cache.
                    self.recentRFIDReads.removeAll()
                    self.updateScannerControls()
                    self.hasSuccessfulSave = true
                    self.hasSaveFailed = false
                    self.stopSaveIndicator(success: true)
                    self.showStockTakeResultMessage(
                        success: true,
                        message: "Save Successful"
                    )

                } else {
                    if let error = jsonResult.value(forKey: "error") as? String,
                       error == "Authorization has been expired" {
                        self.stopSaveIndicator(success: false)
                        CommonClass.sessionExpired(isExpired: true, navigation: self.navigationController)
                    } else {
                        self.hasSuccessfulSave = false
                        self.hasSaveFailed = true
                        self.stopSaveIndicator(success: false)
                        self.showStockTakeResultMessage(
                            success: false,
                            message: "Save Failed. Please try again."
                        )
                    }
                }
                
                
            }
        }else{
            stopSaveIndicator(success: false)
            CommonClass.showSnackBar(message: "No Internet Connection")
        }
        
        
    }
    
    private func hasStockTakeData() -> Bool {
        let scanned = Int(mScannedStocks?.text ?? "0") ?? 0
        let conflict = Int(mConflictStocks?.text ?? "0") ?? 0
        let unknown = Int(mUnknownStocks?.text ?? "0") ?? 0
        let unscanned = Int(mUnscannedStocks?.text ?? "0") ?? 0
        // The initial session already contains the full unscanned inventory.
        // Only actual scan/result changes should trigger the unsaved-data warning.
        return scanned > 0 || conflict > 0 || unknown > 0
    }

    private func shouldConfirmLeavingWithoutSave() -> Bool {
        guard hasStockTakeData() else { return false }
        return !hasSuccessfulSave && !isSaveInProgress
    }

    private func shouldConfirmClearingWithoutSave() -> Bool {
        guard hasStockTakeData() else { return false }
        return !hasSuccessfulSave && !isSaveInProgress
    }

    private func showLeaveWithoutSavingConfirmation() {
        let alert = UIAlertController(
            title: "Leave without saving?",
            message: "Unsaved stock take data will be lost. Do you want to leave anyway?",
            preferredStyle: .alert
        )

        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        alert.addAction(UIAlertAction(title: "Leave", style: .destructive) { [weak self] _ in
            self?.navigationController?.popViewController(animated: true)
        })

        present(alert, animated: true)
    }

    private func showClearWithoutSavingConfirmation() {
        let alert = UIAlertController(
            title: "Clear data without saving?",
            message: "Unsaved stock take data will be lost. Do you want to clear it?",
            preferredStyle: .alert
        )

        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        alert.addAction(UIAlertAction(title: "Clear", style: .destructive) { [weak self] _ in
            self?.clearStockTakeResults()
        })

        present(alert, animated: true)
    }

    private func showStockTakeResultMessage(success: Bool, message: String) {
        DispatchQueue.main.async {
            let color = success
                ? UIColor.systemGreen
                : UIColor.systemRed

            let background = success
                ? UIColor(red: 0.93, green: 1.0, blue: 0.91, alpha: 1.0)
                : UIColor(red: 1.0, green: 0.93, blue: 0.93, alpha: 1.0)

            let toast = UIView()
            toast.backgroundColor = background
            toast.layer.cornerRadius = 5
            toast.layer.borderWidth = 1
            toast.layer.borderColor = color.cgColor
            toast.translatesAutoresizingMaskIntoConstraints = false
            toast.tag = 99123

            let label = UILabel()
            label.text = message
            label.font = UIFont.systemFont(ofSize: 13, weight: .regular)
            label.textColor = color
            label.textAlignment = .center
            label.translatesAutoresizingMaskIntoConstraints = false

            toast.addSubview(label)
            self.view.addSubview(toast)

            NSLayoutConstraint.activate([
                toast.topAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.topAnchor, constant: 8),
                toast.centerXAnchor.constraint(equalTo: self.view.centerXAnchor),
                toast.widthAnchor.constraint(greaterThanOrEqualToConstant: success ? 126 : 206),
                toast.heightAnchor.constraint(equalToConstant: 40),
                label.leadingAnchor.constraint(equalTo: toast.leadingAnchor, constant: 12),
                label.trailingAnchor.constraint(equalTo: toast.trailingAnchor, constant: -12),
                label.topAnchor.constraint(equalTo: toast.topAnchor),
                label.bottomAnchor.constraint(equalTo: toast.bottomAnchor)
            ])

            UIView.animate(withDuration: 0.2) {
                toast.alpha = 1.0
            }

            DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
                UIView.animate(withDuration: 0.2, animations: {
                    toast.alpha = 0
                }, completion: { _ in
                    toast.removeFromSuperview()
                })
            }
        }
    }

    func getVoucherID(){
        let params:[String: Any] = [
            "query":"{\n        vouchers(group: \"Stock_Take\") {\n          id\n          name \n      }\n        }",
            "variables":"{}"
        ]

        mGetData(url: mInventoryGrapQlUrl, headers: sGisHeaders, params: params) { response, status in
            CommonClass.stopLoader()

            guard status else {
                self.hasSuccessfulSave = false
                self.hasSaveFailed = true
                self.stopSaveIndicator(success: false)
                self.showStockTakeResultMessage(
                    success: false,
                    message: "Save Failed. Please try again."
                )
                return
            }

            if let dataDictionary = response.value(forKey: "data") as? [String: Any],
               let vouchersArray = dataDictionary["vouchers"] as? [[String: Any]],
               let firstVoucher = vouchersArray.first,
               let voucherId = firstVoucher["id"] as? String {

                self.mUploadStocksSave(voucherId: voucherId)
            } else {
                self.hasSuccessfulSave = false
                self.hasSaveFailed = true
                self.stopSaveIndicator(success: false)
                self.showStockTakeResultMessage(
                    success: false,
                    message: "Save Failed. Please try again."
                )
            }
        }
    }

    //UI Element
    func createScanningIndicator() {
        
        let height: CGFloat = 15
        let opacity: Float = 0.4
        let topColor = UIColor.green.withAlphaComponent(0)
        let bottomColor = UIColor.green
        
        let layer = CAGradientLayer()
        layer.colors = [topColor.cgColor, bottomColor.cgColor]
        layer.opacity = opacity
        
        let squareWidth = mScannerCamView.frame.width * 0.6
        let xOffset = mScannerCamView.frame.width * 0.2
        let yOffset = mScannerCamView.frame.midY - (squareWidth / 2)
        layer.frame = CGRect(x: xOffset, y: yOffset, width: squareWidth, height: height)
        
        self.mScannerCamView.layer.insertSublayer(layer, at: 1)
        
        let initialYPosition = layer.position.y
        let finalYPosition = initialYPosition + squareWidth - height
        let duration: CFTimeInterval = 2
        
        let animation = CABasicAnimation(keyPath: "position.y")
        animation.fromValue = initialYPosition as NSNumber
        animation.toValue = finalYPosition as NSNumber
        animation.duration = duration
        animation.repeatCount = .infinity
        animation.isRemovedOnCompletion = false
        
        layer.add(animation, forKey: nil)
    }
    //UI Element
    func createScanningFrame() {
        
        let lineLength: CGFloat = 15
        let squareWidth = mScannerCamView.frame.width * 0.6
        let topLeftPosX = mScannerCamView.frame.width * 0.2
        let topLeftPosY = mScannerCamView.frame.midY - (squareWidth / 2)
        let btmLeftPosY = mScannerCamView.frame.midY + (squareWidth / 2)
        let btmRightPosX = mScannerCamView.frame.midX + (squareWidth / 2)
        let topRightPosX = mScannerCamView.frame.width * 0.8
        
        let path = UIBezierPath()
        
        //top left
        path.move(to: CGPoint(x: topLeftPosX, y: topLeftPosY + lineLength))
        path.addLine(to: CGPoint(x: topLeftPosX, y: topLeftPosY))
        path.addLine(to: CGPoint(x: topLeftPosX + lineLength, y: topLeftPosY))
        
        //bottom left
        path.move(to: CGPoint(x: topLeftPosX, y: btmLeftPosY - lineLength))
        path.addLine(to: CGPoint(x: topLeftPosX, y: btmLeftPosY))
        path.addLine(to: CGPoint(x: topLeftPosX + lineLength, y: btmLeftPosY))
        
        //bottom right
        path.move(to: CGPoint(x: btmRightPosX - lineLength, y: btmLeftPosY))
        path.addLine(to: CGPoint(x: btmRightPosX, y: btmLeftPosY))
        path.addLine(to: CGPoint(x: btmRightPosX, y: btmLeftPosY - lineLength))
        
        //top right
        path.move(to: CGPoint(x: topRightPosX, y: topLeftPosY + lineLength))
        path.addLine(to: CGPoint(x: topRightPosX, y: topLeftPosY))
        path.addLine(to: CGPoint(x: topRightPosX - lineLength, y: topLeftPosY))
        
        
        shape.path = path.cgPath
        shape.strokeColor = UIColor.white.cgColor
        shape.lineWidth = 3
        shape.fillColor = UIColor.clear.cgColor
        
        self.mScannerCamView.layer.insertSublayer(shape, at: 1)
    }
    //Filter and remove duplicate item from array.
    func uniqueElementsFrom(array:[String]) -> [String] {
        
        var set = Set<String>()
        let result = array.filter {
            
            guard !set.contains($0)  else { return  false }
            
            set.insert($0)
            return true
        }
        
        return result
    }
    
    
    func mGetFilterData(){
        
        let urlPath =  mGetInventoryFilter

        
        if Reachability.isConnectedToNetwork() == true {
            AF.request(urlPath, method:.post, headers: sGisHeaders2).responseJSON
            { response in
                
                guard response.error == nil else {
                    CommonClass.showSnackBar(message: "OOP's something went wrong!")
                    return
                }
                
                guard let jsonData = response.data else {
                    CommonClass.showSnackBar(message: "OOP's something went wrong!")
                    return
                }
                
                let json = try? JSONSerialization.jsonObject(with: jsonData, options: [])
                
                guard let jsonResult = json as? NSDictionary else {
                    CommonClass.showSnackBar(message: "OOP's something went wrong!")
                    return
                }
                
                if jsonResult.value(forKey: "code") as? Int == 200 {
                    
                    if let mData = jsonResult.value(forKey: "data") as? NSDictionary {
                        
                        if let mItems = mData.value(forKey: "item_name") as? NSArray {
                            if mItems.count > 0 {
                                self.mItemsData = mItems
                                self.mItemCollectionView.reloadData()
                            }
                        }
                        
                        if let mMetal = mData.value(forKey: "Metal") as? NSArray {
                            if mMetal.count > 0 {
                                self.mMetalsData = mMetal
                                self.mMetalCollectionView.reloadData()
                            }
                        }
                        
                        if let mLocation = mData.value(forKey: "location_name") as? NSArray {
                            if mLocation.count > 0 {
                                self.mLocationsData = mLocation
                                self.mLocationCollectionView.reloadData()
                            }
                        }
                    }
                    
                }else{
                    if let error = jsonResult.value(forKey: "error") as? String {
                        if error == "Authorization has been expired" {
                            CommonClass.sessionExpired(isExpired: true, navigation: self.navigationController)
                        }
                    }
                }
                
                
            }
        }else{
            CommonClass.showSnackBar(message: "No Internet Connection")
        }
        
        
    }
    
    
    
}

extension Array where Element : Hashable{
    
    
    func removingDuplicates() -> [Element]
    {
        
        var addedDict = [Element:Bool]()
        return filter {
            addedDict.updateValue(true,forKey:$0) == nil
        }
    }
    
    
    mutating func removingDuplicates() {
        
        self = self.removingDuplicates()
    }
}

extension String {
    
    func hexToString()->String{
        
        var finalString = ""
        let chars = Array(self)
        
        for count in stride(from: 0, to: chars.count - 1, by: 2){
            let firstDigit =  Int.init("\(chars[count])", radix: 16) ?? 0
            let lastDigit = Int.init("\(chars[count + 1])", radix: 16) ?? 0
            let decimal = firstDigit * 16 + lastDigit
            let decimalString = String(format: "%c", decimal) as String
            finalString.append(decimalString.trimmingCharacters(in: CharacterSet(charactersIn: "0123456789").inverted)
            )
        }
        return finalString
        
        
        
    }
    
    func base64Decoded() -> String? {
        guard let data = Data(base64Encoded: self) else { return nil }
        return String(data: data, encoding: .init(rawValue: 0))
    }
   
}

extension DataProtocol {
    func hexEncodedString(uppercase: Bool = false) -> String {
        return self.map {
            if $0 < 16 {
                return "0" + String($0, radix: 16, uppercase: uppercase)
            } else {
                return String($0, radix: 16, uppercase: uppercase)
            }
        }.joined()
    }
}
extension Data {
    func hexEncodedStrings() -> String {
        return map { String(format: "%02hhx", $0) }.joined()
    }
}

extension UIView {
    func dropShadow(scale: Bool = true) {
        layer.masksToBounds = false
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOpacity = 0.2
        layer.shadowOffset = .zero
        layer.shadowRadius = 1
        
        layer.shouldRasterize = true
        layer.rasterizationScale = scale ? UIScreen.main.scale : 1
    }
}
